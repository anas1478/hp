
// Copyright 2012 Google Inc. All rights reserved.
(function(w,g){w[g]=w[g]||{};w[g].e=function(s){return eval(s);};})(window,'google_tag_manager');(function(){

var data = {
"resource": {
  "version":"101",
  "macros":[{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var b=17;return function(a){a.set(\"dimension\"+b,a.get(\"clientId\"))}})();"]
    },{
      "function":"__v",
      "vtp_name":"gtm.elementUrl",
      "vtp_dataLayerVersion":1
    },{
      "function":"__c",
      "vtp_value":"\\.(wav|mp\\d|mov|mpe*g|avi|hqx|mxp|adpp|air|mp3|mpg|wmv|doc|xls|tgz|msi|zxp|flv|cptx|docx*|xlsx*|pptx*|pdf|xml|exe|dmg|zip|jar|bin|msi)$"
    },{
      "function":"__c",
      "vtp_value":"(gplus|twitter|facebook|youtube|linkedin)"
    },{
      "function":"__c",
      "vtp_value":"example.com"
    },{
      "function":"__c",
      "vtp_value":"hp.com"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){try{var a=",["escape",["macro",1],8,16],";return a?\/^mailto:\/i.test(a)?\"mailto\":(new RegExp(",["escape",["macro",2],8,16],",\"i\")).test(a)?\"download\":(new RegExp(\"^[^?]+\"+location.hostname,\"i\")).test(a)?\"same\":(new RegExp(\"^[^?]+\"+",["escape",["macro",3],8,16],",\"i\")).test(a)?\"social\":(new RegExp(\"^[^?]+(\"+",["escape",["macro",4],8,16],".replace(\/,\/,\"|\")+\")\",\"i\")).test(a)?\"crossDomain\":(new RegExp(\"^[^?]+\"+",["escape",["macro",5],8,16],",\"i\")).test(a)?\"sibling\":\/mailto:([^?]+)\/.test(a)?\"email\":\/^https*:\\\/\\\/\/i.test(a)?\"outbound\":\"unknown\":\n\"none\"}catch(b){dataLayer.push({event:\"error\",action:\"GTM\",label:\"linkType:\"+b.message})}})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return function(){var a=ga.getAll()[0];a=a.get(\"clientId\");window.dataLayer.push({googleCID:a})}})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ecommerce.purchase.actionField.id"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){if(",["escape",["macro",8],8,16],")return function(){var b=",["escape",["macro",8],8,16],",c=\"_g_tid\",a=new Date;a.setTime(a.getTime()+1728E5);a=\"expires\\x3d\"+a.toUTCString();document.cookie=c+\"\\x3d\"+b+\";\"+a+\";path\\x3d\/\"}})();"]
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"_g_tid"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",8],8,16],";if(",["escape",["macro",10],8,16],"\u0026\u0026a==",["escape",["macro",10],8,16],")return\"blockTransaction\"})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return document.location.hostname})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=\"??\",b=a;try{\"object\"==typeof window._A\u0026\u0026\"function\"==typeof _A.getSiteSection\u0026\u0026(_A.getSiteSection(),b=_A.scrubAndEsc(_A.section.country,\":\",!0)||a)}catch(c){b=a}return b})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=\"unknown\",b=a;try{\"object\"==typeof window._A\u0026\u0026\"function\"==typeof _A.getSiteSection\u0026\u0026(_A.getSiteSection(),b=_A.scrubAndEsc(_A.section.region,\":\",!0)||a)}catch(c){b=a}return b})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var b=\"??-??\",a=b;try{if(\"object\"==typeof window._A\u0026\u0026\"function\"==typeof _A.getSiteSection){_A.getSiteSection();var c=_A.scrubAndEsc(_A.section.language,\":\",!0)||\"??\";var d=_A.scrubAndEsc(_A.section.country,\":\",!0)||\"??\";a=c+\"-\"+d}}catch(e){a=b}return a})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=\"en\",b=a;try{\"object\"==typeof window._A\u0026\u0026\"function\"==typeof _A.getSiteSection\u0026\u0026(_A.getSiteSection(),b=_A.scrubAndEsc(_A.section.language,\":\",!0)||a)}catch(c){b=a}return b})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var b=\"unknown\",a=b;try{\"object\"==typeof window._A\u0026\u0026\"function\"==typeof _A.getSiteSection\u0026\u0026(_A.getSiteSection(),_A.section.type\u0026\u0026_A.isS(_A.section.type)\u0026\u0026(a=_A.LC(_A.section.type)))}catch(c){a=b}return a})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var b=\"unknown\",a=b;try{\"object\"==typeof window._A\u0026\u0026\"function\"==typeof _A.getSiteSection\u0026\u0026(_A.getSiteSection(),_A.section.type\u0026\u0026_A.isS(_A.section.type)\u0026\u0026(a=_A.LC(_A.section.type)),_A.section.subtype\u0026\u0026_A.isS(_A.section.subtype)\u0026\u0026(a+=\":\"+_A.LC(_A.section.subtype)))}catch(c){a=b}return a})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return document.location.hostname+document.location.pathname})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var b=\"object\"==typeof window._UDL,a=\"object\"==typeof window.s\u0026\u0026window.s?window.s:0;if(a\u0026\u0026!b||_UDL.compatibilityMode)return a.pageName||document.location.href.replace(\/^http.?:\\\/\\\/\/,\"\").replace(\/\\\/$\/,\"\")})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var b=\"unknown\",a=b;try{\"object\"==typeof window._A\u0026\u0026\"function\"==typeof _A.getSiteSection\u0026\u0026(_A.getSiteSection(),a=_A.section.dev?\"dev\":\"production\")}catch(c){a=b}return a})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=\"unknown\",b=a;try{\"object\"==typeof window._A\u0026\u0026(b=_A.getDeviceInfo().deviceType||a)}catch(c){b=a}return b})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){try{var b=window,a=_A.isO(b._AA)\u0026\u0026_A.isO(b._AA.s)?b._AA.s:_A.isO(b.s)?b.s:{};_A.isF(a.c_r)||(a.c_r=_A.cR);var c=a.visitorID||(a.c_r(\"s_vi\")||\"\").replace(\/\\[[^\\[]*\\]\/g,\"\").replace(\/[^\\|]*\\|\/,\"\")||a.c_r(\"AMCV_\")||a.mim||a.c_r(\"s_fid\")||a.fid||\"\";if(c)return c}catch(d){}})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){try{if(_A.parseParam(\"aoid\"))return _A.parseParam(\"aoid\")}catch(a){}})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){try{var a=(_A.parseParam(\"jumpid\")||\"\").toLowerCase();if(a\u0026\u0026-1==\"af_ ba_ cs_ em_ ex_ mb_ ps_ sc_ va_\".split(\" \").indexOf(a.split(\"_\")[0]+\"_\"))return a}catch(b){}})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){try{var a=(_A.parseParam(\"jumpid\")||\"\").toLowerCase();if(a\u0026\u0026-1\u003C\"af_ ba_ cs_ em_ ex_ mb_ ps_ sc_ va_\".split(\" \").indexOf(a.split(\"_\")[0]+\"_\"))return a}catch(b){}})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=\"unknown\",b=a;try{\"object\"==typeof window._A\u0026\u0026\"function\"==typeof _A.getSiteSection\u0026\u0026(_A.getSiteSection(),b=_A.scrubAndEsc(_A.section.platform,\":\",!0)||a)}catch(c){b=a}return b})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){try{if(_A.parseParam(\"rid\"))return _A.parseParam(\"rid\")}catch(a){}})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return document.location.href})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return document.location.href.split(\"?\")[0]})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){if(document.referrer)return document.referrer})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"pageNameL5"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"pageType"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"pageNameL6"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"pageCategory"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"pageNameL7"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"pageSubcategory"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"pageNameL8"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"pageSubcategoryDetail"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=\"\";if(\"object\"==typeof window._A){var c=location,e=\"unknown\",b=\"\",d=\":\";a=_A.LC(_A.section.type)||e;var f=_A.LC(_A.section.subtype)||e,g=_A.scrubAndEsc(_A.LC(",["escape",["macro",32],8,16],"||",["escape",["macro",33],8,16],"||b)||e),h=_A.scrubAndEsc(_A.LC(",["escape",["macro",34],8,16],"||",["escape",["macro",35],8,16],"||b)),k=_A.scrubAndEsc(_A.LC(",["escape",["macro",36],8,16],"||",["escape",["macro",37],8,16],"||b)),l=_A.scrubAndEsc(_A.LC(",["escape",["macro",38],8,16],"||",["escape",["macro",39],8,16],"||b));f\u0026\u0026(a+=d+f);g==e?a+=\":\/\"+c.href.replace(\/^http.?:\\\/\\\/\/,\nb).replace(\/\\?.*\/,b):(c=l?8:k?7:h?6:5,a+=d+g,5\u003Cc\u0026\u0026(a+=d+h),6\u003Cc\u0026\u0026(a+=d+k),7\u003Cc\u0026\u0026(a+=d+l))}return a})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a;return ",["escape",["macro",32],8,16],"||",["escape",["macro",33],8,16],"||a})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a;return ",["escape",["macro",34],8,16],"||",["escape",["macro",35],8,16],"||a})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a;return ",["escape",["macro",36],8,16],"||",["escape",["macro",37],8,16],"||a})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a;return ",["escape",["macro",38],8,16],"||",["escape",["macro",39],8,16],"||a})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=\"\";if(\"object\"==typeof window._A\u0026\u0026\"function\"==typeof _A.getSiteSection){_A.getSiteSection();var d=location,e=\"unknown\",c=\"\",b=\":\";a=_A.LC(_A.section.country)||\"us\";var m=_A.LC(_A.section.language)||\"en\",n=_A.LC(_A.section.type)||e,f=_A.LC(_A.section.subtype)||e,g=_A.scrubAndEsc(_A.LC(",["escape",["macro",32],8,16],"||",["escape",["macro",33],8,16],"||c)||e),h=_A.scrubAndEsc(_A.LC(",["escape",["macro",34],8,16],"||",["escape",["macro",35],8,16],"||c)),k=_A.scrubAndEsc(_A.LC(",["escape",["macro",36],8,16],"||",["escape",["macro",37],8,16],"||c)),\nl=_A.scrubAndEsc(_A.LC(",["escape",["macro",38],8,16],"||",["escape",["macro",39],8,16],"||c));a=a+b+m+b+n;f\u0026\u0026(a+=b+f);g==e?a+=\":\/\"+d.href.replace(\/^http.?:\\\/\\\/\/,c).replace(\/\\?.*\/,c):(d=l?8:k?7:h?6:5,a+=b+g,5\u003Cd\u0026\u0026(a+=b+h),6\u003Cd\u0026\u0026(a+=b+k),7\u003Cd\u0026\u0026(a+=b+l))}return a})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"loginStatus"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",46],8,16],";\"string\"==typeof a\u0026\u0026(a=a.toLowerCase(),a=\"true\"==a?!0:\"false\"==a?!1:a);if(\"boolean\"==typeof a)return a?\"logged in\":\"not logged in\"})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var b;try{var a=_A.getVisitNum()}catch(c){a=b}if(a)return a})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"test1name"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"test1variation"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",49],8,16],";if(a)return a+\":\"+(",["escape",["macro",50],8,16],"||\"unspecified\")})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"test2name"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"test2variation"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",52],8,16],";if(a)return a+\":\"+(",["escape",["macro",53],8,16],"||\"unspecified\")})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"test3name"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"test3variation"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",55],8,16],";if(a)return a+\":\"+(",["escape",["macro",56],8,16],"||\"unspecified\")})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return\"v99|03-Oct-2018 18:20:00\"})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=document.cookie||\"\";try{if(-1\u003Ca.indexOf(\"WRUID\")\u0026\u0026(-1\u003Ca.indexOf(\"_CT_RS_\\x3d1\")||-1==a.indexOf(\"WRIgnore\\x3dtrue\")\u0026\u0026-1\u003C !a.indexOf(\"_CT_RS_\\x3d1\"))){var e=a.split(\";\"),c=0,d=0,b,f=\"\";for(b=0;b\u003Ce.length;b++){for(a=e[b];\" \"==a.charAt(0);)a=a.substring(1,a.length);-1\u003Ca.indexOf(\"CT_Data\")\u0026\u0026(c=a.substring(a.indexOf(\"apv_\")).split(\"_\")[1]);-1\u003Ca.indexOf(\"WRUID\")\u0026\u0026(d=a.split(\"\\x3d\")[1])}f=0==d||0==c?\"\":d+\".\"+c}}catch(g){}if(a=f)return a})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){try{var a=_A.LC(_A.getHTMLtag(\"meta\",\"name\",\"bu\",\"content\"));if(a)return a}catch(b){}})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){try{var a=document,b=\"2c2p.com login.id.hp.com migs.mastercard.com paydollar.com www.paypal.com paypal.vantagecircle.com securegw.paytm.in secure.payu.in phc.hp.com :end:\".split(\" \");if((refHn=(ref=a.referrer)?_A.parseUri(ref).hostname:\"\")\u0026\u0026refHn!=a.location.hostname\u0026\u0026-1==_A.iO(refHn,b))return refHn}catch(c){}})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=document.location.href.toLowerCase(),b=\/store\\.hp\\.com\\\/(us|app|webapp)\\\/\/;a=a.substring(0,(a+\"?\").indexOf(\"?\"));a=a.substring(0,(a+\"#\").indexOf(\"#\"));return!!a.match(b)})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=document.location.href.toLowerCase(),c=[\/www8\\.hp\\.com\\\/[^\\\/]+\\\/[^\\\/]+\\\/contact-hp\/,\/h30631\\.www3\\.hp\\.com\/,\/www8\\.hp\\.com\\\/[^\\\/]+\\\/[^\\\/]+\\\/jobs\/,\/h30261\\.www3\\.hp\\.com\/,\/www8\\.hp\\.com\\\/[^\\\/]+\\\/[^\\\/]+\\\/hp-information\\\/global-citizenship\/,\/(press|garage|newsblog)\\.ext\\.hp\\.com\/,\/engineeredby\\.hp\\.com\/,\/engineeredby\\.hpfitstation\\.com\/,\/lookbook\\.hp\\.com\/,\/helpmechoose\\.ext\\.hp\\.com\/,\/campaigns\\.ext\\.hp\\.com\/,\/qrq\\.itcs\\.hp\\.com\/,\/locator\\.itcs\\.hp\\.com\/,\/enable\\.hp\\.com\/,\/(www[12345678]?|m|ext|welcome|jp)\\.hp\\.com\/],\nb=0;a=a.substring(0,(a+\"?\").indexOf(\"?\"));for(a=a.substring(0,(a+\"#\").indexOf(\"#\"));b\u003Cc.length;b++)if(a.match(c[b]))return!0;return!1})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=document.location.href.toLowerCase(),c=[\/hpshopping\\.in\/,\/hpshopping\\.id\/,\/hpshopping\\.hk\/,\/hpstorethailand\\.com\/,\/hpstore\\.cn\/],b=0;a=a.substring(0,(a+\"?\").indexOf(\"?\"));for(a=a.substring(0,(a+\"#\").indexOf(\"#\"));b\u003Cc.length;b++)if(a.match(c[b]))return!0;return!1})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"available"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return ",["escape",["macro",65],8,16],"?\"available\":\"unavailable\"})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return function(a,b,c){a.attachEvent?(a[\"e\"+b+c]=c,a[b+c]=function(){a[\"e\"+b+c](window.event)},a.attachEvent(\"on\"+b,a[b+c])):a.addEventListener(b,c,!1)}})();"]
    },{
      "function":"__e"
    },{
      "function":"__c",
      "vtp_value":"1"
    },{
      "function":"__c",
      "vtp_value":"2"
    },{
      "function":"__c",
      "vtp_value":"3"
    },{
      "function":"__c",
      "vtp_value":"4"
    },{
      "function":"__c",
      "vtp_value":"5"
    },{
      "function":"__c",
      "vtp_value":"1"
    },{
      "function":"__c",
      "vtp_value":"2"
    },{
      "function":"__c",
      "vtp_value":"3"
    },{
      "function":"__c",
      "vtp_value":"4"
    },{
      "function":"__c",
      "vtp_value":"5"
    },{
      "function":"__c",
      "vtp_value":"6"
    },{
      "function":"__c",
      "vtp_value":"7"
    },{
      "function":"__c",
      "vtp_value":"8"
    },{
      "function":"__c",
      "vtp_value":"9"
    },{
      "function":"__c",
      "vtp_value":"10"
    },{
      "function":"__c",
      "vtp_value":"12"
    },{
      "function":"__c",
      "vtp_value":"13"
    },{
      "function":"__c",
      "vtp_value":"14"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"userTypeSession"
    },{
      "function":"__c",
      "vtp_value":"15"
    },{
      "function":"__c",
      "vtp_value":"16"
    },{
      "function":"__c",
      "vtp_value":"18"
    },{
      "function":"__c",
      "vtp_value":"19"
    },{
      "function":"__c",
      "vtp_value":"20"
    },{
      "function":"__c",
      "vtp_value":"21"
    },{
      "function":"__c",
      "vtp_value":"22"
    },{
      "function":"__c",
      "vtp_value":"23"
    },{
      "function":"__c",
      "vtp_value":"24"
    },{
      "function":"__c",
      "vtp_value":"25"
    },{
      "function":"__c",
      "vtp_value":"26"
    },{
      "function":"__c",
      "vtp_value":"27"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return\"gtm|GTM-MZXB4R4|\"+(",["escape",["macro",58],8,16],"||\"\")})();"]
    },{
      "function":"__c",
      "vtp_value":"28"
    },{
      "function":"__c",
      "vtp_value":"29"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"prevPageName"
    },{
      "function":"__c",
      "vtp_value":"30"
    },{
      "function":"__c",
      "vtp_value":"31"
    },{
      "function":"__c",
      "vtp_value":"32"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"demandBase1"
    },{
      "function":"__c",
      "vtp_value":"33"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"demandBase2"
    },{
      "function":"__c",
      "vtp_value":"34"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"demandBase3"
    },{
      "function":"__c",
      "vtp_value":"35"
    },{
      "function":"__c",
      "vtp_value":"11"
    },{
      "function":"__c",
      "vtp_value":"36"
    },{
      "function":"__c",
      "vtp_value":"38"
    },{
      "function":"__c",
      "vtp_value":"37"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"discountAmount"
    },{
      "function":"__c",
      "vtp_value":"41"
    },{
      "function":"__c",
      "vtp_value":"42"
    },{
      "function":"__c",
      "vtp_value":"43"
    },{
      "function":"__c",
      "vtp_value":"151"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"v151"
    },{
      "function":"__c",
      "vtp_value":"152"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"v152"
    },{
      "function":"__c",
      "vtp_value":"153"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"v153"
    },{
      "function":"__c",
      "vtp_value":"154"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"v154"
    },{
      "function":"__c",
      "vtp_value":"155"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"v155"
    },{
      "function":"__c",
      "vtp_value":"156"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"v156"
    },{
      "function":"__c",
      "vtp_value":"39"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dnb1"
    },{
      "function":"__c",
      "vtp_value":"40"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dnb2"
    },{
      "function":"__c",
      "vtp_value":"17"
    },{
      "function":"__c",
      "vtp_value":"44"
    },{
      "function":"__c",
      "vtp_value":"45"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"companyID"
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",21],
      "vtp_defaultValue":"UA-73104404-4",
      "vtp_map":["list",["map","key","production","value","UA-73104404-1"],["map","key","dev","value","UA-73104404-2"]]
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",21],
      "vtp_defaultValue":"UA-73104404-4",
      "vtp_map":["list",["map","key","production","value","UA-73104404-5"],["map","key","dev","value","UA-73104404-6"]]
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",21],
      "vtp_defaultValue":"UA-73104404-4",
      "vtp_map":["list",["map","key","production","value","UA-73104404-7"],["map","key","dev","value","UA-73104404-8"]]
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",14],
      "vtp_defaultValue":"UA-73104404-4",
      "vtp_map":["list",["map","key","ams","value",["macro",141]],["map","key","apj","value",["macro",142]],["map","key","emea","value",["macro",143]]]
    },{
      "function":"__gas",
      "vtp_useDebugVersion":false,
      "vtp_useHashAutoLink":false,
      "vtp_contentGroup":["list",["map","index",["macro",69],"group",["macro",17]],["map","index",["macro",70],"group",["macro",18]],["map","index",["macro",71],"group",["macro",41]],["map","index",["macro",72],"group",["macro",42]],["map","index",["macro",73],"group",["macro",43]]],
      "vtp_decorateFormsAutoLink":false,
      "vtp_cookieDomain":"auto",
      "vtp_useEcommerceDataLayer":true,
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_fieldsToSet":["list",["map","fieldName","page","value",["macro",19]],["map","fieldName","customTask","value",["macro",0]],["map","fieldName","hitCallback","value",["macro",9]]],
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index",["macro",74],"dimension",["macro",13]],["map","index",["macro",75],"dimension",["macro",14]],["map","index",["macro",76],"dimension",["macro",16]],["map","index",["macro",77],"dimension",["macro",15]],["map","index",["macro",78],"dimension",["macro",17]],["map","index",["macro",79],"dimension",["macro",18]],["map","index",["macro",80],"dimension",["macro",41]],["map","index",["macro",81],"dimension",["macro",42]],["map","index",["macro",82],"dimension",["macro",43]],["map","index",["macro",83],"dimension",["macro",44]],["map","index",["macro",84],"dimension",["macro",20]],["map","index",["macro",85],"dimension",["macro",21]],["map","index",["macro",86],"dimension",["macro",87]],["map","index",["macro",88],"dimension",["macro",47]],["map","index",["macro",89],"dimension",["macro",28]],["map","index",["macro",90],"dimension",["macro",23]],["map","index",["macro",91],"dimension",["macro",26]],["map","index",["macro",92],"dimension",["macro",25]],["map","index",["macro",93],"dimension",["macro",24]],["map","index",["macro",94],"dimension",["macro",27]],["map","index",["macro",95],"dimension",["macro",29]],["map","index",["macro",96],"dimension",["macro",30]],["map","index",["macro",97],"dimension",["macro",12]],["map","index",["macro",98],"dimension",["macro",31]],["map","index",["macro",99],"dimension",["macro",100]],["map","index",["macro",101],"dimension",["macro",22]],["map","index",["macro",102],"dimension",["macro",103]],["map","index",["macro",104],"dimension",["macro",60]],["map","index",["macro",105],"dimension",["macro",59]],["map","index",["macro",106],"dimension",["macro",107]],["map","index",["macro",108],"dimension",["macro",109]],["map","index",["macro",110],"dimension",["macro",111]],["map","index",["macro",112],"dimension",["macro",40]],["map","index",["macro",113],"dimension",["macro",19]],["map","index",["macro",114],"dimension",["macro",45]],["map","index",["macro",115],"dimension",["macro",48]],["map","index",["macro",116],"dimension",["macro",117]],["map","index",["macro",118],"dimension",["macro",51]],["map","index",["macro",119],"dimension",["macro",54]],["map","index",["macro",120],"dimension",["macro",57]],["map","index",["macro",121],"dimension",["macro",122]],["map","index",["macro",123],"dimension",["macro",124]],["map","index",["macro",125],"dimension",["macro",126]],["map","index",["macro",127],"dimension",["macro",128]],["map","index",["macro",129],"dimension",["macro",130]],["map","index",["macro",131],"dimension",["macro",132]],["map","index",["macro",133],"dimension",["macro",134]],["map","index",["macro",135],"dimension",["macro",136]],["map","index",["macro",137],"dimension",["macro",0]],["map","index",["macro",138],"dimension",["macro",61]],["map","index",["macro",139],"dimension",["macro",140]]],
      "vtp_enableEcommerce":true,
      "vtp_trackingId":["macro",144],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_ecommerceIsEnabled":true
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"videoAction"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"videoLabel"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"disableScrollTracking"
    },{
      "function":"__c",
      "vtp_value":"1"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"cm25"
    },{
      "function":"__c",
      "vtp_value":"2"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"cm50"
    },{
      "function":"__c",
      "vtp_value":"3"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"cm75"
    },{
      "function":"__c",
      "vtp_value":"4"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"cm100"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"eventAction"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"pageName"
    },{
      "function":"__v",
      "vtp_name":"gtm.triggers",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":""
    },{
      "function":"__aev",
      "vtp_varType":"TEXT"
    },{
      "function":"__u",
      "vtp_component":"URL"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"numSearchResults"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"searchTerm"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"filterCategories"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"filterValue"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"searchSortType"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"linkPlacement"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"linkID"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"couponCode"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"productName"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"concatProductIDs"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"detailsTabName"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"searchCatAndTerm"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"searchResults"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"returnType"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"clickedTerm"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"orderNumber"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"component"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"fieldError"
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",1],
      "vtp_defaultValue":"",
      "vtp_map":["list",["map","key","http:\/\/www.facebook.com\/HP","value","facebook"],["map","key","https:\/\/www.linkedin.com\/company\/hp","value","linkedin"],["map","key","https:\/\/twitter.com\/HP","value","twitter"],["map","key","http:\/\/www.youtube.com\/hp","value","youtube"]]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ecommerce.add.products.0.id"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ecommerce.remove.products.0.id"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"formName"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"shippingMethod"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"id"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"zipCode"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"step"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"action"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"label"
    },{
      "function":"__u",
      "vtp_component":"HOST"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"country"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"region"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"language"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"locale"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"siteType"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"siteSubtype"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"url"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"urlNoQS"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"legacyPageName"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"platform"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"environment"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"recipientID"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"adobeID"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"externalJumpID"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"internalJumpID"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"AOID"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"storeType"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"communityID"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"catalogID"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"siteServ"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"siteVersion"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"segment"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"subSegment"
    },{
      "function":"__c",
      "vtp_value":"25"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"scroll-tracking-data"
    },{
      "function":"__c",
      "vtp_value":"7"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"urlHost"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"urlReferrer"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"codeVersion"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"disableScrollTrack"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"userDeviceType"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"contentPosition"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"contentName"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"menuName"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"menuType"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"configurationType"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"concatComponents"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"sectionType"
    },{
      "function":"__c",
      "vtp_value":"UA-73104404-2"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"searchAutoResults"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"httpErrorCode"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"pageNameNoReferrer"
    },{
      "function":"__u",
      "vtp_component":"PATH"
    },{
      "function":"__f",
      "vtp_component":"URL"
    },{
      "function":"__e"
    },{
      "function":"__v",
      "vtp_name":"gtm.element",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.elementClasses",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.elementClasses",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.elementId",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.elementTarget",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.elementUrl",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.errorMessage",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.errorUrl",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.errorLineNumber",
      "vtp_dataLayerVersion":1
    }],
  "tags":[{
      "function":"__ua",
      "priority":99,
      "once_per_event":true,
      "vtp_overrideGaSettings":false,
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_gaSettings":["macro",145],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "tag_id":1
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"videos",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":["macro",146],
      "vtp_eventLabel":["macro",147],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":4
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":true,
      "vtp_overrideGaSettings":true,
      "vtp_fieldsToSet":["list",["map","fieldName","transport","value","beacon"]],
      "vtp_eventCategory":"scroll depth",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_metric":["list",["map","index",["macro",149],"metric",["macro",150]],["map","index",["macro",151],"metric",["macro",152]],["map","index",["macro",153],"metric",["macro",154]],["map","index",["macro",155],"metric",["macro",156]]],
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":["macro",157],
      "vtp_eventLabel":["macro",158],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":6
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"exit links",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":["macro",1],
      "vtp_eventLabel":["macro",160],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":8
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"account",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"register",
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":9
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"account",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"login",
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":10
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"account",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"mailing list signup",
      "vtp_eventLabel":["macro",161],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":11
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"account",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"email unsubscribe",
      "vtp_eventLabel":["macro",161],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":12
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"search",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":["macro",162],
      "vtp_eventLabel":["macro",163],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":13
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"filter",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":["macro",164],
      "vtp_eventLabel":["macro",165],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":14
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"search",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"sort by",
      "vtp_eventLabel":["macro",166],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":15
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"link clicks",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":["macro",167],
      "vtp_eventLabel":["macro",168],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":18
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"support",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"chat open",
      "vtp_eventLabel":["macro",158],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":19
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"cart",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"coupon applied",
      "vtp_eventLabel":["macro",169],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":20
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"cart",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"coupon error",
      "vtp_eventLabel":["macro",169],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":21
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"product",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"read reviews",
      "vtp_eventLabel":["macro",170],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":22
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"product",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"compare models",
      "vtp_eventLabel":["macro",171],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":26
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"product detail",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":["macro",172],
      "vtp_eventLabel":["macro",170],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":27
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"support",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"business chat open",
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":30
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"supplies",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":["macro",173],
      "vtp_eventLabel":["macro",174],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":32
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"support",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"request a call",
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":34
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"returns and exchanges",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":["macro",175],
      "vtp_eventLabel":["macro",158],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":36
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"search - autofill",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":["macro",176],
      "vtp_eventLabel":["macro",163],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":39
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"customer service",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"order status",
      "vtp_eventLabel":["macro",177],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":40
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"product",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"write review",
      "vtp_eventLabel":["macro",170],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":41
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"configurator",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"change",
      "vtp_eventLabel":["template",["macro",170]," - ",["macro",178]],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":42
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"checkout error",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"change",
      "vtp_eventLabel":["macro",179],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":43
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_overrideGaSettings":false,
      "vtp_trackType":"TRACK_SOCIAL",
      "vtp_socialAction":"visit fan page",
      "vtp_gaSettings":["macro",145],
      "vtp_socialActionTarget":["macro",1],
      "vtp_socialNetwork":["macro",180],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsSocial":true,
      "tag_id":44
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"ecommerce",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"add to cart",
      "vtp_eventLabel":["macro",181],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":45
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"ecommerce",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"remove from cart",
      "vtp_eventLabel":["macro",182],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":46
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"configurator",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"start",
      "vtp_eventLabel":["template",["macro",170]," - ",["macro",178]],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":47
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"configurator",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"complete",
      "vtp_eventLabel":["template",["macro",170]," - ",["macro",178]],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":48
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"downloads",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":["macro",1],
      "vtp_eventLabel":["macro",160],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":55
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"form",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"submitted",
      "vtp_eventLabel":["macro",183],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":63
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"form",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"error",
      "vtp_eventLabel":["macro",183],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":64
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"form",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"start",
      "vtp_eventLabel":["macro",183],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":65
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"internal",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"a\/b test",
      "vtp_eventLabel":["macro",158],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":66
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"shipping method",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":["macro",184],
      "vtp_eventLabel":["template",["macro",185],":",["macro",66],":",["macro",186],":",["macro",187]],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":68
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"Internal",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"demandbase",
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":69
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"internal",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":["macro",188],
      "vtp_eventLabel":["macro",189],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":70
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"internal",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",145],
      "vtp_eventAction":"dnb",
      "vtp_eventLabel":["macro",158],
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":71
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":72
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-TLDHNPR","nickname","India Marketing DEV"]],
      "vtp_boundaries":["list",["zb","_cn",["macro",190],"staging.hpshopping.in",false,false]],
      "vtp_enableTypeRestrictions":true,
      "vtp_whitelistedTypes":["list",["map","typeId","awct"],["map","typeId","gcs"],["map","typeId","ac360"],["map","typeId","flc"],["map","typeId","sp"],["map","typeId","fls"],["map","typeId","ts"],["map","typeId","adm"],["map","typeId","opt"],["map","typeId","gclidw"],["map","typeId","hl"],["map","typeId","sdl"],["map","typeId","fsl"],["map","typeId","cl"],["map","typeId","tl"],["map","typeId","jel"],["map","typeId","ytl"],["map","typeId","lcl"],["map","typeId","evl"],["map","typeId","vis"],["map","typeId","ctv"],["map","typeId","remm"],["map","typeId","smm"],["map","typeId","c"],["map","typeId","d"],["map","typeId","e"],["map","typeId","f"],["map","typeId","j"],["map","typeId","k"],["map","typeId","r"],["map","typeId","u"],["map","typeId","v"],["map","typeId","dbg"],["map","typeId","ev"],["map","typeId","cid"],["map","typeId","aev"],["map","typeId","gas"],["map","typeId","crto"],["map","typeId","k50Init"],["map","typeId","sca"],["map","typeId","bzi"],["map","typeId","uspt"],["map","typeId","okt"],["map","typeId","yieldify"],["map","typeId","dstag"],["map","typeId","cts"],["map","typeId","mpm"],["map","typeId","baut"],["map","typeId","bsa"],["map","typeId","pijs"],["map","typeId","bb"],["map","typeId","omc"],["map","typeId","nudge"],["map","typeId","abtGeneric"],["map","typeId","ta"],["map","typeId","tc"],["map","typeId","sfc"],["map","typeId","svw"],["map","typeId","xpsh"],["map","typeId","sfl"],["map","typeId","infinity"],["map","typeId","asp"],["map","typeId","ll"],["map","typeId","messagemate"],["map","typeId","qca"],["map","typeId","uslt"],["map","typeId","twitter_website_tag"],["map","typeId","ndcr"],["map","typeId","mf"],["map","typeId","qcm"],["map","typeId","html"],["map","typeId","ela"],["map","typeId","vei"],["map","typeId","ms"],["map","typeId","scjs"],["map","typeId","ljs"],["map","typeId","hjtc"],["map","typeId","fxm"],["map","typeId","awc"],["map","typeId","cegg"],["map","typeId","pa"],["map","typeId","shareaholic"],["map","typeId","tdc"],["map","typeId","pc"],["map","typeId","awj"],["map","typeId","csm"],["map","typeId","m6d"],["map","typeId","scp"],["map","typeId","veip"],["map","typeId","mpr"],["map","typeId","placedPixel"],["map","typeId","vdc"],["map","typeId","sfr"],["map","typeId","img"],["map","typeId","tdlc"],["map","typeId","tpdpx"],["map","typeId","tdsc"]],
      "tag_id":75
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-MMFK95","nickname","India Marketing"]],
      "vtp_boundaries":["list",["zb","_cn",["macro",190],"hpshopping.in",false,false],["zb","_cn",["macro",190],"staging",true,false]],
      "vtp_enableTypeRestrictions":true,
      "vtp_whitelistedTypes":["list",["map","typeId","awct"],["map","typeId","gcs"],["map","typeId","ac360"],["map","typeId","flc"],["map","typeId","sp"],["map","typeId","fls"],["map","typeId","ts"],["map","typeId","adm"],["map","typeId","opt"],["map","typeId","gclidw"],["map","typeId","hl"],["map","typeId","sdl"],["map","typeId","fsl"],["map","typeId","cl"],["map","typeId","tl"],["map","typeId","jel"],["map","typeId","ytl"],["map","typeId","lcl"],["map","typeId","evl"],["map","typeId","vis"],["map","typeId","ctv"],["map","typeId","remm"],["map","typeId","smm"],["map","typeId","c"],["map","typeId","d"],["map","typeId","e"],["map","typeId","f"],["map","typeId","j"],["map","typeId","k"],["map","typeId","r"],["map","typeId","u"],["map","typeId","v"],["map","typeId","dbg"],["map","typeId","ev"],["map","typeId","cid"],["map","typeId","aev"],["map","typeId","gas"],["map","typeId","crto"],["map","typeId","k50Init"],["map","typeId","sca"],["map","typeId","bzi"],["map","typeId","uspt"],["map","typeId","okt"],["map","typeId","yieldify"],["map","typeId","dstag"],["map","typeId","cts"],["map","typeId","mpm"],["map","typeId","baut"],["map","typeId","bsa"],["map","typeId","pijs"],["map","typeId","bb"],["map","typeId","omc"],["map","typeId","nudge"],["map","typeId","abtGeneric"],["map","typeId","ta"],["map","typeId","tc"],["map","typeId","sfc"],["map","typeId","svw"],["map","typeId","xpsh"],["map","typeId","sfl"],["map","typeId","infinity"],["map","typeId","asp"],["map","typeId","ll"],["map","typeId","messagemate"],["map","typeId","qca"],["map","typeId","uslt"],["map","typeId","twitter_website_tag"],["map","typeId","ndcr"],["map","typeId","mf"],["map","typeId","qcm"],["map","typeId","html"],["map","typeId","ela"],["map","typeId","vei"],["map","typeId","ms"],["map","typeId","scjs"],["map","typeId","ljs"],["map","typeId","hjtc"],["map","typeId","fxm"],["map","typeId","awc"],["map","typeId","cegg"],["map","typeId","pa"],["map","typeId","shareaholic"],["map","typeId","tdc"],["map","typeId","pc"],["map","typeId","awj"],["map","typeId","csm"],["map","typeId","m6d"],["map","typeId","scp"],["map","typeId","veip"],["map","typeId","mpr"],["map","typeId","placedPixel"],["map","typeId","vdc"],["map","typeId","sfr"],["map","typeId","img"],["map","typeId","tdlc"],["map","typeId","tpdpx"],["map","typeId","tdsc"]],
      "tag_id":76
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-TT8HRS","nickname","Indonesia Marketing"]],
      "vtp_boundaries":["list",["zb","_cn",["macro",190],"hpshopping.id",false,false],["zb","_cn",["macro",190],"staging",true,false]],
      "vtp_enableTypeRestrictions":true,
      "vtp_whitelistedTypes":["list",["map","typeId","awct"],["map","typeId","gcs"],["map","typeId","flc"],["map","typeId","sp"],["map","typeId","fls"],["map","typeId","ts"],["map","typeId","adm"],["map","typeId","opt"],["map","typeId","gclidw"],["map","typeId","hl"],["map","typeId","sdl"],["map","typeId","fsl"],["map","typeId","cl"],["map","typeId","tl"],["map","typeId","jel"],["map","typeId","ytl"],["map","typeId","lcl"],["map","typeId","evl"],["map","typeId","vis"],["map","typeId","ctv"],["map","typeId","remm"],["map","typeId","smm"],["map","typeId","c"],["map","typeId","d"],["map","typeId","e"],["map","typeId","f"],["map","typeId","j"],["map","typeId","k"],["map","typeId","r"],["map","typeId","u"],["map","typeId","v"],["map","typeId","dbg"],["map","typeId","ev"],["map","typeId","cid"],["map","typeId","aev"],["map","typeId","gas"],["map","typeId","ac360"],["map","typeId","crto"],["map","typeId","k50Init"],["map","typeId","sca"],["map","typeId","bzi"],["map","typeId","uspt"],["map","typeId","okt"],["map","typeId","yieldify"],["map","typeId","dstag"],["map","typeId","cts"],["map","typeId","mpm"],["map","typeId","baut"],["map","typeId","bsa"],["map","typeId","pijs"],["map","typeId","bb"],["map","typeId","omc"],["map","typeId","nudge"],["map","typeId","abtGeneric"],["map","typeId","ta"],["map","typeId","tc"],["map","typeId","sfc"],["map","typeId","svw"],["map","typeId","xpsh"],["map","typeId","sfl"],["map","typeId","infinity"],["map","typeId","asp"],["map","typeId","ll"],["map","typeId","messagemate"],["map","typeId","qca"],["map","typeId","uslt"],["map","typeId","twitter_website_tag"],["map","typeId","ndcr"],["map","typeId","mf"],["map","typeId","qcm"],["map","typeId","html"],["map","typeId","ela"],["map","typeId","vei"],["map","typeId","ms"],["map","typeId","scjs"],["map","typeId","ljs"],["map","typeId","hjtc"],["map","typeId","fxm"],["map","typeId","awc"],["map","typeId","cegg"],["map","typeId","pa"],["map","typeId","shareaholic"],["map","typeId","tdc"],["map","typeId","pc"],["map","typeId","awj"],["map","typeId","csm"],["map","typeId","m6d"],["map","typeId","scp"],["map","typeId","veip"],["map","typeId","mpr"],["map","typeId","placedPixel"],["map","typeId","vdc"],["map","typeId","sfr"],["map","typeId","img"],["map","typeId","tdlc"],["map","typeId","tpdpx"],["map","typeId","tdsc"]],
      "tag_id":77
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-MT85W9K","nickname","Indonesia Marketing Dev"]],
      "vtp_boundaries":["list",["zb","_cn",["macro",190],"staging.hpshopping.id",false,false]],
      "vtp_enableTypeRestrictions":true,
      "vtp_whitelistedTypes":["list",["map","typeId","awct"],["map","typeId","gcs"],["map","typeId","ac360"],["map","typeId","flc"],["map","typeId","sp"],["map","typeId","fls"],["map","typeId","ts"],["map","typeId","adm"],["map","typeId","opt"],["map","typeId","gclidw"],["map","typeId","hl"],["map","typeId","sdl"],["map","typeId","fsl"],["map","typeId","cl"],["map","typeId","tl"],["map","typeId","jel"],["map","typeId","ytl"],["map","typeId","lcl"],["map","typeId","evl"],["map","typeId","vis"],["map","typeId","ctv"],["map","typeId","remm"],["map","typeId","smm"],["map","typeId","c"],["map","typeId","d"],["map","typeId","e"],["map","typeId","f"],["map","typeId","j"],["map","typeId","k"],["map","typeId","r"],["map","typeId","u"],["map","typeId","v"],["map","typeId","dbg"],["map","typeId","ev"],["map","typeId","cid"],["map","typeId","aev"],["map","typeId","gas"],["map","typeId","crto"],["map","typeId","k50Init"],["map","typeId","sca"],["map","typeId","bzi"],["map","typeId","uspt"],["map","typeId","okt"],["map","typeId","yieldify"],["map","typeId","dstag"],["map","typeId","cts"],["map","typeId","mpm"],["map","typeId","baut"],["map","typeId","bsa"],["map","typeId","pijs"],["map","typeId","bb"],["map","typeId","omc"],["map","typeId","nudge"],["map","typeId","abtGeneric"],["map","typeId","ta"],["map","typeId","tc"],["map","typeId","sfc"],["map","typeId","svw"],["map","typeId","xpsh"],["map","typeId","sfl"],["map","typeId","infinity"],["map","typeId","asp"],["map","typeId","ll"],["map","typeId","messagemate"],["map","typeId","qca"],["map","typeId","uslt"],["map","typeId","twitter_website_tag"],["map","typeId","ndcr"],["map","typeId","mf"],["map","typeId","qcm"],["map","typeId","html"],["map","typeId","ela"],["map","typeId","vei"],["map","typeId","ms"],["map","typeId","scjs"],["map","typeId","ljs"],["map","typeId","hjtc"],["map","typeId","fxm"],["map","typeId","awc"],["map","typeId","cegg"],["map","typeId","pa"],["map","typeId","shareaholic"],["map","typeId","tdc"],["map","typeId","pc"],["map","typeId","awj"],["map","typeId","csm"],["map","typeId","m6d"],["map","typeId","scp"],["map","typeId","veip"],["map","typeId","mpr"],["map","typeId","placedPixel"],["map","typeId","vdc"],["map","typeId","sfr"],["map","typeId","img"],["map","typeId","tdlc"],["map","typeId","tpdpx"],["map","typeId","tdsc"]],
      "tag_id":78
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-MB3LLQ","nickname","Thailand Marketing"]],
      "vtp_boundaries":["list",["zb","_cn",["macro",190],"hpstorethailand.com",false,false],["zb","_cn",["macro",190],"staging",true,false]],
      "vtp_enableTypeRestrictions":true,
      "vtp_whitelistedTypes":["list",["map","typeId","awct"],["map","typeId","gcs"],["map","typeId","flc"],["map","typeId","sp"],["map","typeId","fls"],["map","typeId","ts"],["map","typeId","adm"],["map","typeId","opt"],["map","typeId","gclidw"],["map","typeId","hl"],["map","typeId","sdl"],["map","typeId","fsl"],["map","typeId","cl"],["map","typeId","tl"],["map","typeId","jel"],["map","typeId","ytl"],["map","typeId","lcl"],["map","typeId","evl"],["map","typeId","vis"],["map","typeId","ctv"],["map","typeId","remm"],["map","typeId","smm"],["map","typeId","c"],["map","typeId","d"],["map","typeId","e"],["map","typeId","f"],["map","typeId","j"],["map","typeId","k"],["map","typeId","r"],["map","typeId","u"],["map","typeId","v"],["map","typeId","dbg"],["map","typeId","ev"],["map","typeId","cid"],["map","typeId","aev"],["map","typeId","gas"],["map","typeId","ac360"],["map","typeId","crto"],["map","typeId","k50Init"],["map","typeId","sca"],["map","typeId","bzi"],["map","typeId","uspt"],["map","typeId","okt"],["map","typeId","yieldify"],["map","typeId","dstag"],["map","typeId","cts"],["map","typeId","mpm"],["map","typeId","baut"],["map","typeId","bsa"],["map","typeId","pijs"],["map","typeId","bb"],["map","typeId","omc"],["map","typeId","nudge"],["map","typeId","abtGeneric"],["map","typeId","ta"],["map","typeId","tc"],["map","typeId","sfc"],["map","typeId","svw"],["map","typeId","xpsh"],["map","typeId","sfl"],["map","typeId","infinity"],["map","typeId","asp"],["map","typeId","ll"],["map","typeId","messagemate"],["map","typeId","qca"],["map","typeId","uslt"],["map","typeId","twitter_website_tag"],["map","typeId","ndcr"],["map","typeId","mf"],["map","typeId","qcm"],["map","typeId","html"],["map","typeId","ela"],["map","typeId","vei"],["map","typeId","ms"],["map","typeId","scjs"],["map","typeId","ljs"],["map","typeId","hjtc"],["map","typeId","fxm"],["map","typeId","awc"],["map","typeId","cegg"],["map","typeId","pa"],["map","typeId","shareaholic"],["map","typeId","tdc"],["map","typeId","pc"],["map","typeId","awj"],["map","typeId","csm"],["map","typeId","m6d"],["map","typeId","scp"],["map","typeId","veip"],["map","typeId","mpr"],["map","typeId","placedPixel"],["map","typeId","vdc"],["map","typeId","sfr"],["map","typeId","img"],["map","typeId","tdlc"],["map","typeId","tpdpx"],["map","typeId","tdsc"]],
      "tag_id":79
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-MV6HMFH","nickname","Thailand Marketing Dev"]],
      "vtp_boundaries":["list",["zb","_cn",["macro",190],"staging.hpstorethailand.com",false,false]],
      "vtp_enableTypeRestrictions":true,
      "vtp_whitelistedTypes":["list",["map","typeId","awct"],["map","typeId","gcs"],["map","typeId","ac360"],["map","typeId","flc"],["map","typeId","sp"],["map","typeId","fls"],["map","typeId","ts"],["map","typeId","adm"],["map","typeId","opt"],["map","typeId","gclidw"],["map","typeId","hl"],["map","typeId","sdl"],["map","typeId","fsl"],["map","typeId","cl"],["map","typeId","tl"],["map","typeId","jel"],["map","typeId","ytl"],["map","typeId","lcl"],["map","typeId","evl"],["map","typeId","vis"],["map","typeId","ctv"],["map","typeId","remm"],["map","typeId","smm"],["map","typeId","c"],["map","typeId","d"],["map","typeId","e"],["map","typeId","f"],["map","typeId","j"],["map","typeId","k"],["map","typeId","r"],["map","typeId","u"],["map","typeId","v"],["map","typeId","dbg"],["map","typeId","ev"],["map","typeId","cid"],["map","typeId","aev"],["map","typeId","gas"],["map","typeId","crto"],["map","typeId","k50Init"],["map","typeId","sca"],["map","typeId","bzi"],["map","typeId","uspt"],["map","typeId","okt"],["map","typeId","yieldify"],["map","typeId","dstag"],["map","typeId","cts"],["map","typeId","mpm"],["map","typeId","baut"],["map","typeId","bsa"],["map","typeId","pijs"],["map","typeId","bb"],["map","typeId","omc"],["map","typeId","nudge"],["map","typeId","abtGeneric"],["map","typeId","ta"],["map","typeId","tc"],["map","typeId","sfc"],["map","typeId","svw"],["map","typeId","xpsh"],["map","typeId","sfl"],["map","typeId","infinity"],["map","typeId","asp"],["map","typeId","ll"],["map","typeId","messagemate"],["map","typeId","qca"],["map","typeId","uslt"],["map","typeId","twitter_website_tag"],["map","typeId","ndcr"],["map","typeId","mf"],["map","typeId","qcm"],["map","typeId","html"],["map","typeId","ela"],["map","typeId","vei"],["map","typeId","ms"],["map","typeId","scjs"],["map","typeId","ljs"],["map","typeId","hjtc"],["map","typeId","fxm"],["map","typeId","awc"],["map","typeId","cegg"],["map","typeId","pa"],["map","typeId","shareaholic"],["map","typeId","tdc"],["map","typeId","pc"],["map","typeId","awj"],["map","typeId","csm"],["map","typeId","m6d"],["map","typeId","scp"],["map","typeId","veip"],["map","typeId","mpr"],["map","typeId","placedPixel"],["map","typeId","vdc"],["map","typeId","sfr"],["map","typeId","img"],["map","typeId","tdlc"],["map","typeId","tpdpx"],["map","typeId","tdsc"]],
      "tag_id":80
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-525RNQ4","nickname",""]],
      "vtp_boundaries":["list",["zb","_cn",["macro",190],"hpshopping.hk",false,false],["zb","_cn",["macro",190],"staging",true,false]],
      "vtp_enableTypeRestrictions":true,
      "vtp_whitelistedTypes":["list",["map","typeId","awct"],["map","typeId","gcs"],["map","typeId","ac360"],["map","typeId","flc"],["map","typeId","sp"],["map","typeId","fls"],["map","typeId","ts"],["map","typeId","adm"],["map","typeId","opt"],["map","typeId","gclidw"],["map","typeId","hl"],["map","typeId","sdl"],["map","typeId","fsl"],["map","typeId","cl"],["map","typeId","tl"],["map","typeId","jel"],["map","typeId","ytl"],["map","typeId","lcl"],["map","typeId","evl"],["map","typeId","vis"],["map","typeId","ctv"],["map","typeId","remm"],["map","typeId","smm"],["map","typeId","c"],["map","typeId","d"],["map","typeId","e"],["map","typeId","f"],["map","typeId","j"],["map","typeId","k"],["map","typeId","r"],["map","typeId","u"],["map","typeId","v"],["map","typeId","dbg"],["map","typeId","ev"],["map","typeId","cid"],["map","typeId","aev"],["map","typeId","gas"],["map","typeId","crto"],["map","typeId","k50Init"],["map","typeId","sca"],["map","typeId","bzi"],["map","typeId","uspt"],["map","typeId","okt"],["map","typeId","yieldify"],["map","typeId","dstag"],["map","typeId","cts"],["map","typeId","mpm"],["map","typeId","baut"],["map","typeId","bsa"],["map","typeId","pijs"],["map","typeId","bb"],["map","typeId","omc"],["map","typeId","nudge"],["map","typeId","abtGeneric"],["map","typeId","ta"],["map","typeId","tc"],["map","typeId","sfc"],["map","typeId","svw"],["map","typeId","xpsh"],["map","typeId","sfl"],["map","typeId","infinity"],["map","typeId","asp"],["map","typeId","ll"],["map","typeId","messagemate"],["map","typeId","qca"],["map","typeId","uslt"],["map","typeId","twitter_website_tag"],["map","typeId","ndcr"],["map","typeId","mf"],["map","typeId","qcm"],["map","typeId","html"],["map","typeId","ela"],["map","typeId","vei"],["map","typeId","ms"],["map","typeId","scjs"],["map","typeId","ljs"],["map","typeId","hjtc"],["map","typeId","fxm"],["map","typeId","awc"],["map","typeId","cegg"],["map","typeId","pa"],["map","typeId","shareaholic"],["map","typeId","tdc"],["map","typeId","pc"],["map","typeId","awj"],["map","typeId","csm"],["map","typeId","m6d"],["map","typeId","scp"],["map","typeId","veip"],["map","typeId","mpr"],["map","typeId","placedPixel"],["map","typeId","vdc"],["map","typeId","sfr"],["map","typeId","img"],["map","typeId","tdlc"],["map","typeId","tpdpx"],["map","typeId","tdsc"]],
      "tag_id":81
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-P6X398R","nickname","WW Digital Mkt - U.S. Store"]],
      "vtp_boundaries":["list",["zb","_eq",["macro",62],"true",false,false]],
      "vtp_enableTypeRestrictions":true,
      "vtp_whitelistedTypes":["list",["map","typeId","awct"],["map","typeId","gcs"],["map","typeId","ac360"],["map","typeId","flc"],["map","typeId","sp"],["map","typeId","fls"],["map","typeId","ts"],["map","typeId","adm"],["map","typeId","opt"],["map","typeId","gclidw"],["map","typeId","hl"],["map","typeId","sdl"],["map","typeId","fsl"],["map","typeId","cl"],["map","typeId","tl"],["map","typeId","jel"],["map","typeId","ytl"],["map","typeId","lcl"],["map","typeId","evl"],["map","typeId","vis"],["map","typeId","ctv"],["map","typeId","remm"],["map","typeId","smm"],["map","typeId","c"],["map","typeId","d"],["map","typeId","e"],["map","typeId","f"],["map","typeId","j"],["map","typeId","k"],["map","typeId","r"],["map","typeId","u"],["map","typeId","v"],["map","typeId","dbg"],["map","typeId","ev"],["map","typeId","cid"],["map","typeId","aev"],["map","typeId","gas"],["map","typeId","crto"],["map","typeId","k50Init"],["map","typeId","sca"],["map","typeId","bzi"],["map","typeId","uspt"],["map","typeId","okt"],["map","typeId","yieldify"],["map","typeId","dstag"],["map","typeId","cts"],["map","typeId","mpm"],["map","typeId","baut"],["map","typeId","bsa"],["map","typeId","pijs"],["map","typeId","bb"],["map","typeId","omc"],["map","typeId","nudge"],["map","typeId","abtGeneric"],["map","typeId","ta"],["map","typeId","tc"],["map","typeId","sfc"],["map","typeId","svw"],["map","typeId","xpsh"],["map","typeId","sfl"],["map","typeId","infinity"],["map","typeId","asp"],["map","typeId","ll"],["map","typeId","messagemate"],["map","typeId","qca"],["map","typeId","uslt"],["map","typeId","twitter_website_tag"],["map","typeId","ndcr"],["map","typeId","mf"],["map","typeId","qcm"],["map","typeId","html"],["map","typeId","ela"],["map","typeId","vei"],["map","typeId","ms"],["map","typeId","scjs"],["map","typeId","ljs"],["map","typeId","hjtc"],["map","typeId","fxm"],["map","typeId","awc"],["map","typeId","cegg"],["map","typeId","pa"],["map","typeId","shareaholic"],["map","typeId","tdc"],["map","typeId","pc"],["map","typeId","awj"],["map","typeId","csm"],["map","typeId","m6d"],["map","typeId","scp"],["map","typeId","veip"],["map","typeId","mpr"],["map","typeId","placedPixel"],["map","typeId","vdc"],["map","typeId","sfr"],["map","typeId","img"],["map","typeId","tdlc"],["map","typeId","tpdpx"],["map","typeId","tdsc"]],
      "tag_id":82
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-KHWBPWB","nickname","WW Digital Mkt - APJ Magento Stores"]],
      "vtp_boundaries":["list",["zb","_eq",["macro",64],"true",false,false]],
      "vtp_enableTypeRestrictions":true,
      "vtp_whitelistedTypes":["list",["map","typeId","awct"],["map","typeId","gcs"],["map","typeId","ac360"],["map","typeId","flc"],["map","typeId","sp"],["map","typeId","fls"],["map","typeId","ts"],["map","typeId","adm"],["map","typeId","opt"],["map","typeId","gclidw"],["map","typeId","hl"],["map","typeId","sdl"],["map","typeId","fsl"],["map","typeId","cl"],["map","typeId","tl"],["map","typeId","jel"],["map","typeId","ytl"],["map","typeId","lcl"],["map","typeId","evl"],["map","typeId","vis"],["map","typeId","ctv"],["map","typeId","remm"],["map","typeId","smm"],["map","typeId","c"],["map","typeId","d"],["map","typeId","e"],["map","typeId","f"],["map","typeId","j"],["map","typeId","k"],["map","typeId","r"],["map","typeId","u"],["map","typeId","v"],["map","typeId","dbg"],["map","typeId","ev"],["map","typeId","cid"],["map","typeId","aev"],["map","typeId","gas"],["map","typeId","crto"],["map","typeId","k50Init"],["map","typeId","sca"],["map","typeId","bzi"],["map","typeId","uspt"],["map","typeId","okt"],["map","typeId","yieldify"],["map","typeId","dstag"],["map","typeId","cts"],["map","typeId","mpm"],["map","typeId","baut"],["map","typeId","bsa"],["map","typeId","pijs"],["map","typeId","bb"],["map","typeId","omc"],["map","typeId","nudge"],["map","typeId","abtGeneric"],["map","typeId","ta"],["map","typeId","tc"],["map","typeId","sfc"],["map","typeId","svw"],["map","typeId","xpsh"],["map","typeId","sfl"],["map","typeId","infinity"],["map","typeId","asp"],["map","typeId","ll"],["map","typeId","messagemate"],["map","typeId","qca"],["map","typeId","uslt"],["map","typeId","twitter_website_tag"],["map","typeId","ndcr"],["map","typeId","mf"],["map","typeId","qcm"],["map","typeId","html"],["map","typeId","ela"],["map","typeId","vei"],["map","typeId","ms"],["map","typeId","scjs"],["map","typeId","ljs"],["map","typeId","hjtc"],["map","typeId","fxm"],["map","typeId","awc"],["map","typeId","cegg"],["map","typeId","pa"],["map","typeId","shareaholic"],["map","typeId","tdc"],["map","typeId","pc"],["map","typeId","awj"],["map","typeId","csm"],["map","typeId","m6d"],["map","typeId","scp"],["map","typeId","veip"],["map","typeId","mpr"],["map","typeId","placedPixel"],["map","typeId","vdc"],["map","typeId","sfr"],["map","typeId","img"],["map","typeId","tdlc"],["map","typeId","tpdpx"],["map","typeId","tdsc"]],
      "tag_id":83
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-PDHM2PK","nickname","WW Digital Mkt - WW Marketing pages"]],
      "vtp_boundaries":["list",["zb","_eq",["macro",63],"true",false,false]],
      "vtp_enableTypeRestrictions":true,
      "vtp_whitelistedTypes":["list",["map","typeId","awct"],["map","typeId","gcs"],["map","typeId","ac360"],["map","typeId","flc"],["map","typeId","sp"],["map","typeId","fls"],["map","typeId","ts"],["map","typeId","adm"],["map","typeId","opt"],["map","typeId","gclidw"],["map","typeId","hl"],["map","typeId","sdl"],["map","typeId","fsl"],["map","typeId","cl"],["map","typeId","tl"],["map","typeId","jel"],["map","typeId","ytl"],["map","typeId","lcl"],["map","typeId","evl"],["map","typeId","vis"],["map","typeId","ctv"],["map","typeId","remm"],["map","typeId","smm"],["map","typeId","c"],["map","typeId","d"],["map","typeId","e"],["map","typeId","f"],["map","typeId","j"],["map","typeId","k"],["map","typeId","r"],["map","typeId","u"],["map","typeId","v"],["map","typeId","dbg"],["map","typeId","ev"],["map","typeId","cid"],["map","typeId","aev"],["map","typeId","gas"],["map","typeId","crto"],["map","typeId","k50Init"],["map","typeId","sca"],["map","typeId","bzi"],["map","typeId","uspt"],["map","typeId","okt"],["map","typeId","yieldify"],["map","typeId","dstag"],["map","typeId","cts"],["map","typeId","mpm"],["map","typeId","baut"],["map","typeId","bsa"],["map","typeId","pijs"],["map","typeId","bb"],["map","typeId","omc"],["map","typeId","nudge"],["map","typeId","abtGeneric"],["map","typeId","ta"],["map","typeId","tc"],["map","typeId","sfc"],["map","typeId","svw"],["map","typeId","xpsh"],["map","typeId","sfl"],["map","typeId","infinity"],["map","typeId","asp"],["map","typeId","ll"],["map","typeId","messagemate"],["map","typeId","qca"],["map","typeId","uslt"],["map","typeId","twitter_website_tag"],["map","typeId","ndcr"],["map","typeId","mf"],["map","typeId","qcm"],["map","typeId","html"],["map","typeId","ela"],["map","typeId","vei"],["map","typeId","ms"],["map","typeId","scjs"],["map","typeId","ljs"],["map","typeId","hjtc"],["map","typeId","fxm"],["map","typeId","awc"],["map","typeId","cegg"],["map","typeId","pa"],["map","typeId","shareaholic"],["map","typeId","tdc"],["map","typeId","pc"],["map","typeId","awj"],["map","typeId","csm"],["map","typeId","m6d"],["map","typeId","scp"],["map","typeId","veip"],["map","typeId","mpr"],["map","typeId","placedPixel"],["map","typeId","vdc"],["map","typeId","sfr"],["map","typeId","img"],["map","typeId","tdlc"],["map","typeId","tpdpx"],["map","typeId","tdsc"]],
      "tag_id":84
    },{
      "function":"__lcl",
      "vtp_waitForTags":true,
      "vtp_checkValidation":true,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"7314507_35",
      "tag_id":85
    },{
      "function":"__lcl",
      "vtp_waitForTags":true,
      "vtp_checkValidation":true,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"7314507_36",
      "tag_id":86
    },{
      "function":"__lcl",
      "vtp_waitForTags":true,
      "vtp_checkValidation":true,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"7314507_37",
      "tag_id":87
    },{
      "function":"__lcl",
      "vtp_waitForTags":true,
      "vtp_checkValidation":true,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"7314507_38",
      "tag_id":88
    },{
      "function":"__lcl",
      "vtp_waitForTags":true,
      "vtp_checkValidation":true,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"7314507_39",
      "tag_id":89
    },{
      "function":"__jel",
      "tag_id":90
    },{
      "function":"__evl",
      "vtp_useOnScreenDuration":false,
      "vtp_useDomChangeListener":true,
      "vtp_elementSelector":".video-overlay",
      "vtp_firingFrequency":"MANY_PER_ELEMENT",
      "vtp_selectorType":"CSS",
      "vtp_onScreenRatio":"10",
      "vtp_uniqueTriggerId":"7314507_312",
      "tag_id":91
    },{
      "function":"__html",
      "setup_tags":["list",["tag",63,1]],
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003E(function(){function q(){}function h(a,b,c){dataLayer.push({event:\"e_error\",error:{name:a,message:c+\": \"+b}})}function r(){try{var a='iframe[src*\\x3d\"youtube\"] { visibility: hidden; opacity: 0; } iframe[src*\\x3d\"youtube\"][ythide] { visibility: hidden!important; opacity: 0!important; } iframe[src*\\x3d\"enablejsapi\"] { visibility: visible; opacity: 100; }',b=document.head||document.getElementsByTagName(\"head\")[0],c=document.createElement(\"style\");c.type=\"text\/css\";c.styleSheet?c.styleSheet.cssText=a:\nc.appendChild(document.createTextNode(a));b.appendChild(c)}catch(e){h(e.name,e.message,\"yt.addYTCSS\")}}function t(a){try{var b=a.getAttribute(\"src\"),c=\/enablejsapi\/i,e=!1;var f=document.createElement(\"a\");f.href=b;var d=f.search;c.test(d)||(d=(0\u003Cd.length?d+\"\\x26\":\"?\")+\"enablejsapi\\x3d1\",f.search=d,e=!0);for(;1\u003Cd.lastIndexOf(\"?\");)e=!0,idx=d.lastIndexOf(\"?\"),d=\"\\x26\"!=d.charAt(idx+1)?d.substring(0,idx)+\"\\x26\"+d.substring(idx+1):d.substring(0,idx)+d.substring(idx+1);f.search=d;\"youtube.com\"==f.hostname\u0026\u0026\n(f.hostname=\"www.youtube.com\",e=!0);e?(a.setAttribute(\"ythide\",\"true\"),a.setAttribute(\"src\",f.href),setTimeout(function(){a.removeAttribute(\"ythide\")},1E3)):a.removeAttribute(\"ythide\");return e}catch(g){h(g.name,g.message,\"yt.enableJSAPI\")}}function k(a){try{var b,c,e,f=a.getAttribute(\"src\");var d=f,g=\/youtube\\.com\\\/(?:embed|v)\\\/([^?]*)\/,k=\"\";if(\"string\"==typeof d){var l=d.match(g);d\u0026\u0026(l=d.match(g))\u0026\u0026(k=l[1])}var m=k;if(!t(a)){if(b=YT.get(a.id)){for(c in b)if(\"object\"==typeof b[c]\u0026\u0026null!=b[c]\u0026\u0026\"boolean\"==\ntypeof b[c].onStateChange)for(e in b[c])b[c][e]=!1;b.addEventListener(\"onStateChange\",q)}else b=new YT.Player(a);b.analytics||(b.addEventListener(\"onStateChange\",u),b.addEventListener(\"onError\",v));b.analytics\u0026\u0026b.analytics.src==f||(b.analytics={lastAction:\"p\",videoId:m})}}catch(n){h(n.name,n.message,\"yt.attachEvents\")}}function l(a){a=a.src||\"\";var b=\/youtube.com\\\/(embed|v)\/i;return b.test(a)}function w(){var a,b=document.getElementsByTagName(\"iframe\");for(a=0;a\u003Cb.length;++a){var c=b[a];l(c)\u0026\u0026k(c)}}\nfunction x(){\"undefined\"!=typeof YT\u0026\u0026YT.loaded\u0026\u0026(clearInterval(y),navigator.userAgent.match(\/MSIE [67]\\.\/gi)||(\"loading\"!==document.readyState?m():(document.addEventListener?(elem=window,evt=\"load\"):(elem=document,evt=\"DOMContentLoaded\"),",["escape",["macro",67],8,16],"(elem,evt,m))))}function m(){r();w();\"addEventListener\"in document\u0026\u0026document.addEventListener(\"load\",function(a){a=a.target||a.srcElement;\"IFRAME\"===a.tagName\u0026\u0026l(a)\u0026\u0026k(a)},!0)}function u(a){try{var b=a.data,c=a.target,e=c.getVideoData();b==YT.PlayerState.PLAYING\u0026\u0026\nsetTimeout(p,1E3,c);b==YT.PlayerState.PLAYING\u0026\u0026\"p\"==c.analytics.lastAction\u0026\u0026(dataLayer.push({event:\"e_video\",videoAction:\"play\",videoLabel:e.title}),c.analytics.lastAction=\"\");b==YT.PlayerState.PAUSED\u0026\u0026\"p\"!=c.analytics.lastAction\u0026\u0026(dataLayer.push({event:\"e_video\",videoAction:\"pause\",videoLabel:e.title}),c.analytics.lastAction=\"p\")}catch(f){h(f.name,f.message,\"yt.onPlayerStateChange\")}}function v(a){var b=a.data;a=a.target;h(youtube,a.src+\"-\"+b,\"yt.onPlayerError\")}function p(a){try{var b=a.getVideoData(),\nc=a.getDuration(),e=a.getCurrentTime(),f=a.getPlayerState();if(f==YT.PlayerState.PLAYING){var d=1.5\u003E=c-e?1:(Math.floor(e\/c*4)\/4).toFixed(2);if(!a.lastP||d\u003Ea.lastP)try{0!=100*d\u0026\u0026(a.lastP=d,dataLayer.push({event:\"e_video\",videoAction:100*d+\"% viewed\",videoLabel:b.title}))}catch(g){}1!=a.lastP\u0026\u0026setTimeout(p,1E3,a)}}catch(g){h(youtube,a.src+\"-\"+data,\"yt.onPlayerPercent\")}}var y=setInterval(x,100);(function(){var a=document.createElement(\"script\"),b=document.getElementsByTagName(\"script\")[0];a.src=\"\/\/www.youtube.com\/iframe_api\";\na.async=!0;b.parentNode.insertBefore(a,b)})()})();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":3
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E(function(){var n=function(){function k(a,b,c){a.attachEvent?(a[\"e\"+b+c]=c,a[b+c]=function(){a[\"e\"+b+c](window.event)},a.attachEvent(\"on\"+b,a[b+c])):a.addEventListener(b,c,!1)}function p(){e=Math.max(((window.pageYOffset||document.body.scrollTop||f.scrollTop||0)+(window.innerHeight||f.clientHeight||document.body.clientHeight||0))\/Math.max(document.body.scrollHeight||0,f.scrollHeight||0,document.body.offsetHeight||0,f.offsetHeight||0,document.body.clientHeight||0,f.clientHeight||0)*100,e);var a=(e\u003E\nl?1:0)*Math.floor(e\/l)*l;95\u003Ce\u0026\u0026(a=100);if(a\u003Eq){q=e;if(100==a){var b=window,c=\"scroll\",d=p;b.detachEvent?(b.detachEvent(\"on\"+c,b[c+d]),b[c+d]=null):b.removeEventListener(c,d,!1)}\"undefined\"!==typeof dataLayer\u0026\u0026(g=a)}}function n(){var a=m.indexOf(g);if(0\u003C=a){a=m.indexOf(g);for(i=0;i\u003C=a;i++)d[h[\"data_layer_milestone_\"+m[i]]]=1;d.event=h.data_layer_event_value;d.eventCategory=h.data_layer_category_value;d.eventAction=g+\"% scrolled\";d.eventLabel=document.location.pathname;dataLayer.push(d);console.log(d)}}\nvar h={data_layer_event_value:\"scrollEvent\",data_layer_category_value:\"scroll tracking\",percentage_threshold:60,data_layer_milestone_25:\"cm25\",data_layer_milestone_50:\"cm50\",data_layer_milestone_75:\"cm75\",data_layer_milestone_100:\"cm100\"},g,l=25,m=[25,50,75,100],f=document.documentElement,q=0,e=0,d={};return{init:function(){Math.round(window.innerHeight\/document.documentElement.scrollHeight*100)\u003Ch.percentage_threshold\u0026\u0026(k(window,\"scroll\",p),k(window,\"unload\",n));return!0}}}();try{n.init()}catch(k){}})();\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":35
    },{
      "function":"__html",
      "teardown_tags":["list",["tag",64,2]],
      "once_per_load":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E!function(){var d=window;d._A\u0026\u0026\"object\"==typeof d._A\u0026\u0026d._A.constructor!=Array||(console.log(\"_A Framework v2.16\",\"18.09.06b via GTM\"),d._A=function(){var d=\"s\",e=this,k=window,r=document,D=r.location,q=!0,w=!1,m=\"\",t=\"length\",W=\"string\",L=\"number\",Q=\"object\",M=\"array\",T=\"boolean\",R=\"function\",la=\"null\",aa=\"undefined\",fa=\"_A ERROR\",z=fa+\" in\",ha=function(a){var b;try{(b=null===a?la:typeof a)==Q\u0026\u0026typeof a[t]==L\u0026\u0026(b=M)}catch(g){b=aa}return b},ba=function(a){return null===a},C=function(a){return typeof a==\naa},I=function(a){try{return typeof a==L\u0026\u0026!isNaN(a)}catch(b){return w}},A=function(a){return typeof a==W},S=function(a){return typeof a==T},B=function(a){return null!==a\u0026\u0026typeof a==Q},ca=function(a){try{return null!==a\u0026\u0026typeof a==Q\u0026\u0026a.constructor===Array}catch(b){return w}},J=function(a){try{return null!==a\u0026\u0026typeof a==Q\u0026\u0026a.constructor!==Array}catch(b){return w}},K=function(a){return typeof a==R},da=function(a){try{return a instanceof RegExp}catch(b){return w}},N=function(a){try{return a instanceof\nDate}catch(b){return w}},X=function(a,b){try{A(b)\u0026\u0026(b=\"lc\"==b?-1:\"uc\"==b?1:0),I(b)||(b=b?1:0),a=A(a)||I(a)||N(a)||S(a)?a+m:\"\",a=A(a)?0\u003Eb?a.toLowerCase(a):0\u003Cb?a.toUpperCase(a):a:\"\"}catch(g){a=\"\"}return a},F=function(a){return X(a,\"lc\")},u=function(a){return X(a,\"uc\")},db=function(a){if(A(a)){for(var b=0,g=\" \",l=\"\",p;b\u003Ca[t];b++)p=a[b],l+=\"a\"\u003C=g\u0026\u0026\"z\"\u003E=g||\"0\"\u003C=g\u0026\u0026\"9\"\u003E=g?p.toLowerCase():p.toUpperCase(),\"'\"!=p\u0026\u0026(g=p.toLowerCase());return l}return a},Oa=function(a){var b,g;if(J(a))for(g in b=0,a)b++;else b=\nC(a)?-1:ca(a)?a[t]:1;return b},ea=function(a,b,g){var l=-1,p=0;try{if(a=a?a+m:m,g=g||0,A(b))l=a.indexOf(b,g);else if(ca(b))for(;p\u003Cb[t]\u0026\u00260\u003El;p++)-1\u003Ca.indexOf(b[p],g)\u0026\u0026(l=p)}catch(U){}return l},Pa=function(a){try{a||(a=m),a=a.replace(\/^\\s+\/g,m).replace(\/\\s+$\/g,m).replace(\/\\s+\/g,\" \")}catch(b){}return a},eb=function(a,b,g,l){b=b||\":,\";a=A(a)?a:\"\";l=\"\";var p=new RegExp(\"[\"+b.replace(\"[\",\"\\\\[\").replace(\"]\",\"\\\\]\")+\"]\",\"g\");if(a=a.replace(\/^\\s+\/,\"\").replace(\/\\s+$\/,\"\"),0\u003Eb.indexOf(\";\")||!p.test(a))l=a.replace(p,\n\";\");else for(p=0;p\u003Ca[t];p++)l+=-1\u003Cb.indexOf(a[p])?escape(a[p]):a[p];return g?F(l):l},Aa=function(a,b,g){var l,p,U=function(a){var b=a.split(\"\\x3d\");return 0\u003Cb.length?b[0]:a},y=function(a){for(var b=0;b\u003Ca;b++)p==U(l[b])\u0026\u0026(l[b]=\"\")};if(a=a?a+\",\"+b:b,g){var e=(l=a.split(\",\")).length;-1==g\u0026\u0026(p=U(b),y(e));for(b=e-1;0\u003C=b;b--){var d=l[b];p=U(d);y(b)}a=\"\";for(b=0;b\u003Ce;b++)(d=l[b])\u0026\u0026(a=a?a+\",\"+d:d)}return a},Ba=function(a,b,g){var l,p=NaN,e=1,y=0,d=0,k=b?1E306:1E14;if(I(a))return b?a:Math.round(a);if(J(a)\u0026\u0026\n(a+=m),!a||!A(a))return NaN;for(;g\u0026\u0026y\u003Ca[t]\u0026\u0026!(\" \"\u003Ca.substring(y,y+1));y++);var h=a.substring(y,y+1);d||\"+\"!=h||y++;d||\"-\"!=h||(e=-1,y++);for(b\u0026\u0026!d\u0026\u0026\".\"==h\u0026\u0026(d=1,y++);y\u003Ca[t];y++)if(h=a.substring(y,y+1),l=ea(\"0123456789\",h),b\u0026\u0026\".\"==h\u0026\u0026!d)d=1;else{if(0\u003El)return g?e*p:NaN;if(k\u003Cp)return NaN;isNaN(p)\u0026\u0026(p=0);d?p+=l*(d\/=10):p=10*p+l}return e*p},fb=function(a){var b=1\u003Carguments[t]\u0026\u0026!!arguments[1];return Ba(a,0,b)},Qa=function(a){var b=1\u003Carguments[t]\u0026\u0026!!arguments[1];return Ba(a,1,b)},gb=function(a,b,g,l){return I(g)||\n(g=NaN),I(a)||(a=Qa(a)),isNaN(a)?g:((!I(b)||0\u003Eb)\u0026\u0026(b=0),(!l||!I(l)||2\u003El)\u0026\u0026(l=10),b=Math.pow(l,isNaN(b)?0:b),Math.floor(a*b+.5)\/b)},xa=function(a,b,g,l,p){l=l||\".\";var e=\"\\\\d(?\\x3d(\\\\d{3})+\"+(0\u003Cg?\"\\\\D\":\"$\")+\")\";a=a.toFixed(Math.max(0,~~g));for(b=(b||0)-((p=(l?a.replace(\".\",l):a).replace(new RegExp(e,\"g\"),\"$\\x26\"+(p||\",\")))+l).indexOf(l);0\u003Cb--;)p=\"0\"+p;return p},Ca=function(a){return f=23==(new Date(6E4*(new Date).getTimezoneOffset())).getHours()?36E5:0,a=N(a)?a:I(a)?new Date(a+f+6E4*(new Date).getTimezoneOffset()):\nnew Date,xa(a.getHours(),2)+\":\"+xa(a.getMinutes(),2)+\":\"+xa(a.getSeconds()+a.getMilliseconds()\/1E3,2,3)},hb=function(a){var b=null;try{b=eval(a)}catch(g){b=null}return b},ib=function(a,b){try{var g,l=k,p=\/\\[['\"]?([^\\]'\"]+)['\"]?\\]\/,e=arguments,y=function(a){return\/^[0-9]+$\/.test(a)?Number(a):a};if(2==e[t]\u0026\u0026a\u0026\u0026A(a)){a=a.replace(\/\\[\\]\/g,\"[@]\");for(g=0;99\u003Eg\u0026\u0026a.match(p);g++)a=a.replace(p,\".$1\");a=a.split(\".\");g=0;for(c=l;g\u003Ca[t]-1;g++)\"@\"==(e=y(a[g]))\u0026\u0026(e=l[t]||0),B(l[e])||(n=y(a[g+1]),l[e]=\"@\"!=n\u0026\u0026isNaN(n)?\n{}:[]),l=l[e];\"@\"==(e=y(a[g]))\u0026\u0026(e=l[t]);l[e]=b}}catch(qa){}return b},Da=function(a,b,g){var l;try{B(a)?a=eval(a[b]):(g=b,a=eval(a));try{a=g==W?v+m:g==L?Number(a):g==T?!!a:a}catch(p){}}catch(p){a=l}return a},Ea=function(a,b,g){var l,p,e,y=A(b)?b.split(\",\"):[],d=a;if(J(a))for(d={},b=0;b\u003Cy[t];b++)for(l in e=(p=y[b])[t],a){var k=a[l];(0\u003Ce\u0026\u0026\"*\"==p[e-1]\u0026\u0026!l.indexOf(p.substring(0,e-1))||l==p)\u0026\u0026(!g||S(k)||k)\u0026\u0026(d[l]=k)}return d},ma=function(a){var b=r.createElement(\"a\"),g=0,l={args:{}},p=\"pathname\",e=\"href\",\ny=\"search\",d=[\"hash\",\"host\",\"hostname\",e,\"origin\",p,\"port\",\"protocol\",y],k=decodeURIComponent||unescape;a=a\u0026\u0026A(a)?a:D[e];for(b.setAttribute(e,a);g\u003Cd[t];g++)l[d[g]]=b[d[g]];delete b;b=l[p]||\"\";ea(b,\"\/\/\")||(l[p]=\"\/\/\"+l[p]);a\u0026\u0026ea(b,\"\/\")\u0026\u0026(l[p]=\"\/\"+b);b=0\u003Cl[y][t]?l[y].substring(1).split(\"\\x26\"):[];for(g=0;g\u003Cb[t];g++)if(p=b[g])try{e=p.split(\"\\x3d\"),n=e[0],e.shift(),e[t]?0\u003Cd[t]\u0026\u0026(l.args[n]=k(e.join(\"\\x3d\"))):l.args[n]=q}catch(Xb){}return l},Ra=function(a,b,g){S(b)\u0026\u0026(g=b,b=m);A(b)||(b=D.href);var l,p,e;\nvar y=(b=ma(b).search).substring(0,1);\"?\"!=y\u0026\u0026\"\\x26\"!=y||(b=b.substring(1));b=b.split(\"\\x26\");for(y=0;y\u003Cb[t];y++)if(a==(e=0\u003E(p=(l=b[y]).indexOf(\"\\x3d\"))?l:l.substring(0,p)))return e=l.substring(p+1),0\u003Ep?q:g||0==e[t]||isNaN(e)?e:parseFloat(e);return w},jb=function(){var a,b,g,l;var p=\"unknown\";var e={device:\"BlackBerry;Google TV;iPad;iPhone;iPod;Kindle;Kindle Fire~(?:Cloud9|Silk-Accelerated);Intel Mac;Mac;Nook;PlayBook;PlayStation Vita;TouchPad;Transformer;Xoom;Android;Windows CE;PC~Windows\".split(\";\"),\nOS:\"Android;BlackBerry;CentOS;Debian;Fedora;FreeBSD;Gentoo;Haiku;Kubuntu;Linux Mint;Red Hat;SuSE;Ubuntu;Xubuntu;Cygwin;Symbian OS;hpwOS;webOS;Tablet OS;Linux;OS X;Macintosh;OpenBSD;Windows( [a-zA-Z0-9]+|)\".split(\";\"),browser:\"Nook Browser;Opera( Mini|);Opera~OPR;Chrome;Chrome Mobile~(?:CriOS|CrMo);Firefox~(?:Firefox|Minefield);IE~MSIE;Safari\".split(\";\")};var y=k.navigator||{};var d=y.userAgent||\"\";var h=k.screen||{};var m={agent:d||p,locale:F(y.language||\"\")||p,device:p,deviceType:p,OS:p,OSVer:p,\nbrowser:p,browserVer:p,width:h.width||0,height:h.height||0,density:Math.round(100*(k.devicePixelRatio||1))\/100};for(a in e)for(p=y=0;!y\u0026\u0026p\u003Ce[a][t];p++){var q=(h=e[a][p]).indexOf(\"~\")+1;(y=(new RegExp(h.substring(q))).exec(d))\u0026\u0026(m[a]=q?h.substring(0,q-1):y[0],\"device\"!=a\u0026\u0026(m[a+\"Ver\"]=(b=y[0],void 0,g=d.indexOf(b)+b[t],2\u003C(l=\/([\/ :]+)([0-9.]+)\/i.exec(d.substring(g)))[t]?l[2]:\"\")))}return m.deviceType=-1\u003C\"BlackBerry|iPad|iPhone|iPod|Kindle|TouchPad|Nook|Android|Windows CE\".indexOf(m.device)?\"mobile\":\n\"desktop\",m},Fa=function(a){var b,g=m,l=m,p=m,e=m,d=m,k=\"mc\",h=arguments,q=h[t];if((1\u003Cq\u0026\u0026(\"uc\"!=(b=F(h[q-1]))\u0026\u0026\"lc\"!=b\u0026\u0026\"mc\"!=b||(k=b,q--)),!q)||(a=F(a),2==q?p=F(h[1]):3\u003C=q\u0026\u0026(g=F(h[1]),l=X(h[2],k),4\u003C=q\u0026\u0026(p=X(h[3],k))),r.getElementsByTagName\u0026\u0026(e=r.getElementsByTagName(a)),!B(e)))return d;for(b=0;!d\u0026\u0026b\u003Ce[t];b++)d=e[b],g\u0026\u0026l\u0026\u0026X(d.getAttribute(g),k)!=l\u0026\u0026(d=m);return B(d)\u0026\u0026p?\"text\"!=p?d.getAttribute(p):(d.innerText||d.textContent||m).replace(\/\\s*\u003E\\s*\/g,\"\\x3e\").replace(\/^\u003E+\/,m).replace(\/\u003E+$\/,m):d},kb=function(){var a=\nFa(\"meta\",\"http-equiv\",\"content-type\",\"content\")||\"\",b=a.indexOf(\"charset\\x3d\");return u(0\u003Eb?Fa(\"meta\",\"charset\")||\"\":a.substring(b+8).replace(\/['\";, ].*\/,\"\"))},Sa=function(a){return A(a)||(a=D.href),F(ma(a).hostname.replace(\/^www-?[0-9]*\\.\/i,m))},Ta=function(a){for(var b=(a=Sa(a))[t]-1,g=0;0\u003Cb;b--)if(\".\"==a.substring(b,b+1)){if(g)break;g=b}return g\u0026\u00260\u003Cb\u0026\u0026(a=a.substring(b+1)),F(a)},lb=Da(\"performance.timing.requestStart\")||(new Date).getTime(),Ua=function(a){return(new Date).getTime()-(a\u0026\u0026I(a)?a:\nN(a)?a.getTime():lb)},mb=function(){return J(k.performance)\u0026\u0026J(k.performance.navigation)?1==k.performance.navigation.type:la},nb=function(){return J(k.history)?1==k.history[t]:null},Va=function(a){a=ma(a||D.href).hostname;return a.match(\/\\.co\\..{2}$\/i)||a.match(\/\\.(gov|edu|com|mil|org|net|int)\\..{2}$\/i)?3:2},Y=function(a){var b=\" \"+r.cookie,g=ea(b,\" \"+a+\"\\x3d\"),l=0\u003Eg?g:ea(b,\";\",g);a=0\u003Eg?m:unescape(b.substring(g+2+a[t],0\u003El?b[t]:l));return\"[[B]]\"==a?m:a},ra=function(a,b,g,l){return(b+=m)||((g=new Date).setTime(g.getTime()-\n1E7),b=\"\"),g=g\u0026\u0026!N(g)?new Date(g):g,a\u0026\u0026(r.cookie=a+\"\\x3d\"+escape(b||\"[[B]]\")+\"; path\\x3d\/\"+(l?\"; domain\\x3d\"+l:m)+(g?\"; expires\\x3d\"+g.toUTCString():m)),a?Y(a):w},ob=function(a,b){var g=!!Y(a);return x=function(b){document.cookie=a+\"\\x3d;\"+(b?\" domain\\x3d\"+b+\";\":\"\")+\"path\\x3d\/; expires\\x3dThu, 01 Jan 1970 00:00:01 GMT;\"},g\u0026\u0026(x(b),b||x(\".\"+_A.getOwnerHn())),g},Wa=function(a){return sessionStorage.getItem(a)||\"\"},Xa=function(a,b){sessionStorage.setItem(a,b)},pb=function(a){sessionStorage.removeItem(a)},\nqb=function(){sessionStorage.clear()},rb=function(a){return localStorage.getItem(a)||\"\"},sb=function(a,b){localStorage.setItem(a,b)},tb=function(a){localStorage.removeItem(a)},ub=function(){localStorage.clear()},vb=function(a,b){var g=Wa(a);return C(b)||Xa(a,b),g},wb=function(a){var b=Ra(a),g=Y(a);return g||(g=0),b===q\u0026\u0026(b=1),b===w?g=!A(g)||0==g[t]||isNaN(g)?g:parseFloat(g):(ra(a,b+m),g=b),g},xb=function(a,b){ra(a,b===m||b?b===q?1:b+m:\"0\")},E=[],V=0,Ga=50,Ha=function(a){var b=void 0;a=E[a].n;var g=\n\"window.\";try{a.indexOf(g)\u0026\u0026(a=g+a),b=eval(a)}catch(l){}return b},yb=function(a,b,g){g=typeof(b=Ha(a));ca(b)\u0026\u0026(g=M);try{g!=aa\u0026\u0026(g+=\" \"+(K(b)?b.toString():B(b)?Oa(Ha(a)):b))}catch(l){}return g},Ia=function(){try{var a,b=0,g=1;for(b=V=0;b\u003CE[t];b++)if((a=yb(b))!==E[b].l){try{K(E[b].c)\u0026\u0026E[b].c(Ha(b),E[b].n,a,E[b].l)}catch(l){console.log(z,\"callback function for \"+E[b].n+\":\",l)}E[b].l=a}}catch(l){console.log(H,l),g=0}g\u0026\u0026E[t]\u0026\u0026(V=setTimeout(function(){Ia()},Ga))},zb=function(a,b){if(b||Ya(a),A(a)\u0026\u0026a\u0026\u00260\u003E\na.indexOf(\"(\")\u0026\u0026(!b||K(b))){var g;V\u0026\u0026(clearTimeout(V),V=0);for(g=0;g\u003CE[t]\u0026\u0026(E[g].n!=a||E[g].c!=b);g++);g\u003E=E[t]\u0026\u0026E.push({n:a,c:b,l:aa});V=setTimeout(function(){Ia()},Ga)}else console.log(fa,\"calling _A.watch(\",P(a),\",\",P(b),\") invalid argument(s)\")},Ya=function(a,b){if(A(a)\u0026\u0026a\u0026\u00260\u003Ea.indexOf(\"(\")){var g,l;V\u0026\u0026(clearTimeout(V),V=0);for(g=0;g\u003CE[t];g++)for(;g\u003CE[t]\u0026\u0026E[g].n==a\u0026\u0026(!b||E[g].c==b);){for(l=g;l\u003CE[t]-1;l++)E[l].n=E[l+1].n,E[l].c=E[l+1].c,E[l].l=E[g+1].l;E.pop()}E[t]\u0026\u0026(V=setTimeout(function(){Ia()},\nGa))}},Ab=function(a,b,g){var l=\"typeof \",p=m;a=g?g+\".\"+a:a;g=a+\"_orig\";try{eval(l+g)!=R\u0026\u0026eval(l+a)==R\u0026\u0026eval(l+b)==R\u0026\u0026(eval(g+\"\\x3d\"+a+\";\"+a+\"\\x3d\"+b),p=g)}catch(U){}return p},Bb=function(a,b){var g=\"typeof \",l=m;a=b?b+\".\"+a:a;var p=a+\"_orig\";try{eval(g+p)==R\u0026\u0026eval(g+a)==R\u0026\u0026(eval(a+\"\\x3d\"+p+\";\"+p+\"\\x3dnull\"),l=a)}catch(U){}return l},Cb=function(a,b,g,l){var p,e=\"script\";(p=r.createElement(e)).type=\"text\/java\"+e;p.src=A(a)?a:\"\";p.async=w;g\u0026\u0026K(g)\u0026\u0026(p.onload=g);b=b\u0026\u0026A(b)?b.split(\",\"):[];for(g=0;a\u003Cb[t];g++)\"defer\"==\nb[g]\u0026\u0026(p.defer=q),\"async\"==b[g]\u0026\u0026(p.async=q);l\u0026\u0026!r.body?r.write('\\x3cscript src\\x3d\"'+a+'\"'+(p.defer?\" defer\":\"\")+(p.async?\" async\":\"\")+\"\\x3e\\x3c\/\"+e+\"\\x3e\"):r.getElementsByTagName(l||!r.body?\"head\":e)[0].appendChild(p)},na,sa,Ja=function(a,b,g,l,p){if(!(1E3\u003Cna))try{b=b||0;var e,d=m;var k=\"...TRUNCATED, TOO \";var h=k+\"LARGE\",q=function(a,b){var g=m,l=0;if(1==a)for(g+=\"\\n\";l++\u003Cb;)g+=\"  \";return g},r=function(a,b,g){return 2==a\u0026\u0026(0\u003Cg||b)?b+\"\\x3d\":m};if(l||(l=0),(g=g||m)||(g=\"?\"),p||(p=0),10\u003C++p)return sa++||\n(d+=k+\"DEEP\"),na=2E3,d;var u=ha(a);switch(u){case L:case T:d+=r(b,g,l)+a;break;case R:d+=r(b,g,l)+\"function(){}\";break;case aa:case la:d+=r(b,g,l)+u;break;case W:d+=r(b,g,l)+\"'\"+a.replace(\/\"\/g,\"\\\\'\")+\"'\";break;case M:2\u003Eb\u0026\u0026(d+=\"[\");for(e=0;e\u003Ca[t];e++){if(1E3\u003Cna++)return sa++||(d+=h),d;e\u0026\u0026(d+=2==b?\"\\n\":m);d+=(2\u003Eb\u0026\u0026e?\", \":m)+Ja(a[e],b,g+\"[\"+e+\"]\",l,p)}2\u003Eb\u0026\u0026(d+=\"]\");break;case Q:for(e in k=0,l++,a){if(1E3\u003Cna++)return sa++||(d+=h),d;k\u0026\u0026(d+=2==b?\"\\n\":m);d+=(2\u003Eb?(k++?\", \":\"{\")+q(b,l)+e+\":\"+(b?\" \":m):m)+\nJa(a[e],b,g+\".\"+e,l,p)}l--;2\u003Eb\u0026\u0026(d+=(k?m:\"{\")+q(b,l)+\"}\");break;default:d+=\"UNKNOWN TYPE: \"+u}return d}catch(Zb){return na=2E3,sa++,\"...FORMATTING \"+fa}},P=function(){var a,b,g,l=arguments,e=l[t],d=w,k=0,h=m,r=m;try{for(a=0;a\u003Ce;a++){a\u0026\u0026!d\u0026\u0026(h+=\" \");d=w;var u=l[a];(b=ha(u))==W\u0026\u0026(0\u003C(g=u[t])\u0026\u0026\"\\x3d\"==u.substring(g-1,g)?(d=q,2!=k\u0026\u0026(h+=u),(r=u.substring(0,g-1))||(r=\" \")):\"-c\"==u?(d=q,k=0):\"-l\"==u?(d=q,k=1):\"-a\"==u\u0026\u0026(d=q,k=2));d||(na=sa=0,h+=Ja(u,r\u0026\u0026b==W\u0026\u0026!k?1:k,\" \"==r?m:r),r=m)}}catch(Yb){h=\"PROCESSING \"+\nfa}return h},ia=function(){console.log(P.apply(this,arguments))},Db=function(){try{var a=\"logLevel\",b=ma().args[a]||Y(a)||\"0\",g=parseInt(b),l=k[a],e=arguments,d=e[0]||0,h=1,q=[];I(g)\u0026\u0026(ra(b),l=g);l=I(l)\u0026\u0026l||0;k[a]=l;for(I(d)||(d=d?1:0);h\u003Ce[t];)q.push(e[h++]);d\u003C=l\u0026\u0026ia.apply(this,q)}catch(wa){ia(z,\"logl\")}},Eb=function(a,b){var g=fa+\" \"+(b\u0026\u0026A(b)\u0026\u0026b?\" in \"+b:m),l=J(a)?65535\u0026(a.number||0):m,e=m,d=a.message||a.description||m,k=m,h=m;I(l)\u0026\u0026(l\u0026\u0026(k=l+\": \"),a.name\u0026\u00260\u003E(a.stack||m).indexOf(a.name)\u0026\u0026(k+=a.name),\nd\u0026\u00260\u003E(a.stack||m).indexOf(d)\u0026\u0026(k+=(k?\": \":m)+d),a.lineNumber\u0026\u0026(e+=\"Line \"+a.lineNumber),a.columnNumber\u0026\u0026(e+=\", Column\"+a.columnNumber),a.fileName\u0026\u0026(e+=(e?\" \":m)+\"in \"+a.fileName),a.stack\u0026\u0026(h=a.stack),ia(g),k\u0026\u0026ia(k),e\u0026\u0026ia(e),h\u0026\u0026ia(h))},Fb=function(a){var b=ma(a||D.href).hostname,g=Va(a);a=b.split(\".\");g=a[t]-g;for(b=m;g\u003Ca[t];g++)b+=\".\"+a[g];return b},Gb=function(a,b){var g,e,d,k=\"length\",h=document.cookie.split(\";\"),q=\/%[0-9a-fA-F]+\/,m=[];(I(a)||S(a))\u0026\u0026(g=a,a=b,b=g);for(g=0;g\u003Ch[k];g++){var u=(e=h[g].replace(\/^ \/,\n\"\").split(\"\\x3d\"))?e[0]:\"\";var r=e\u0026\u00260\u003Ce[k]?\"'\"+e[1]+\"'\":\"\";for(d=0;3\u003Ed\u0026\u0026!b;d++)r=r.match(q)?unescape(r)+\" e\":r;e=u+\"\\x3d\"+r;(da(a)?e.match(a):A(a)?-1\u003CF(e).indexOf(F(a)):!a)\u0026\u0026m.push(u+\" \\x3d \"+r)}for(g=0;g\u003Cm[k];g++)for(d=0;d\u003Cm[k]-1;d++)u=d+1,0\u003Cm[d].localeCompare(m[u])\u0026\u0026(e=m[d],m[d]=m[u],m[u]=e);for(g=0;g\u003Cm[k];g++)console.log(m[g])},Hb=function(a){var b,g,e,d=[];var k=0;try{h.d.e+=0}catch(qa){if(qa.stack){var h=0;for(b=(k=qa.stack.split(\"\\n\"))[t];h\u003Cb;h++)d.push(k[h]);d.shift();d.shift();d.shift();k=\n1}else if(window.opera\u0026\u0026qa.message){h=0;for(b=(k=qa.message.split(\"\\n\"))[t];h\u003Cb;h++)k[h].match(\/^\\s*[A-Za-z0-9\\-_\\$]+\\(\/)\u0026\u0026(g=k[h],k[h+1]\u0026\u0026(g+=k[h+1],h++),d.push(g));d.shift();d.shift();d.shift();k=1}}if(!k)for(h=arguments.callee.caller;h;)g=(e=h+\"\").substring(e.indexOf(\"function\")+8,e.indexOf(\"(\"))||\"anonymous\",d.push(g),h=h.caller;return d[t]||d.push(\"\\x3cunknown\\x3e\"),\"string\"==typeof a\u0026\u0026console.log((\"\"!=a?a+\", \":\"\")+\"Call stack:\\n\"+d.join(\"\\n\")),d},Ib=function(){var a,b,g,e=Ca,d=console.log,h=\nk.performance||{};var m=h.timing||0;var q=h.timeOrigin||0,u=[];h=h.navigation||{};var r=h.type||0;if(m){for(a in a=m.responseEnd,g=m.fetchStart,d(\"Network latency:\",-1\u003C(b=a\u0026\u0026g?a-g:-1)?e(b):\"?\",\"fetchStart to responseEnd\"),a=m.loadEventEnd,g=m.responseEnd,d(\" Render latency:\",-1\u003C(b=a\u0026\u0026g?a-g:-1)?e(b):\"?\",\"responseEnd to loadEventEnd\"),a=m.loadEventEnd,g=m.navigationStart,d(\"Total page load:\",-1\u003C(b=a\u0026\u0026g?a-g:-1)?e(b):\"?\",\"navigationStart to loadEventEnd\"),d(\"Origin time:\",q?e(q-6E4*(new Date).getTimezoneOffset()):\n\"?\"),m)(b=I(m[a])?m[a]:0)\u0026\u0026u.push({n:a,v:b});m=u.length;for(a=0;a\u003Cm;a++)for(g=0;g\u003Cm-1;g++)u[g].v\u003Eu[g+1].v\u0026\u0026(b=u[g].v,u[g].v=u[g+1].v,u[g+1].v=b,b=u[g].n,u[g].n=u[g+1].n,u[g+1].n=b);d(\"Performance timing:\");for(a=0;a\u003Cm;a++)d(\"  \"+(0\u003E(b=u[a].v-q)?\"-\":1\u003Cb?\"+\":\" \")+e(0\u003Eb?-b:b),u[a].n);d(\"Navigation:\");d(\"  Type:\",0\u003C=r\u0026\u00263\u003E=r?[\"navigate\",\"reload\",\"back-forward\",\"reserved\"][r]:r);d(\"  Redirect count:\",h.redirectCount)}else d(\"performance.timing undefined\")},Z=function(a){var b;a=J(k._AA)?J(k._AA[d])?k._AA[d]:\nb:J(k[d])?k[d]:b;return J(a)\u0026\u0026K(a.t)?a:b},Jb=function(){var a,b,g=\",\",d=Z()||{},e=\"\";for(a=0;a\u003Carguments[t];a++)J(arguments[a])?d=arguments[a]:e+=A(arguments[a])?(e?\",\":\"\")+arguments[a]:\"\";e=e.split(\",\");for(a=0;a\u003Ce[t];a++)e[a]\u0026\u0026((\"event\"==(b=e[a].replace(\/=.*\/,\"\").replace(\/:\/,\"\")).substring(0,5)||-1\u003C\"scOpen,scView,scAdd,scRemove,scCheckout,prodView,purchase\".indexOf(b))\u0026\u0026(A(d.linkTrackEvents)\u0026\u0026\"none\"!=F(d.linkTrackEvents)||(d.linkTrackEvents=\"\"),0\u003E(g+d.linkTrackEvents+g).indexOf(g+b+g)\u0026\u0026(d.linkTrackEvents+=\n(d.linkTrackEvents?g:\"\")+b),b=\"events\"),A(d.linkTrackVars)\u0026\u0026\"none\"!=F(d.linkTrackVars)||(d.linkTrackVars=\"\"),0\u003E(g+d.linkTrackVars+g).indexOf(g+b+g)\u0026\u0026(d.linkTrackVars+=(d.linkTrackVars?g:\"\")+b))},Kb=function(){try{var a=Z()||{};return a.visitorID||(Y(\"s_vi\")||\"\").replace(\/\\[[^\\[]*\\]\/g,\"\").replace(\/[^\\|]*\\|\/,\"\")||Y(\"AMCV_\")||a.mim||Y(\"s_fid\")||a.fid||\"\"}catch(b){}},Lb=function(){try{var a=k.ga.getAll()[0].get(\"clientId\")}catch(b){}return a||\"\"},Mb=function(){var a=Y(\"_auid\"),b=(new Date).getTime(),\ng=1E17*Math.random();return a||(a=b.toString(16)+\"-\"+g.toString(16)),ra(\"_auid\",a,b+2E11,Ta()),a},Za=function(){return Ea(k.hpmmd,\"type,page,product,user,promo,search,legacy,browser,csstate,version,code\")},ta=function(a){return Ea(a||Z(),\"account,version,currencyCode,pageName,products,events,channel,server,hier*,campaign,eVar*,prop*\",1)},Nb=function(a){var b=a||k.dataLayer,g=b;if(ca(g))for(g={},a=0;a\u003Cb.length;a++)v=b[a].event,A(v)\u0026\u0026!v.indexOf(\"gtm.\")||(g[a+\"\"]=b[a]);return g},Ob=function(){var a=\nDa(\"Bootstrapper.ensightenOptions.staticJavascriptPath\");return A(a)\u0026\u00260\u003Ca.indexOf(\"-test\")},ya=0,Ka=k.addEventListener,La=k.attachEvent,Pb=k.removeEventListener,Qb=k.detachEvent,oa=\"afterprint beforeprint focusin focusout pagehide pageshow play pause cuechange playing ended volumechange canplay canplaythrough durationchange ratechange waiting change contextmenu formchange forminput submit emptied error invalid line loadstart load hashchange beforeunload unload stalled reset abort loadeddata loadedmetadata DOMContentLoaded readystatechange offline popstate progress seeking seeked show suspend timeupdate\".split(\" \"),\nza=function(a){try{a=a||k.event,k.console.log(\"DOM EVENT\",a.type)}catch(b){}},pa=function(){var a,b=\"logAnalytics\";try{!0===(a=k._A.parseParam(b))\u0026\u0026(a=1),1==a?k._A.cW(b,a):0===a\u0026\u0026k._A.cD(b),k._A.isN(a)||(a=_A.toNum(_A.cR(b)))}catch(g){}return a||0},Rb=function(){if(!ya){ya=q;for(var a=0;a\u003Coa[t];a++)Ka?Ka(oa[a],za,w):La\u0026\u0026La(\"on\"+oa[a],za)}},Sb=function(){if(ya){ya=w;for(var a=0;a\u003Coa[t];a++)Ka?Pb(oa[a],za,w):La\u0026\u0026Qb(\"on\"+oa[a],za)}},ja={log:0,warn:0,error:0,info:0},$a=D.href,Tb=function(){var a,b,g,\nd=k.console||{},e=J(k.performance)\u0026\u0026J(k.performance.timing)?k.performance.timing:0,h=e?e.navigationStart:0,u=\"requestStart responseStart domLoading domContentLoadedEventEndf loadEventStart loadEventEnd\".split(\" \"),q=function(a,b,g){try{var e,l=[Ca(b||Ua())];for(e=0;e\u003Cg[t];e++)l[e+1]=g[e];return a?Function.prototype.apply.call(a,d,l):-1}catch($b){return-2}};for(b in ja)!ja[b]\u0026\u0026(g=ja[b]=d[b]||0)\u0026\u0026(d[b]=function(){return q(g,0,arguments)});for(a=0;h\u0026\u0026a\u003Cu[t];a++){var r=e[b=u[a]];I(r)\u0026\u0026r\u0026\u0026(q(ja.log,r-\nh,[\"PERF TIME\",b,$a]),$a=m)}},Ub=function(){var a,b;for(a in ja)(b=ja[a])\u0026\u0026(k.console[a]=b,ja[a]=0)},ka=0,ua=[],Vb=51,Ma=0,Na=0,va={trackMetrics:{c:0,n:function(a,b){var g;if(_A.isF(k.trackMetricsOverrides))try{k.trackMetricsOverrides(a,b)}catch(l){console.log(z,\"trackMetricsOverrides\",l)}if(pa())try{console.log(\"Analytics trackMetrics(\",P(a),\",\",\"\\n\"+P(\"-l\",b),\");\",\"\\n\"+P(\"hpmmd_subset\\x3d\",Za()))}catch(l){}if(g=k.o_trackMetrics.apply(k,arguments),_A.isF(k.trackMetricsPostOverrides))try{k.trackMetricsPostOverrides(a,\nb)}catch(l){console.log(z,\"trackMetricsPostOverrides\",l)}return g}},t:{c:d,n:function(){var a=this;try{ua.length||ab()}catch(b){}if(Na)a=a.o_t.apply(a,arguments);else{if(K(k.sToverrides))try{k.sToverrides(a)}catch(b){console.log(z,\"sToverrides\",b)}if(a=a.o_t.apply(a,arguments),ua.push((J(Z())?Z().account:0)||k.s_account||\"?\"),pa())try{console.log(\"Adobe Analytics s.t()\",\"\\n\"+P(\"s_subset\\x3d\",ta()))}catch(b){}}return a}},tl:{c:d,n:function(a,b,g){var d;if(K(k.sTLoverrides))try{k.sTLoverrides(this,\na,b,g)}catch(p){console.log(z,\"sTLoverrides\",p)}if(Na=1,d=this.o_tl.apply(this,arguments),Na=0,K(k.sTLpostOverrides))try{k.sTLpostOverrides(this,a,b,g)}catch(p){console.log(z,\"sTLpostOverrides\",p)}if(pa())try{console.log(\"Adobe Analytics s.tl(\",P(a),\",\",P(b),\",\",P(g),\")\",\"\\n\"+P(\"s_subset\\x3d\",ta()))}catch(p){}return d}},sa:{c:d,n:function(a){var b;if(K(k.sSAoverrides))try{a=k.sSAoverrides(a)}catch(g){console.log(z,\"sSAoverrides\",g)}if(b=this.o_sa.apply(this,arguments),pa())try{console.log(\"Adobe Analytics s.sa(\",\nP(a),\")\",\"\\n\"+P(\"s_subset\\x3d\",ta()))}catch(g){}if(K(k.sSApostOverrides))try{a=k.sSApostOverrides(a)}catch(g){console.log(z,\"sSAoverrides\",g)}return b}},s_gi:{c:0,n:function(a){var b;if(K(k.sGIoverrides))try{a=k.sGIoverrides(a)}catch(g){console.log(z,\"sGIoverrides\",g)}if(b=k.o_s_gi.apply(k,arguments),pa())try{console.log(\"Adobe Analytics s_gi(\",P(a),\")\",\"\\n\"+P(\"s_subset\\x3d\",ta()))}catch(g){}if(K(k.sGIpostOverrides))try{a=k.W.sGIpostOverrides(a)}catch(g){console.log(z,\"sGIoverrides\",g)}return b}}},\nab=function(){try{var a,b,g,d=1,e=Z();for(a=0;a\u003Cua.length;a++)if((b=ua[a])\u0026\u0026(Ma++,g=k[\"s_i_\"+b.replace(\/,\/g,\"_\")]||k[\"s_i_\"+e.visitorNamespace],J(g)\u0026\u0026g.complete||10\u003CMa)){if(Ma=0,console.log(\"Adobe Analytics s.t() beacon sent\",\"?\"==b?\"\":\"to RSID(s) \"+b),K(k.sTpostOverrides))try{k.sTpostOverrides(Z(),b)}catch(U){console.log(z,\"sTpostOverrides()\",U)}ua[a]=\"\"}}catch(U){console.log(z,\"_watchST\",U),d=0}d\u0026\u0026setTimeout(function(){ab()},Vb)},bb=function(){ka\u0026\u0026(clearTimeout(ka),ka=0);var a;try{var b,g,e,h,m=\nZ(),u=1,q=z+\" wrapS\";if(m)for(a in!J(k._AA)\u0026\u0026k._A.adobeSobject!=m\u0026\u0026K(m.t)\u0026\u0026(k._A.adobeSobject=m),va)try{(g=(b=va[a]).c?b.c==d?Z():k[b.c]:k)\u0026\u0026(e=g[a],h=\"o_\"+a,_A.isF(e)\u0026\u0026!K(g[h])\u0026\u0026(g[h]=e,g[a]=b.n))}catch(wa){console.log(q,\"polling loop\",wa),u=0}}catch(wa){console.log(q,wa),u=0}(a=u)\u0026\u0026(ka=setTimeout(bb,50))},cb=function(a){a=z+\" wrapAdobeCalls\";try{bb()}catch(b){console.log(a,b)}},Wb=function(){try{var a,b,g,d;for(a in ka\u0026\u0026(clearTimeout(ka),ka=0),va)(b=va[a].c?k[va[a].c]:k)\u0026\u0026(g=b[a],d=\"o_\"+a,K(g)\u0026\u0026\nK(b[d])\u0026\u0026(b[a]=b[d],b[d]=0,delete b[d]))}catch(p){console.log(z,\"wrapAdobeCallsEnd\",p)}};return{tO:function(){return ha.apply(e,arguments)},isNU:function(){return ba.apply(e,arguments)},isU:function(){return C.apply(e,arguments)},isN:function(){return I.apply(e,arguments)},isS:function(){return A.apply(e,arguments)},isB:function(){return S.apply(e,arguments)},isAO:function(){return B.apply(e,arguments)},isA:function(){return ca.apply(e,arguments)},isO:function(){return J.apply(e,arguments)},isF:function(){return K.apply(e,\narguments)},isR:function(){return da.apply(e,arguments)},isD:function(){return N.apply(e,arguments)},MC:function(){return X.apply(e,arguments)},LC:function(){return F.apply(e,arguments)},UC:function(){return u.apply(e,arguments)},LUC:function(){return db.apply(e,arguments)},len:function(){return Oa.apply(e,arguments)},iO:function(){return ea.apply(e,arguments)},trimWS:function(){return Pa.apply(e,arguments)},scrubAndEsc:function(){return eb.apply(e,arguments)},addCS:function(){return Aa.apply(e,arguments)},\ntoNum:function(){return Ba.apply(e,arguments)},toInt:function(){return fb.apply(e,arguments)},toFloat:function(){return Qa.apply(e,arguments)},roundNum:function(){return gb.apply(e,arguments)},fmtNum:function(){return xa.apply(e,arguments)},fmtTimestamp:function(){return Ca.apply(e,arguments)},Eval:function(){return hb.apply(e,arguments)},sP:function(){return ib.apply(e,arguments)},gP:function(){return Da.apply(e,arguments)},subO:function(){return Ea.apply(e,arguments)},parseUri:function(){return ma.apply(e,\narguments)},parseParam:function(){return Ra.apply(e,arguments)},getDeviceInfo:function(){return jb.apply(e,arguments)},getHTMLtag:function(){return Fa.apply(e,arguments)},getCharSet:function(){return kb.apply(e,arguments)},getShortHn:function(){return Sa.apply(e,arguments)},getOwnerHn:function(){return Ta.apply(e,arguments)},getTLDlevels:function(){return Va.apply(e,arguments)},getCookieDomain:function(){return Fb.apply(e,arguments)},getElapsedTime:function(){return Ua.apply(e,arguments)},pageReloaded:function(){return mb.apply(e,\narguments)},newTabOrWinOpened:function(){return nb.apply(e,arguments)},cR:function(){return Y.apply(e,arguments)},cW:function(){return ra.apply(e,arguments)},cD:function(){return ob.apply(e,arguments)},lG:function(){return rb.apply(e,arguments)},lS:function(){return sb.apply(e,arguments)},lR:function(){return tb.apply(e,arguments)},lC:function(){return ub.apply(e,arguments)},sG:function(){return Wa.apply(e,arguments)},sS:function(){return Xa.apply(e,arguments)},sR:function(){return pb.apply(e,arguments)},\nsC:function(){return qb.apply(e,arguments)},getPrevious:function(){return vb.apply(e,arguments)},getSessionP:function(){return wb.apply(e,arguments)},setSessionP:function(){return xb.apply(e,arguments)},watch:function(){return zb.apply(e,arguments)},watchEnd:function(){return Ya.apply(e,arguments)},intercept:function(){return Ab.apply(e,arguments)},deIntercept:function(){return Bb.apply(e,arguments)},runJS:function(){return Cb.apply(e,arguments)},varsToStr:function(){return P.apply(e,arguments)},\nlog:function(){return ia.apply(e,arguments)},logl:function(){return Db.apply(e,arguments)},logE:function(){return Eb.apply(e,arguments)},logC:function(){return Gb.apply(e,arguments)},getStackTrace:function(){return Hb.apply(e,arguments)},logPerf:function(){return Ib.apply(e,arguments)},addLTV:function(){return Jb.apply(e,arguments)},getAdobeID:function(){return Kb.apply(e,arguments)},getGoogleID:function(){return Lb.apply(e,arguments)},getUniqueID:function(){return Mb.apply(e,arguments)},subHpmmd:function(){return Za.apply(e,\narguments)},subS:function(){return ta.apply(e,arguments)},subDL:function(){return Nb.apply(e,arguments)},onEnsightenTest:function(){return Ob.apply(e,arguments)},logState:function(){return pa.apply(e,arguments)},logDomEvents:function(){return Rb.apply(e,arguments)},logDomEventsEnd:function(){return Sb.apply(e,arguments)},logTimeStamps:function(){return Tb.apply(e,arguments)},logTimeStampsEnd:function(){return Ub.apply(e,arguments)},wrapAdobeCalls:function(){return cb.apply(e,arguments)},logAdobeCreg:function(){return cb.apply(e,\narguments)},wrapAdobeCallsEnd:function(){return Wb.apply(e,arguments)}}}(),d._A.logState()\u0026\u0026(d._A.logTimeStamps(),d._A.logDomEvents()),d._A.wrapAdobeCalls())}();\n(function(){var d=window,h=d._A,e=\"s_vnum\",k=\"s_invisit\",r=\"s_invisitc\",D=\"s_previousUrl\",q,w,m,t=function(){q=h.toNum(h.cR(e));w=h.toNum(h.cR(k));m=h.toNum(h.cR(r))};G=function(d){var e=h.visit;h.isO(e)?d=e[d]||0:(t(),O={},h.isN(q)?h.isN(w)?(w++,m++,2\u003Em\u0026\u0026(m=2)):(q++,m=w=1):q=w=m=1,O.num=q,O.pageDepth=w,O.callDepth=m,O.ltDepth=0,d=O[d]||0);return d};h.incDepth=function(d){h.isO(h.visit)||(h.visit={});var L=h.visit;if(!h.isN(L.timeout)||5\u003EL.timeout)L.timeout=30;var Q=6E4*L.timeout,M=(new Date).getTime(),\nT=h.getLtDepth(),R=h.getOwnerHn();t();h.isN(q)?h.isN(w)?(d\u0026\u0026w++,m++,2\u003Em\u0026\u0026(m=2)):(q++,w=d?1:0,m=1):(q=1,w=d?1:0,m=1);h.cW(e,q,M+2E11,R);h.cW(k,w,M+Q,R);h.cW(r,m,M+Q,R);h.cW(D,document.location.href,M+Q,R);L.num=q;L.pageDepth=w;L.callDepth=m;L.ltDepth=d?0:T+1};h.getVisitNum=function(){return G(\"num\")};h.getPageDepth=function(){return G(\"pageDepth\")};h.getCallDepth=function(){return G(\"callDepth\")};h.getLtDepth=function(){return G(\"ltDepth\")}})();\n_A.isF(window._A.getSiteSection)||(window._A.getSiteSection=function(d){var h=this,e=!0,k=!1,r=\"content\",D=\"ERROR in getSiteSection\",q,w,m,t=\"match\",W=t+\"Dev\",L=\"rsid\",Q=\"rsidDev\",M=\"country\",T=\"language\",R=\"region\",la=\"currency\",aa=[L,Q,M,T,R,la],fa=function(d){for(var h=0;h\u003Caa.length;h++)if(d==aa[h])return e;return k},z,ha=document.location,ba=\"Unknown\",C={type:ba,subtype:ba,platform:ba,match:\"NONE\",dev:e,rsid:\"hphqunknown\",rsidDev:\"hphqglobaldev\"},I=\"adEUR aeAED afAFN agXCD aiXCD alALL amAMD anANG aoAOA aqXCD arARS asUSD atEUR auAUD awAWG axEUR azAZN baBAM bbBBD bdBDT beEUR bfXOF bgBGN bhBHD biBIF bjXOF blEUR bmBMD bnBND boBOB brBRL bsBSD btBTN bvNOK bwBWP byBNY bzBZD caCAD ccAUD cdCDF cfXAF cgXAF chCHF ciXOF ckNZD clCLP cmXAF cnCNY coCOP crCRC cvCVE cxAUD cyEUR czCZK deEUR djDJF dkDKK dmXCD doDOP dzDZD ecECS eeEUR egEGP ehMAD esEUR etETB fiEUR fjFJD fkFKP fmUSD foDKK frEUR gaXAF gbGBP gdXCD geGEL gfEUR ggGGP ghGHS giGIP glDKK gmGMD gnGNF gpEUR gqXAF grEUR gsGBP gtGTQ guUSD gwGWP gyGYD hkHKD hmAUD hnHNL hrHRK htHTG huHUF idIDR ieEUR ilILS imGBP inINR ioGBP iqIQD isISK itEUR jeGBP jmJMD joJOD jpJPY keKES kgKGS khKHR kiAUD kmKMF knXCD krKRW ksEUR kwKWD kyKYD kzKZT laLAK lbLBP lcXCD liCHF lkLKR lrLRD lsLSL ltLTL luEUR lvLVL lyLYD maMAD mcEUR mdMDL meEUR mfEUR mgMGF mhUSD mkMKD mlXOF mmMMK mnMNT moMOP mpUSD mqEUR mrMRO msXCD mtEUR muMUR mvMVR mwMWK mxMXN myMYR mzMZN naNAD ncXPF neXOF nfAUD ngNGN niNIO nlEUR noNOK npNPR nrAUD nuNZD nzNZD omOMR paPAB pePEN pfEUR pgPGK phPHP pkPKR plPLN pmEUR pnNZD prUSD psILS ptEUR pwUSD pyPYG qaQAR reEUR roRON rsRSD ruRUB rwRWF saSAR sbSBD scSCR seSEK sgSGD shSHP siEUR sjNOK skEUR slSLL smEUR snXOF soSOS srSRD ssSSP stSTD svSVC szSZL tcUSD tdXAF tfEUR tgXOF thTHB tjTJS tkNZD tlUSD tmTMT tnTND toTOP trTRY ttTTD tvAUD twTWD tzTZS uaUAH ugUGX ukGBP umUSD usUSD uyUYU uzUZS vaEUR vcXCD vgUSD viUSD vnVND vuVUV wfXPF wsWST xkEUR yeYER ytEUR zaZAR zmZMW zwZWD\".split(\" \"),\nA={APJ:\",asia_pac,af,au,bd,cn,hk,id,in,jp,kr,lk,my,nz,ph,pk,sg,th,tw,vn,\",EMEA:\",emea_africa,emea_europe,emea_middle_east,ae,al,ar,at,ax,az,ba,be,bg,by,ch,cz,de,dk,ee,es,fi,fr,ga,gb,gr,hr,hu,hr,ie,il,is,it,ks,kz,lt,lu,lv,md,mk,mt,nl,no,pl,pt,ro,rs,ru,rs,sa,se,si,sk,tm,tr,ua,uk,xk,za,\",AMS:\",america_nsc_carib,lamerica_nsc_cnt_amer,ar,bo,br,ca,cl,co,ec,hn,jm,mx,ns,pe,pr,py,sv,us,uy,ve,\"},S=function(d){var h,m=k,q;if(2==d.length){d=_A.LC(d);for(h=0;!m\u0026\u0026h\u003CI.length;h++)m=d==I[h].substring(0,2);for(q in A)-1\u003C\n_A.iO(A[q],\",\"+d+\",\")\u0026\u0026(m=e)}return m};var B=function(){var d=function(){var d=_A.LC(_A.getHTMLtag(\"meta\",\"name\",\"target_\"+M,r)||_A.getHTMLtag(\"meta\",\"name\",M,r));return S(d)?d:\"\"},e=function(){var d=_A.LC(_A.getHTMLtag(\"html\",\"lang\")||_A.getHTMLtag(\"meta\",\"name\",T,r));5==d.length\u0026\u0026\"-\"==d[2]?d=S(d.substring(3,5))?d.substring(0,2):S(d.substring(0,2))?d.substring(3,5):\"\":\"-\"==d[2]\u0026\u0026(d=d.substring(0,2));return 2==d.length?d:\"\"};6\u003CF.length\u0026\u0026\"\/\"==F[0]\u0026\u0026\"\/\"==F[6]\u0026\u0026(\"\/\"==F[3]||\"-\"==F[3])\u0026\u0026(q=F.substring(1,\n3),S(q)?w=F.substring(4,6):(q=F.substring(4,6),S(q)?w=F.substring(1,3):q=w=\"\"));if(!q){var h=hn.length;\".\"==hn[h-3]\u0026\u0026(q=hn.substring(h-2),S(q)||(q=\"\"))}q=d()||q;q=\"uk\"==q?\"gb\":q;q=\"xk\"==q?\"ks\":q;w=e()||w;return q};var ca=function(e){var h,k=0,m=function(e){var h=0;if(_A.isB(e)||_A.isN(e))h=e;else if(_A.isS(e))h=-1\u003C_A.iO(d,e);else if(_A.isR(e))h=d.match(e);else if(_A.isF(e))try{h=e(d)}catch(Aa){console.log(D,\"running match function sa[\"+z+\"]:\",Aa)}return h};if(_A.isA(e))for(h=0;!k\u0026\u0026h\u003Ce.length;h++)k=\nm(e[h]);else k=m(e);return k};ba=function(d){var e,h;for(e=h=0;!h\u0026\u0026e\u003CX.length;e++){var k=X[e];ca(k[d])\u0026\u0026(h=k);h\u0026\u0026q\u0026\u0026k.matchCc\u0026\u0026q!=k.matchCc\u0026\u0026(h=0)}return h};var J=function(){var d,e=\"\",h=_A.LC(_A.getHTMLtag(\"meta\",\"name\",\"target_\"+M,r));for(d in A)-1\u003C_A.iO(A[d],\",\"+q+\",\")\u0026\u0026(e=d);for(d in A)-1\u003C_A.iO(A[d],\",\"+h+\",\")\u0026\u0026(e=d);return e},K=function(){var d=\"\",e;for(e=0;!d\u0026\u0026e\u003CI.length;e++)q==I[e].substring(0,2)\u0026\u0026(d=I[e].substring(2));return d},da=function(d,e,h){if(_A.isF(d))try{d=d(C.url,C)}catch(ea){console.log(D,\n\"evaluating\",h,\"for\",e,ea),d=\"function-error\"}return d},N=function(d,e){var h=\"AMS\"==m?\"us\"==q||\"ca\"==q||\"pr\"==q?\"na\":\"la\":\"APJ\"==m?\"ap\":\"EMEA\"==m?\"emea\":\"\";h\u0026\u0026(d=(d?d+\",\":\"\")+\"hpi-hphq\"+h+\",hphq\"+h+\",hphq\"+h+q+\",hpi-hphq\"+h+q+(e?(\"us\"==q?\",hphqetrstagetemp,hpcsecamsushhos,hphqnaspshopping\":\"\")+(\"APJ\"==m?\",hpi-hphqaponlinestore,hpi-hphqaponlinestore\":\"\")+\",hphq\"+h+\"store\":\"\"));return d},X=[{type:\"Store\",subtype:\"Public\",platform:\"ISCS\",match:\/hp\\.com\\\/(australia|canada|france|germany|italy|korea|malaysia|netherlands|singapore|spain|sweden|switzerland|uk)store\/,\nmatchDev:\/(qa|hotfix|itg|test|uat|perf|test)[0-9]*\\.store\\.hp\\.com\\\/(australia|canada|france|germany|italy|korea|malaysia|netherlands|singapore|spain|sweden|switzerland|uk)store\/},{type:\"Store\",subtype:function(d){try{var e=\"Public\";d=_A.parseUri(_A.LC(d));var h=d.hostname,k=d.pathname;0\u003Eh.indexOf(\"php9\")\u0026\u0026(h.indexOf(\"cepp.\")?0!=h.indexOf(\"www.\")\u0026\u00260!=h.indexOf(\"staging.\")\u0026\u0026(e=h.substring(0,h.indexOf(\".\"))):(0==k.indexOf(\"\/\")\u0026\u0026(k=k.substring(1)||\"cepp\"),e=k.substring(0,(k+\"\/\").indexOf(\"\/\"))))}catch(Pa){e=\n\"Public\"}return _A.LC(e)},platform:\"Magento\",match:\"hpshopping.in hpshopping.id hpshopping.hk hpstorethailand.com www.hpstore.cn smbclub.hpstore.cn\".split(\" \"),matchDev:\"staging.hpshopping.in staging.hpshopping.id staging.hpshopping.hk staging.hpstorethailand.com hp.php9.cc test.php9.cc\".split(\" \"),udl:!0,rsid:function(){return N(\"hphqglobal\",!0)}},{type:\"Store\",subtype:\"Public\",platform:\"Acquire\",match:\"hpshopping.co.nz\"},{type:\"Store\",subtype:\"Public\",platform:\"Direct+\",match:\/(h20547|h50146)\\.www2\\.hp\\.com\/},\n{type:\"Store\",subtype:\"Public\",platform:\"Linio\",match:\/www\\.hponline(\\.cl|\\.com\\.(mx|co|ar)|store\\.com\\.pe)\/,matchDev:\"hp.linio-staging.com\"},{type:\"Store\",subtype:\"Public\",platform:\"CNOVA\",match:\"www.lojahp.com.br\",country:\"br\",language:\"pt\"},{type:\"Store\",subtype:\"ServicesStore\",platform:\"GenesisGSS\",match:\"essc-web-pro.houston.hp.com\/gss\/\",matchDev:[\/(qa|hotfix|itg|test|uat|perf|test)[0-9]*\\.store\\.hp\\.com\\\/gss\\\/\/,\/essc-web-(dev|itg)[12]?\\.(houston|austin|genuitga)\\.hp\\.com\\\/gss\\\/\/]},{type:\"Store\",\nsubtype:\"Genesis\",platform:\"GenesisGSS\",match:\"h20212-3.www2.hp.com\",matchDev:\"g1w9260g-3.austin.hpicorp.net\"},{type:\"Store\",subtype:\"Public\",platform:\"ETR\",match:\"store.hp.com\",matchDev:[\/(qa|hotfix|itg|test|uat|perf|test)[0-9]*\\.store\/,\/(genuiitga|essc-web-(dev|itg)[0-9]*)\\.(houston|austin)\\.hp\\.com\/],udl:\"store.hp.com\/app\/\",rsid:function(){return N(\"hphqglobal,hphqetrstagetemp,hpcsecamsushhos,hphqnahpshopping\")},rsidDev:\"hphqetr1dev1,hphqatlasdev1\"},{type:\"Support\",subtype:\"HPSC\",platform:\"HPSC\",\nmatch:\"www2.hp.com\/hpsc\"},{type:\"Support\",subtype:\"ProdReg\",platform:\"ProdReg\",match:\"register.hp.com\"},{type:\"Support\",subtype:\"PartSurfer\",platform:\"PartSurfer\",match:\"partsurfer.hp.com\"},{type:\"Support\",subtype:\"Parts\",platform:\"Parts\",match:\"parts.hp.com\"},{type:\"Support\",subtype:\"ProdSetup\",platform:\"ProdSetup\",match:\"123.hp.com\"},{type:\"Support\",subtype:\"Forums\",platform:\"Forums\",match:\"h30434.www3.hp.com\"},{type:\"Support\",subtype:\"LitServer\",platform:\"LitServer\",match:\"h20195.www2.hp.com\"},\n{type:\"Support\",platform:\"Support\",match:\"support.hp.com\",matchDev:\/((uat|itgqa|hotfix|itg|test|uat|perf|test)[0-9]*\\.support)\\.hp\\.com\/},{type:\"PrintServices\",subtype:\"FutureSmartCompass\",platform:\"Tridion\",match:\"futuresmartcompass.ext.hp.com\",matchDev:[\"stg-futuresmartcompass.ext.hp.com\",\"futuresmartcompass.ext.hp.com.s3-website-us-west-2.amazonaws.com\"]},{type:\"PrintServices\",subtype:\"SureSupply\",platform:\"SureSupply\",match:\"h22203.www2.hp.com\/suresupply\"},{type:\"PrintServices\",subtype:\"InstantInk\",\nplatform:\"HPconnected\",match:\"instantink.hpconnected.com\"},{type:\"PrintServices\",subtype:\"HPConnected\",platform:\"HPconnected\",match:\"hpconnected.com\"},{type:\"PrintServices\",subtype:\"CarePackCentral\",platform:\"Tridion\",match:\"cpc.ext.hp.com\"},{type:\"B2B\",subtype:\"Elite\",platform:\"B2B\",match:\"h20143.www2.hp.com\"},{type:\"B2B\",subtype:\"Portal\",platform:\"B2Bportal\",match:\"b2b.hp.com\"},{type:\"B2B\",subtype:\"DaaS-APM\",platform:\"DaaS-APM\",match:\"hpdaas.com\",matchDev:[\"stable.lightaria.com\",\"usstagingms.hpdaas.com\",\n\"eustagingms.hpdaas.com\",\"infogain.lightaria.com\"],rsid:\"hphqglobal,hphqtouchpoint\",rsidDev:\"hphqtouchpointdev\"},{type:\"Partner\",subtype:\"Portal\",platform:\"PartnerPortal\",match:[\"partner.hp.com\",\"passport.hp.com\"]},{type:\"Partner\",subtype:\"ChannelServicesNetwork\",platform:\"Tridion\",match:\"h30125.www3.hp.com\"},{type:\"Partner\",subtype:\"SalesCentral\",platform:\"SalesCentralHome\",match:[\"hpsalescentral.com\",\"sales.hpcontent.com\"]},{type:\"Partner\",subtype:\"hpbc\",platform:\"ITCS\",match:\"hpbusinesscentral.com\",\nmatchDev:[\"hpibc.hubub.com\",\"hpi-bc-dev-web.hpsalescentral.com\"],udl:!0,country:function(){var d=_A.isS(window.hp_country_language)?_A.LC(window.hp_country_language):\"\",e=d.substring(3,5);return 5==d.length\u0026\u0026\"-\"==d[2]\u0026\u0026S(e)?e:\"\"},language:function(){var d=_A.isS(window.hp_country_language)?_A.LC(window.hp_country_language):\"\",e=d.substring(0,2),h=d.substring(3,5);return 5==d.length\u0026\u0026\"-\"==d[2]\u0026\u0026S(h)?e:\"\"},rsid:function(){return N(\"hphqglobal,hphqhpbc\")},rsidDev:\"hqhqglobaldev,hphqhpbcdev\"},{type:\"About\",\nsubtype:\"Contact\",platform:\"Tridion\",match:\/www8\\.hp\\.com\\\/[^\\\/]+\\\/[^\\\/]+\\\/contact-hp\/},{type:\"About\",subtype:\"Careers\",platform:function(d){d=_A.parseUri(_A.LC(d));d=d.hostname;return 0\u003Ed.indexOf(\"www8\")?\"www3\":\"Tridion\"},match:[\"h30631.www3.hp.com\",\/www8\\.hp\\.com\\\/[^\\\/]+\\\/[^\\\/]+\\\/jobs\/]},{type:\"About\",subtype:\"Investor\",platform:\"www3\",match:\"h30261.www3.hp.com\"},{type:\"About\",subtype:\"Sustainable\",platform:\"Tridion\",match:\/www8\\.hp\\.com\\\/[^\\\/]+\\\/[^\\\/]+\\\/hp-information\\\/global-citizenship\/},{type:\"About\",\nsubtype:\"PressCenter\",platform:\"AEM\",match:\"press.ext.hp.com\",matchDev:\"stg-press.ext.hp.com\",udl:!0,rsid:function(){return N(\"hphqglobal,hphqnrb\")}},{type:\"About\",subtype:\"Garage\",platform:\"AEM\",match:\"garage.ext.hp.com\",matchDev:\"stg-garage.ext.hp.com\",udl:!0,rsid:function(){return N(\"hphqglobal\")}},{type:\"About\",subtype:\"NewsroomBlog\",platform:\"AEM\",match:\"newsblog.ext.hp.com\",matchDev:\"stg-newsblog.ext.hp.com\",udl:!0,rsid:function(){return N(\"hphqglobal,hphqnrb\")}},{type:\"PubSector\",subtype:\"Government\",\nplatform:\"Government\",match:\"government.hp.com\"},{type:\"PubSector\",subtype:\"Compaq\",platform:\"Compaq\",match:\"compaq.com\"},{type:\"Marketing\",subtype:\"EngineeredBy\",platform:\"EngineeredBy\",match:\"engineeredby.hp.com\"},{type:\"Marketing\",subtype:\"FitStation\",platform:\"FitStation\",matchDev:\/hp-ui-fitstation-dev\\..*amazonaws\\.com\/,match:\"engineeredby.hpfitstation.com\"},{type:\"Marketing\",subtype:\"Lookbook\",platform:\"Lookbook\",match:\"lookbook.hp.com\"},{type:\"Marketing\",subtype:\"HelpMeChoose\",platform:\"Tridion\",\nmatch:\"helpmechoose.ext.hp.com\"},{type:\"Marketing\",subtype:\"Campaign\",platform:\"AEM\",match:\"campaigns.ext.hp.com\",matchDev:\"stg-garage.ext.hp.com\",rsid:function(){return N(\"hphqglobal\")}},{type:\"Marketing\",subtype:\"QR\",platform:\"ITCS\",match:\"qrq.itcs.hp.com\",matchDev:[\"qrx.itcs.hp.com\",\"dev-qrcode.hubub.com\"],country:function(d){return _A.parseUri(d).args.cc||\"us\"},language:function(d){return _A.parseUri(d).args.ll||\"en\"},udl:!0,rsid:function(){return N(\"hphqglobal,hphqqr\")},rsidDev:\"hqhqglobaldev,hphqqrdev\"},\n{type:\"Marketing\",subtype:\"FindReseller\",platform:\"ITCS\",match:\"locator.itcs.hp.com\",matchDev:\"staging.locator.itcs.hp.com\"},{type:\"Marketing\",subtype:\"EloquaLanding\",platform:\"Eloqua\",match:\"enable.hp.com\",udl:!0,rsid:function(){return N(\"hphqglobal\")}},{type:\"Marketing\",subtype:\"Main\",platform:\"Tridion\",match:\/(www[2345678]?|m|ext|welcome|jp)\\.hp\\.com\/,matchDev:[\/((houston|austin)\\.hp\\.com|hpicorp\\.net)\/,\"author-aem.ext.hp.com\",\"hp-ui-homepage.s3.amazonaws.com\",\"52.15.218.35\"]},{type:\"Intranet\",\nsubtype:\"BrandExperience\",platform:\"BrandExperience\",match:[\"h10014.www1.hp.com\/hpweb\/experience\",function(d){return-1\u003Cd.indexOf(\"h10014.www1.hp.com\/hpweb\/login.aspx?attempturl\\x3d%2fhpweb%2fexperience%2findex.aspx\")},\"brandcentral.int.hp.com\/\"],matchDev:\"dev.brandcentral.int.hp.com\"},{type:\"Omen\",subtype:\"Main\",platform:\"Omen\",match:[\"oemn.com\",\"omen.gg\"],rsid:function(){return N(\"hphqglobal,hphqomen\")}},{type:\"Non-HP\",subtype:\"Webtransformer\",platform:\"Godaddy\",matchDev:\"webtransformer.com\",udl:!0,\nrsid:\"webt\",rsidDev:\"webtdev\",nonHP:!0}];C.url=d=d||ha.href;0\u003C_A.iO(d,\"#\")\u0026\u0026(d=d.substring(0,_A.iO(d,\"#\")));0\u003C_A.iO(d,\"?\")\u0026\u0026(d=d.substring(0,_A.iO(d,\"?\")));d=_A.LC(d);var F=-1\u003C_A.iO(d,\"\/\/\")?d.substring(_A.iO(d,\"\/\/\")+2):d;F=-1\u003C_A.iO(F,\"\/\")?F.substring(_A.iO(F,\"\/\")):\"\";hn=_A.LC(ha.hostname);B();B=ba(W);C.dev=!!B||-1\u003Cd.indexOf(\"\/\/localhost\");_A.isO(window._A.section)\u0026\u0026window._A.section.dev\u0026\u0026(C.dev=e);B||(B=ba(t));if(B){for(z in B)z==W||z==t?C[t]=C.dev?B[W]:B[t]:\"udl\"==z?C.udl=_A.isS(B[z])?ca(B[z]):B[z]:\nfa(z)||(C[z]=da(B[z],B,z));C[M]=q=da(B[M],B,M)||q||\"??\";C[T]=w=da(B[T],B,T)||w||\"??\";C[R]=m=J()||\"AMS\";C[la]=K()||\"???\";B[L]\u0026\u0026(C[L]=da(B[L],B,L));B[Q]\u0026\u0026(C[Q]=da(B[Q],B,Q))}else C.type=_A.getShortHn(C.url),-1==C.type.indexOf(\"hp.com\")\u0026\u0026(C.type=_A.getOwnerHn(C.url),C.nonHP=e);if(ha.href==C.url)for(z in _A.isO(h.section)||(h.section={}),C)h.section[z]=C[z];return C},window._A.getSiteSection(),window._A.onHP=function(d){d=_A.getSiteSection(d);var h=d.type;return!(\"Non-HP\"==h||d.nonHP)});\n_A.isF(window._A.optOut)||(window._A.optOut=function(){var d=!0,h=\"1111\",e=document.location.hostname,k=\"OPT-OUT - SUPPRESS\",r=\"\",D=function(){var e=unescape(_A.cR(\"gnb_preference_cookie\")),h=0,k=\"\",m=function(e){k+=e===d?\"1\":\"0\"};if(e\u0026\u0026!e.match(\/\\(\/)){try{eval(\"o\\x3d\"+e)}catch(T){h=0}_A.isO(h)\u0026\u0026(m(!h.show_cookie_header),m(h.personalize_data),m(h.collect_anonymous_data),m(h.show_ads))}return k};h=_A.cR(\"hpeuck_prefs\")||D()||h;D=h.split(\"\");var q=!d;var w=(_A.isO(_A.section)?_A.section.cc:\"\")||\"us\";\nw=[\"\",\"PERSONALI\"+(\"us\"==w||\"ca\"==w?\"Z\":\"S\")+\"ATION\",\"PERFORMANCE \\x26 ANALYTICS\",\"TARGETING\"];if(-1\u003Ce.indexOf(\"hpe.com\")||-1\u003Ce.indexOf(\"hpecorp.net\"))console.log(\"ERROR: HPE page attempting to launch HPI tag\"+(r?\": \"+r:\"\")),q=d;3==m\u0026\u0026_A.isO(_A.section)\u0026\u0026\"cn\"==_A.section.country\u0026\u0026(console.log(k,\"Disabled remarketing tag on China page\",r?\"(\"+r+\")\":\"\"),q=d);if(!q){4\u003ED.length\u0026\u0026D.push([\"1\",\"1\",\"1\",\"1\"]);for(e=0;e\u003Carguments.length;e++)switch(q=arguments[e]){case \"personalize\":case \"personalise\":case 1:var m=\n1;break;case \"analytics\":case 2:m=2;break;case \"remarket\":case 3:m=3;break;case 0:m=0;break;default:_A.isS(q)\u0026\u0026(r=q)}if(1==m){if(q=\"1\"!=D[2])var t=w[1]}else if(2==m){if(q=\"1\"!=D[1]||\"1\"!=D[2])t=w[2]}else if(3==m){if(q=\"1\"!=D[3])t=w[3]}else if(q=\"1111\"!=h)t=\"\";q\u0026\u0026console.log(k,t+(r?\": \"+r:\"\"))}return q});\nwindow.sToverrides=function(d){var h=[\"_hpeuck_banview_\"],e=[\"hphqemeaov2banners\"],k=window,r=k._A;r.isS(d.pageName)\u0026\u0026r.LC(d.pageName);k=r.isS(d.account||k.s_account)?d.account||k.s_account:\"\";d.events\u0026\u0026(d.events=r.addCS(d.events,\"event11\",-1),d.events=r.addCS(d.events,\"event92\",-1),d.events=r.addCS(d.events,\"event93\",-1));d.prop61\u0026\u0026(d.prop61=\"\",delete d.prop61);d.linkTrackVars=r.addCS(d.linkTrackVars||\"None\",\"prop61\",-1);d.linkTrackEvents=r.addCS(d.linkTrackEvents||\"None\",\"event93\",-1);if(0\u003Er.iO(d.pageName,\nh)\u0026\u00260\u003Er.iO(k,e)){d.prop30=r.hpPrevPageName=d.prop73||\"\";r.isF(r.incDepth)\u0026\u0026r.incDepth(1);h=r.getVisitNum();e=r.getPageDepth();k=r.getCallDepth();var D=r.getLtDepth(),q=r.getAdobeID();1==e\u0026\u0026(d.events=r.addCS(d.events,\"event11\",1));2==e\u0026\u0026(d.events=r.addCS(d.events,\"event92\",1));2==k\u0026\u0026(d.events=r.addCS(d.events,\"event93\",1));q\u0026\u0026-1\u003Ch\u0026\u0026-1\u003Ce\u0026\u0026-1\u003CD\u0026\u0026(d.prop61=q+\":\"+(\"000\"+h).slice(-4)+\":\"+(\"000\"+e).slice(-4)+\":\"+(\"0\"+D).slice(-2),r.addLTV(\"prop61\"))}else console.log(\"Internal s.t call!\")};\nwindow.sTpostOverrides=function(d){d=window;d.adobeStCalled=!0};\nwindow.sTLoverrides=function(d,h,e,k){var r=\"d\\x26b demandbase hpeuck namogoo optimizelylayerdecision optly customized.page\".split(\" \");h=window;h=h._A;var D=h.isS(k)?h.LC(k):\"\";h.hpPrevPageName\u0026\u0026(d.prop30=h.hpPrevPageName,h.addLTV(\"prop30\"));k\u0026\u0026(e=\"o\"==e?\"c|\":\"d\"==e?\"d|\":\"e\"==e?\"e|\":\"\",d.prop41=e+k,h.addLTV(\"prop41\"));d.events\u0026\u0026(d.events=h.addCS(d.events,\"event11\",-1),d.events=h.addCS(d.events,\"event92\",-1),d.events=h.addCS(d.events,\"event93\",-1));d.prop61\u0026\u0026(d.prop61=\"\",delete d.prop61);d.linkTrackVars=\nh.addCS(d.linkTrackVars||\"None\",\"prop61\",-1);d.linkTrackEvents=h.addCS(d.linkTrackEvents||\"None\",\"event93\",-1);if(0\u003Eh.iO(D,r)){h.isF(h.incDepth)\u0026\u0026h.incDepth(0);k=h.getVisitNum();e=h.getPageDepth();r=h.getCallDepth();D=h.getLtDepth();var q=h.getAdobeID();2==r\u0026\u0026(d.events=h.addCS(d.events,\"event93\",1),h.addLTV(\"event93\"));q\u0026\u0026-1\u003Ck\u0026\u0026-1\u003Ce\u0026\u0026-1\u003CD\u0026\u0026(d.prop61=q+\":\"+(\"000\"+k).slice(-4)+\":\"+(\"000\"+e).slice(-4)+\":\"+(\"0\"+D).slice(-2),h.addLTV(\"prop61\"))}else console.log(\"Internal s.tl call!\")};\nwindow.sGIoverrides=function(d){var h=window,e=d,k=function(d){if(!d||\"string\"!=typeof d)return d;d=d.split(\",\");var e,h=[];for(e=0;e\u003Cd.length;e++){var k=d[e].toLowerCase();if(0==k.indexOf(\"hpe-\")||\"hphqwwesg\"==k||\"hpcstsg\"==k)d[e]=\"\"}for(e=0;e\u003Cd.length;e++)d[e]\u0026\u0026h.push(d[e]);0==h.length\u0026\u0026h.push(\"hphqglobal\");return h.join(\",\")};try{d=k(d),h.s\u0026\u0026\"object\"==typeof h.s\u0026\u0026h.s.account\u0026\u0026(h.s.account=k(h.s.account)),h.s_account\u0026\u0026(h.s_account=k(h.s_account))}catch(r){}e!=d\u0026\u0026console.log(\"sGIoverrides() orig:\",\ne,\"new:\",d);return d};window.sSAoverrides=window.sGIoverrides;\u003C\/script\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":56
    },{
      "function":"__html",
      "setup_tags":["list",["tag",63,1]],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Etry{var lastP,intervalId,title,html5Video,i;(function(){var d=function(c,a){intervalId=setInterval(function(){var b=c.target.duration,d=c.target.currentTime;b=1.5\u003E=b-d?1:(Math.floor(d\/b*4)\/4).toFixed(2);if(!lastP[a]||b\u003ElastP[a])0!=100*b\u0026\u0026(lastP[a]=b,dataLayer.push({event:\"e_video\",videoAction:100*b+\"% viewed\",videoLabel:a,videoTimeViewed:_cpga.getVideoTimeViewed(\"html5\",a)})),_cpga.resetVideoTimeViewed(\"html5\",a)},200)};lastP=[];title=\"\";html5Video=document.getElementsByTagName(\"video\");for(i=0;i\u003C\nhtml5Video.length;++i)title=html5Video[i].getElementsByTagName(\"source\")[0].src,html5Video[i].onplay=function(c){var a={event:\"e_video\",videoAction:\"play\",videoLabel:title};_cpga.videoIsFirstPlay(\"html5\",title)\u0026\u0026(a.videoStart=1,a.videoDuration=c.target.duration);dataLayer.push(a);_cpga.resetVideoTimeViewed(\"html5\",title);d(c,title)},html5Video[i].onpause=function(){dataLayer.push({event:\"e_video\",videoAction:\"pause\",videoLabel:title,videoTimeViewed:_cpga.getVideoTimeViewed(\"html5\",title)});clearInterval(intervalId)},\nhtml5Video[i].onended=function(){clearInterval(intervalId)}})()}catch(d){};\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":73
    },{
      "function":"__html",
      "once_per_load":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Ewindow._cpga=window._cpga||{};_cpga.playedVideos={};_cpga.videoIsFirstPlay=function(a,b){return\"undefined\"===typeof _cpga.playedVideos[a]||-1===_cpga.playedVideos[a][b]};_cpga.getVideoTimeViewed=function(a,b){if(_cpga.playedVideos[a]\u0026\u0026_cpga.playedVideos[a][b])return Math.round((Date.now()-_cpga.playedVideos[a][b])\/1E3)};_cpga.resetVideoTimeViewed=function(a,b){\"undefined\"===typeof _cpga.playedVideos[a]\u0026\u0026(_cpga.playedVideos[a]={});_cpga.playedVideos[a][b]=Date.now()};\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":74
    },{
      "function":"__html",
      "teardown_tags":["list",["tag",65,2]],
      "once_per_load":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E\"function\"==typeof window.AppMeasurement||window.s\u0026\u0026\"object\"==typeof window.s\u0026\u0026window.s.constructor!==Array||window._AA\u0026\u0026\"object\"==typeof window._AA\u0026\u0026window._AA.constructor!==Array||(window._AA=function(){function P(k){var a=this;a.version=\"2.3.0\";var d=window;d.s_c_in||(d.s_c_il=[],d.s_c_in=0);a._il=d.s_c_il;a._in=d.s_c_in;a._il[a._in]=a;d.s_c_in++;a._c=\"s_c\";var f=null,m=d,n;try{var l=m.parent;for(n=m.location;l\u0026\u0026l.location\u0026\u0026n\u0026\u0026\"\"+l.location!=\"\"+n\u0026\u0026m.location\u0026\u0026\"\"+l.location!=\"\"+m.location\u0026\u0026l.location.host==\nn.host;)m=l,l=m.parent}catch(c){}a.F=function(a){try{console.log(a)}catch(b){}};a.Ma=function(a){return\"\"+parseInt(a)==\"\"+a};a.replace=function(a,b,h){return!a||0\u003Ea.indexOf(b)?a:a.split(b).join(h)};a.escape=function(c){var b;if(!c)return c;c=encodeURIComponent(c);for(b=0;7\u003Eb;b++){var h=\"+~!*()'\".substring(b,b+1);0\u003C=c.indexOf(h)\u0026\u0026(c=a.replace(c,h,\"%\"+h.charCodeAt(0).toString(16).toUpperCase()))}return c};a.unescape=function(c){if(!c)return c;c=0\u003C=c.indexOf(\"+\")?a.replace(c,\"+\",\" \"):c;try{return decodeURIComponent(c)}catch(b){}return unescape(c)};\na.wb=function(){var c=d.location.hostname,b=a.fpCookieDomainPeriods,h;b||(b=a.cookieDomainPeriods);if(c\u0026\u0026!a.Ea\u0026\u0026!\/^[0-9.]+$\/.test(c)\u0026\u0026(b=b?parseInt(b):2,b=2\u003Cb?b:2,h=c.lastIndexOf(\".\"),0\u003C=h)){for(;0\u003C=h\u0026\u00261\u003Cb;)h=c.lastIndexOf(\".\",h-1),b--;a.Ea=0\u003Ch?c.substring(h):c}return a.Ea};a.c_r=a.cookieRead=function(c){c=a.escape(c);var b=\" \"+a.d.cookie,h=b.indexOf(\" \"+c+\"\\x3d\"),e=0\u003Eh?h:b.indexOf(\";\",h);c=0\u003Eh?\"\":a.unescape(b.substring(h+2+c.length,0\u003Ee?b.length:e));return\"[[B]]\"!=c?c:\"\"};a.c_w=a.cookieWrite=function(c,\nb,h){var e=a.wb(),p=a.cookieLifetime,d;b=\"\"+b;p=p?(\"\"+p).toUpperCase():\"\";h\u0026\u0026\"SESSION\"!=p\u0026\u0026\"NONE\"!=p\u0026\u0026((d=\"\"!=b?parseInt(p?p:0):-60)?(h=new Date,h.setTime(h.getTime()+1E3*d)):1==h\u0026\u0026(h=new Date,d=h.getYear(),h.setYear(d+5+(1900\u003Ed?1900:0))));return c\u0026\u0026\"NONE\"!=p?(a.d.cookie=a.escape(c)+\"\\x3d\"+a.escape(\"\"!=b?b:\"[[B]]\")+\"; path\\x3d\/;\"+(h\u0026\u0026\"SESSION\"!=p?\" expires\\x3d\"+h.toGMTString()+\";\":\"\")+(e?\" domain\\x3d\"+e+\";\":\"\"),a.cookieRead(c)==b):0};a.L=[];a.ia=function(c,b,h){if(a.Fa)return 0;a.maxDelay||(a.maxDelay=\n250);var e=0,p=(new Date).getTime()+a.maxDelay,d=a.d.visibilityState,f=[\"webkitvisibilitychange\",\"visibilitychange\"];d||(d=a.d.webkitVisibilityState);if(d\u0026\u0026\"prerender\"==d){if(!a.ja)for(a.ja=1,h=0;h\u003Cf.length;h++)a.d.addEventListener(f[h],function(){var b=a.d.visibilityState;b||(b=a.d.webkitVisibilityState);\"visible\"==b\u0026\u0026(a.ja=0,a.delayReady())});e=1;p=0}else h||a.p(\"_d\")\u0026\u0026(e=1);e\u0026\u0026(a.L.push({m:c,a:b,t:p}),a.ja||setTimeout(a.delayReady,a.maxDelay));return e};a.delayReady=function(){var c=(new Date).getTime(),\nb=0;for(a.p(\"_d\")?b=1:a.xa();0\u003Ca.L.length;){var h=a.L.shift();if(b\u0026\u0026!h.t\u0026\u0026h.t\u003Ec){a.L.unshift(h);setTimeout(a.delayReady,parseInt(a.maxDelay\/2));break}a.Fa=1;a[h.m].apply(a,h.a);a.Fa=0}};a.setAccount=a.sa=function(c){var b;if(!a.ia(\"setAccount\",arguments))if(a.account=c,a.allAccounts){var h=a.allAccounts.concat(c.split(\",\"));a.allAccounts=[];h.sort();for(b=0;b\u003Ch.length;b++)0!=b\u0026\u0026h[b-1]==h[b]||a.allAccounts.push(h[b])}else a.allAccounts=c.split(\",\")};a.foreachVar=function(c,b){var h,e,p=\"\";var d=h=\n\"\";if(a.lightProfileID){var f=a.P;(p=a.lightTrackVars)\u0026\u0026(p=\",\"+p+\",\"+a.na.join(\",\")+\",\")}else{f=a.g;if(a.pe||a.linkType)p=a.linkTrackVars,h=a.linkTrackEvents,a.pe\u0026\u0026(d=a.pe.substring(0,1).toUpperCase()+a.pe.substring(1),a[d]\u0026\u0026(p=a[d].Nb,h=a[d].Mb));p\u0026\u0026(p=\",\"+p+\",\"+a.H.join(\",\")+\",\");h\u0026\u0026p\u0026\u0026(p+=\",events,\")}b\u0026\u0026(b=\",\"+b+\",\");for(h=0;h\u003Cf.length;h++)d=f[h],(e=a[d])\u0026\u0026(!p||0\u003C=p.indexOf(\",\"+d+\",\"))\u0026\u0026(!b||0\u003C=b.indexOf(\",\"+d+\",\"))\u0026\u0026c(d,e)};a.r=function(c,b,h,e,p){var d=\"\",f,g,l,m=0;\"contextData\"==c\u0026\u0026(c=\"c\");\nif(b){for(f in b)if(!(Object.prototype[f]||p\u0026\u0026f.substring(0,p.length)!=p)\u0026\u0026b[f]\u0026\u0026(!h||0\u003C=h.indexOf(\",\"+(e?e+\".\":\"\")+f+\",\"))){var n=!1;if(m)for(g=0;g\u003Cm.length;g++)f.substring(0,m[g].length)==m[g]\u0026\u0026(n=!0);if(!n\u0026\u0026(\"\"==d\u0026\u0026(d+=\"\\x26\"+c+\".\"),g=b[f],p\u0026\u0026(f=f.substring(p.length)),0\u003Cf.length))if(n=f.indexOf(\".\"),0\u003Cn)g=f.substring(0,n),n=(p?p:\"\")+g+\".\",m||(m=[]),m.push(n),d+=a.r(g,b,h,e,n);else if(\"boolean\"==typeof g\u0026\u0026(g=g?\"true\":\"false\"),g){if(\"retrieveLightData\"==e\u0026\u00260\u003Ep.indexOf(\".contextData.\"))switch(n=f.substring(0,\n4),l=f.substring(4),f){case \"transactionID\":f=\"xact\";break;case \"channel\":f=\"ch\";break;case \"campaign\":f=\"v0\";break;default:a.Ma(l)\u0026\u0026(\"prop\"==n?f=\"c\"+l:\"eVar\"==n?f=\"v\"+l:\"list\"==n?f=\"l\"+l:\"hier\"==n\u0026\u0026(f=\"h\"+l,g=g.substring(0,255)))}d+=\"\\x26\"+a.escape(f)+\"\\x3d\"+a.escape(g)}}\"\"!=d\u0026\u0026(d+=\"\\x26.\"+c)}return d};a.usePostbacks=0;a.zb=function(){var c=\"\",b,h,e,p,d=\"\",g=\"\",l=e=\"\";if(a.lightProfileID){var m=a.P;(d=a.lightTrackVars)\u0026\u0026(d=\",\"+d+\",\"+a.na.join(\",\")+\",\")}else{m=a.g;if(a.pe||a.linkType)d=a.linkTrackVars,\ng=a.linkTrackEvents,a.pe\u0026\u0026(e=a.pe.substring(0,1).toUpperCase()+a.pe.substring(1),a[e]\u0026\u0026(d=a[e].Nb,g=a[e].Mb));d\u0026\u0026(d=\",\"+d+\",\"+a.H.join(\",\")+\",\");g\u0026\u0026(g=\",\"+g+\",\",d\u0026\u0026(d+=\",events,\"));a.events2\u0026\u0026(l+=(\"\"!=l?\",\":\"\")+a.events2)}if(a.visitor\u0026\u0026a.visitor.getCustomerIDs){e=f;if(p=a.visitor.getCustomerIDs())for(b in p)Object.prototype[b]||(h=p[b],\"object\"==typeof h\u0026\u0026(e||(e={}),h.id\u0026\u0026(e[b+\".id\"]=h.id),h.authState\u0026\u0026(e[b+\".as\"]=h.authState)));e\u0026\u0026(c+=a.r(\"cid\",e))}a.AudienceManagement\u0026\u0026a.AudienceManagement.isReady()\u0026\u0026\n(c+=a.r(\"d\",a.AudienceManagement.getEventCallConfigParams()));for(b=0;b\u003Cm.length;b++){e=m[b];p=a[e];h=e.substring(0,4);var n=e.substring(4);p||(\"events\"==e\u0026\u0026l?(p=l,l=\"\"):\"marketingCloudOrgID\"==e\u0026\u0026a.visitor\u0026\u0026(p=a.visitor.marketingCloudOrgID));if(p\u0026\u0026(!d||0\u003C=d.indexOf(\",\"+e+\",\"))){switch(e){case \"customerPerspective\":e=\"cp\";break;case \"marketingCloudOrgID\":e=\"mcorgid\";break;case \"supplementalDataID\":e=\"sdid\";break;case \"timestamp\":e=\"ts\";break;case \"dynamicVariablePrefix\":e=\"D\";break;case \"visitorID\":e=\n\"vid\";break;case \"marketingCloudVisitorID\":e=\"mid\";break;case \"analyticsVisitorID\":e=\"aid\";break;case \"audienceManagerLocationHint\":e=\"aamlh\";break;case \"audienceManagerBlob\":e=\"aamb\";break;case \"authState\":e=\"as\";break;case \"pageURL\":e=\"g\";255\u003Cp.length\u0026\u0026(a.pageURLRest=p.substring(255),p=p.substring(0,255));break;case \"pageURLRest\":e=\"-g\";break;case \"referrer\":e=\"r\";break;case \"vmk\":case \"visitorMigrationKey\":e=\"vmt\";break;case \"visitorMigrationServer\":e=\"vmf\";a.ssl\u0026\u0026a.visitorMigrationServerSecure\u0026\u0026\n(p=\"\");break;case \"visitorMigrationServerSecure\":e=\"vmf\";!a.ssl\u0026\u0026a.visitorMigrationServer\u0026\u0026(p=\"\");break;case \"charSet\":e=\"ce\";break;case \"visitorNamespace\":e=\"ns\";break;case \"cookieDomainPeriods\":e=\"cdp\";break;case \"cookieLifetime\":e=\"cl\";break;case \"variableProvider\":e=\"vvp\";break;case \"currencyCode\":e=\"cc\";break;case \"channel\":e=\"ch\";break;case \"transactionID\":e=\"xact\";break;case \"campaign\":e=\"v0\";break;case \"latitude\":e=\"lat\";break;case \"longitude\":e=\"lon\";break;case \"resolution\":e=\"s\";break;case \"colorDepth\":e=\n\"c\";break;case \"javascriptVersion\":e=\"j\";break;case \"javaEnabled\":e=\"v\";break;case \"cookiesEnabled\":e=\"k\";break;case \"browserWidth\":e=\"bw\";break;case \"browserHeight\":e=\"bh\";break;case \"connectionType\":e=\"ct\";break;case \"homepage\":e=\"hp\";break;case \"events\":l\u0026\u0026(p+=(\"\"!=p?\",\":\"\")+l);if(g)for(n=p.split(\",\"),p=\"\",h=0;h\u003Cn.length;h++){var k=n[h];var x=k.indexOf(\"\\x3d\");0\u003C=x\u0026\u0026(k=k.substring(0,x));x=k.indexOf(\":\");0\u003C=x\u0026\u0026(k=k.substring(0,x));0\u003C=g.indexOf(\",\"+k+\",\")\u0026\u0026(p+=(p?\",\":\"\")+n[h])}break;case \"events2\":p=\n\"\";break;case \"contextData\":c+=a.r(\"c\",a[e],d,e);p=\"\";break;case \"lightProfileID\":e=\"mtp\";break;case \"lightStoreForSeconds\":e=\"mtss\";a.lightProfileID||(p=\"\");break;case \"lightIncrementBy\":e=\"mti\";a.lightProfileID||(p=\"\");break;case \"retrieveLightProfiles\":e=\"mtsr\";break;case \"deleteLightProfiles\":e=\"mtsd\";break;case \"retrieveLightData\":a.retrieveLightProfiles\u0026\u0026(c+=a.r(\"mts\",a[e],d,e));p=\"\";break;default:a.Ma(n)\u0026\u0026(\"prop\"==h?e=\"c\"+n:\"eVar\"==h?e=\"v\"+n:\"list\"==h?e=\"l\"+n:\"hier\"==h\u0026\u0026(e=\"h\"+n,p=p.substring(0,\n255)))}p\u0026\u0026(c+=\"\\x26\"+e+\"\\x3d\"+(\"pev\"!=e.substring(0,3)?a.escape(p):p))}\"pev3\"==e\u0026\u0026a.e\u0026\u0026(c+=a.e)}return c};a.D=function(a){var b=a.tagName;if(\"undefined\"!=\"\"+a.Sb||\"undefined\"!=\"\"+a.Ib\u0026\u0026\"HTML\"!=(\"\"+a.Ib).toUpperCase())return\"\";b=b\u0026\u0026b.toUpperCase?b.toUpperCase():\"\";\"SHAPE\"==b\u0026\u0026(b=\"\");b\u0026\u0026((\"INPUT\"==b||\"BUTTON\"==b)\u0026\u0026a.type\u0026\u0026a.type.toUpperCase?b=a.type.toUpperCase():!b\u0026\u0026a.href\u0026\u0026(b=\"A\"));return b};a.Ia=function(a){var b=d.location,c=a.href?a.href:\"\";var e=c.indexOf(\":\");var p=c.indexOf(\"?\");var f=c.indexOf(\"\/\");\nc\u0026\u0026(0\u003Ee||0\u003C=p\u0026\u0026e\u003Ep||0\u003C=f\u0026\u0026e\u003Ef)\u0026\u0026(p=a.protocol\u0026\u00261\u003Ca.protocol.length?a.protocol:b.protocol?b.protocol:\"\",e=b.pathname.lastIndexOf(\"\/\"),c=(p?p+\"\/\/\":\"\")+(a.host?a.host:b.host?b.host:\"\")+(\"\/\"!=c.substring(0,1)?b.pathname.substring(0,0\u003Ee?0:e)+\"\/\":\"\")+c);return c};a.M=function(c){var b=a.D(c),h,e,d=\"\",f=0;return b\u0026\u0026(h=c.protocol,e=c.onclick,!c.href||\"A\"!=b\u0026\u0026\"AREA\"!=b||e\u0026\u0026h\u0026\u0026!(0\u003Eh.toLowerCase().indexOf(\"javascript\"))?e?(d=a.replace(a.replace(a.replace(a.replace(\"\"+e,\"\\r\",\"\"),\"\\n\",\"\"),\"\\t\",\"\"),\" \",\"\"),f=2):\n\"INPUT\"==b||\"SUBMIT\"==b?(c.value?d=c.value:c.innerText?d=c.innerText:c.textContent\u0026\u0026(d=c.textContent),f=3):\"IMAGE\"==b\u0026\u0026c.src\u0026\u0026(d=c.src):d=a.Ia(c),d)?{id:d.substring(0,100),type:f}:0};a.Qb=function(c){for(var b=a.D(c),h=a.M(c);c\u0026\u0026!h\u0026\u0026\"BODY\"!=b;)if(c=c.parentElement?c.parentElement:c.parentNode)b=a.D(c),h=a.M(c);h\u0026\u0026\"BODY\"!=b||(c=0);c\u0026\u0026(b=c.onclick?\"\"+c.onclick:\"\",0\u003C=b.indexOf(\".tl(\")||0\u003C=b.indexOf(\".trackLink(\"))\u0026\u0026(c=0);return c};a.Hb=function(){var c,b=a.linkObject,h=a.linkType,e=a.linkURL,f;a.oa=\n1;b||(a.oa=0,b=a.clickObject);if(b){var g=a.D(b);for(c=a.M(b);b\u0026\u0026!c\u0026\u0026\"BODY\"!=g;)if(b=b.parentElement?b.parentElement:b.parentNode)g=a.D(b),c=a.M(b);c\u0026\u0026\"BODY\"!=g||(b=0);if(b\u0026\u0026!a.linkObject){var l=b.onclick?\"\"+b.onclick:\"\";if(0\u003C=l.indexOf(\".tl(\")||0\u003C=l.indexOf(\".trackLink(\"))b=0}}else a.oa=1;!e\u0026\u0026b\u0026\u0026(e=a.Ia(b));e\u0026\u0026!a.linkLeaveQueryString\u0026\u0026(f=e.indexOf(\"?\"),0\u003C=f\u0026\u0026(e=e.substring(0,f)));if(!h\u0026\u0026e){var m=0,n=0,k;if(a.trackDownloadLinks\u0026\u0026a.linkDownloadFileTypes){l=e.toLowerCase();f=l.indexOf(\"?\");var x=l.indexOf(\"#\");\n0\u003C=f?0\u003C=x\u0026\u0026x\u003Cf\u0026\u0026(f=x):f=x;0\u003C=f\u0026\u0026(l=l.substring(0,f));f=a.linkDownloadFileTypes.toLowerCase().split(\",\");for(x=0;x\u003Cf.length;x++)(k=f[x])\u0026\u0026l.substring(l.length-(k.length+1))==\".\"+k\u0026\u0026(h=\"d\")}if(a.trackExternalLinks\u0026\u0026!h\u0026\u0026(l=e.toLowerCase(),a.La(l)\u0026\u0026(a.linkInternalFilters||(a.linkInternalFilters=d.location.hostname),f=0,a.linkExternalFilters?(f=a.linkExternalFilters.toLowerCase().split(\",\"),m=1):a.linkInternalFilters\u0026\u0026(f=a.linkInternalFilters.toLowerCase().split(\",\")),f))){for(x=0;x\u003Cf.length;x++)k=f[x],\n0\u003C=l.indexOf(k)\u0026\u0026(n=1);n?m\u0026\u0026(h=\"e\"):m||(h=\"e\")}}a.linkObject=b;a.linkURL=e;a.linkType=h;if(a.trackClickMap||a.trackInlineStats)a.e=\"\",b\u0026\u0026(h=a.pageName,e=1,b=b.sourceIndex,h||(h=a.pageURL,e=0),d.s_objectID\u0026\u0026(c.id=d.s_objectID,b=c.type=1),h\u0026\u0026c\u0026\u0026c.id\u0026\u0026g\u0026\u0026(a.e=\"\\x26pid\\x3d\"+a.escape(h.substring(0,255))+(e?\"\\x26pidt\\x3d\"+e:\"\")+\"\\x26oid\\x3d\"+a.escape(c.id.substring(0,100))+(c.type?\"\\x26oidt\\x3d\"+c.type:\"\")+\"\\x26ot\\x3d\"+g+(b?\"\\x26oi\\x3d\"+b:\"\")))};a.Ab=function(){var c=a.oa,b=a.linkType,h=a.linkURL,e=a.linkName;\nb\u0026\u0026(h||e)\u0026\u0026(b=b.toLowerCase(),\"d\"!=b\u0026\u0026\"e\"!=b\u0026\u0026(b=\"o\"),a.pe=\"lnk_\"+b,a.pev1=h?a.escape(h):\"\",a.pev2=e?a.escape(e):\"\",c=1);a.abort\u0026\u0026(c=0);if(a.trackClickMap||a.trackInlineStats||a.ActivityMap){b={};h=0;var d=a.cookieRead(\"s_sq\"),f=d?d.split(\"\\x26\"):0,g,l;d=0;if(f)for(g=0;g\u003Cf.length;g++){var m=f[g].split(\"\\x3d\");e=a.unescape(m[0]).split(\",\");m=a.unescape(m[1]);b[m]=e}e=a.account.split(\",\");g={};for(l in a.contextData)l\u0026\u0026!Object.prototype[l]\u0026\u0026\"a.activitymap.\"==l.substring(0,14)\u0026\u0026(g[l]=a.contextData[l],\na.contextData[l]=\"\");a.e=a.r(\"c\",g)+(a.e?a.e:\"\");if(c||a.e){c\u0026\u0026!a.e\u0026\u0026(d=1);for(m in b)if(!Object.prototype[m])for(l=0;l\u003Ce.length;l++)for(d\u0026\u0026(f=b[m].join(\",\"),f==a.account\u0026\u0026(a.e+=(\"\\x26\"!=m.charAt(0)?\"\\x26\":\"\")+m,b[m]=[],h=1)),g=0;g\u003Cb[m].length;g++)f=b[m][g],f==e[l]\u0026\u0026(d\u0026\u0026(a.e+=\"\\x26u\\x3d\"+a.escape(f)+(\"\\x26\"!=m.charAt(0)?\"\\x26\":\"\")+m+\"\\x26u\\x3d0\"),b[m].splice(g,1),h=1);c||(h=1);if(h){d=\"\";g=2;!c\u0026\u0026a.e\u0026\u0026(d=a.escape(e.join(\",\"))+\"\\x3d\"+a.escape(a.e),g=1);for(m in b)!Object.prototype[m]\u0026\u00260\u003Cg\u0026\u00260\u003Cb[m].length\u0026\u0026\n(d+=(d?\"\\x26\":\"\")+a.escape(b[m].join(\",\"))+\"\\x3d\"+a.escape(m),g--);a.cookieWrite(\"s_sq\",d)}}}return c};a.Bb=function(){if(!a.Lb){var c=new Date,b=m.location,h=\"1.2\",e=a.cookieWrite(\"s_cc\",\"true\",0)?\"Y\":\"N\",d=\"\",f=\"\";if(c.setUTCDate\u0026\u0026(h=\"1.3\",(0).toPrecision\u0026\u0026(h=\"1.5\",c=[],c.forEach))){h=\"1.6\";var g=0;var l={};try{g=new Iterator(l),g.next\u0026\u0026(h=\"1.7\",c.reduce\u0026\u0026(h=\"1.8\",h.trim\u0026\u0026(h=\"1.8.1\",Date.parse\u0026\u0026(h=\"1.8.2\",Object.create\u0026\u0026(h=\"1.8.5\")))))}catch(t){}}l=screen.width+\"x\"+screen.height;c=navigator.javaEnabled()?\n\"Y\":\"N\";g=screen.pixelDepth?screen.pixelDepth:screen.colorDepth;var n=a.w.innerWidth?a.w.innerWidth:a.d.documentElement.offsetWidth;var k=a.w.innerHeight?a.w.innerHeight:a.d.documentElement.offsetHeight;try{a.b.addBehavior(\"#default#homePage\"),d=a.b.Rb(b)?\"Y\":\"N\"}catch(t){}try{a.b.addBehavior(\"#default#clientCaps\"),f=a.b.connectionType}catch(t){}a.resolution=l;a.colorDepth=g;a.javascriptVersion=h;a.javaEnabled=c;a.cookiesEnabled=e;a.browserWidth=n;a.browserHeight=k;a.connectionType=f;a.homepage=d;\na.Lb=1}};a.Q={};a.loadModule=function(c,b){var h=a.Q[c];if(!h){h=d[\"AppMeasurement_Module_\"+c]?new d[\"AppMeasurement_Module_\"+c](a):{};a.Q[c]=a[c]=h;h.eb=function(){return h.ib};h.jb=function(b){if(h.ib=b)a[c+\"_onLoad\"]=b,a.ia(c+\"_onLoad\",[a,h],1)||b(a,h)};try{Object.defineProperty?Object.defineProperty(h,\"onLoad\",{get:h.eb,set:h.jb}):h._olc=1}catch(e){h._olc=1}}b\u0026\u0026(a[c+\"_onLoad\"]=b,a.ia(c+\"_onLoad\",[a,h],1)||b(a,h))};a.p=function(c){var b,h;for(b in a.Q)if(!Object.prototype[b]\u0026\u0026(h=a.Q[b])\u0026\u0026(h._olc\u0026\u0026\nh.onLoad\u0026\u0026(h._olc=0,h.onLoad(a,h)),h[c]\u0026\u0026h[c]()))return 1;return 0};a.Db=function(){var c=Math.floor(1E13*Math.random()),b=a.visitorSampling,h=a.visitorSamplingGroup;h=\"s_vsn_\"+(a.visitorNamespace?a.visitorNamespace:a.account)+(h?\"_\"+h:\"\");var e=a.cookieRead(h);if(b){b*=100;e\u0026\u0026(e=parseInt(e));if(!e){if(!a.cookieWrite(h,c))return 0;e=c}if(e%1E4\u003Eb)return 0}return 1};a.R=function(c,b){var h,e,d,f,g;for(h=0;2\u003Eh;h++){var l=0\u003Ch?a.Aa:a.g;for(e=0;e\u003Cl.length;e++)if(d=l[e],(f=c[d])||c[\"!\"+d]){if(!b\u0026\u0026(\"contextData\"==\nd||\"retrieveLightData\"==d)\u0026\u0026a[d])for(g in a[d])f[g]||(f[g]=a[d][g]);a[d]=f}}};a.Va=function(c,b){var h,e;for(h=0;2\u003Eh;h++){var d=0\u003Ch?a.Aa:a.g;for(e=0;e\u003Cd.length;e++){var f=d[e];c[f]=a[f];b||c[f]||(c[\"!\"+f]=1)}}};a.vb=function(a){var b,c,e,d,f,g=0,l,m=\"\",n=\"\";if(a\u0026\u0026255\u003Ca.length\u0026\u0026(b=\"\"+a,c=b.indexOf(\"?\"),0\u003Cc\u0026\u0026(l=b.substring(c+1),b=b.substring(0,c),d=b.toLowerCase(),e=0,\"http:\/\/\"==d.substring(0,7)?e+=7:\"https:\/\/\"==d.substring(0,8)\u0026\u0026(e+=8),c=d.indexOf(\"\/\",e),0\u003Cc\u0026\u0026(d=d.substring(e,c),f=b.substring(c),b=\nb.substring(0,c),0\u003C=d.indexOf(\"google\")?g=\",q,ie,start,search_key,word,kw,cd,\":0\u003C=d.indexOf(\"yahoo.co\")\u0026\u0026(g=\",p,ei,\"),g\u0026\u0026l)))){if((a=l.split(\"\\x26\"))\u0026\u00261\u003Ca.length){for(e=0;e\u003Ca.length;e++)d=a[e],c=d.indexOf(\"\\x3d\"),0\u003Cc\u0026\u00260\u003C=g.indexOf(\",\"+d.substring(0,c)+\",\")?m+=(m?\"\\x26\":\"\")+d:n+=(n?\"\\x26\":\"\")+d;m\u0026\u0026n?l=m+\"\\x26\"+n:n=\"\"}c=253-(l.length-n.length)-b.length;a=b+(0\u003Cc?f.substring(0,c):\"\")+\"?\"+l}return a};a.ab=function(c){var b=a.d.visibilityState,h=[\"webkitvisibilitychange\",\"visibilitychange\"];b||(b=a.d.webkitVisibilityState);\nif(b\u0026\u0026\"prerender\"==b){if(c)for(b=0;b\u003Ch.length;b++)a.d.addEventListener(h[b],function(){var b=a.d.visibilityState;b||(b=a.d.webkitVisibilityState);\"visible\"==b\u0026\u0026c()});return!1}return!0};a.ea=!1;a.J=!1;a.lb=function(){a.J=!0;a.j()};a.ca=!1;a.V=!1;a.hb=function(c){a.marketingCloudVisitorID=c;a.V=!0;a.j()};a.fa=!1;a.W=!1;a.mb=function(c){a.visitorOptedOut=c;a.W=!0;a.j()};a.Z=!1;a.S=!1;a.Xa=function(c){a.analyticsVisitorID=c;a.S=!0;a.j()};a.ba=!1;a.U=!1;a.Za=function(c){a.audienceManagerLocationHint=c;\na.U=!0;a.j()};a.aa=!1;a.T=!1;a.Ya=function(c){a.audienceManagerBlob=c;a.T=!0;a.j()};a.$a=function(c){a.maxDelay||(a.maxDelay=250);return a.p(\"_d\")?(c\u0026\u0026setTimeout(function(){c()},a.maxDelay),!1):!0};a.da=!1;a.I=!1;a.xa=function(){a.I=!0;a.j()};a.isReadyToTrack=function(){var c=!0,b=a.visitor,h,e,d;a.ea||a.J||(a.ab(a.lb)?a.J=!0:a.ea=!0);if(a.ea\u0026\u0026!a.J)return!1;b\u0026\u0026b.isAllowed()\u0026\u0026(a.ca||a.marketingCloudVisitorID||!b.getMarketingCloudVisitorID||(a.ca=!0,a.marketingCloudVisitorID=b.getMarketingCloudVisitorID([a,\na.hb]),a.marketingCloudVisitorID\u0026\u0026(a.V=!0)),a.fa||a.visitorOptedOut||!b.isOptedOut||(a.fa=!0,a.visitorOptedOut=b.isOptedOut([a,a.mb]),a.visitorOptedOut!=f\u0026\u0026(a.W=!0)),a.Z||a.analyticsVisitorID||!b.getAnalyticsVisitorID||(a.Z=!0,a.analyticsVisitorID=b.getAnalyticsVisitorID([a,a.Xa]),a.analyticsVisitorID\u0026\u0026(a.S=!0)),a.ba||a.audienceManagerLocationHint||!b.getAudienceManagerLocationHint||(a.ba=!0,a.audienceManagerLocationHint=b.getAudienceManagerLocationHint([a,a.Za]),a.audienceManagerLocationHint\u0026\u0026(a.U=\n!0)),a.aa||a.audienceManagerBlob||!b.getAudienceManagerBlob||(a.aa=!0,a.audienceManagerBlob=b.getAudienceManagerBlob([a,a.Ya]),a.audienceManagerBlob\u0026\u0026(a.T=!0)),c=a.ca\u0026\u0026!a.V\u0026\u0026!a.marketingCloudVisitorID,b=a.Z\u0026\u0026!a.S\u0026\u0026!a.analyticsVisitorID,h=a.ba\u0026\u0026!a.U\u0026\u0026!a.audienceManagerLocationHint,e=a.aa\u0026\u0026!a.T\u0026\u0026!a.audienceManagerBlob,d=a.fa\u0026\u0026!a.W,c=c||b||h||e||d?!1:!0);a.da||a.I||(a.$a(a.xa)?a.I=!0:a.da=!0);a.da\u0026\u0026!a.I\u0026\u0026(c=!1);return c};a.o=f;a.u=0;a.callbackWhenReadyToTrack=function(c,b,h){var e={};e.qb=c;e.pb=b;e.nb=\nh;a.o==f\u0026\u0026(a.o=[]);a.o.push(e);0==a.u\u0026\u0026(a.u=setInterval(a.j,100))};a.j=function(){if(a.isReadyToTrack()\u0026\u0026(a.kb(),a.o!=f))for(;0\u003Ca.o.length;){var c=a.o.shift();c.pb.apply(c.qb,c.nb)}};a.kb=function(){a.u\u0026\u0026(clearInterval(a.u),a.u=0)};a.fb=function(c){var b,h=f;if(!a.isReadyToTrack()){var e=[];if(c!=f)for(b in h={},c)h[b]=c[b];c={};a.Va(c,!0);e.push(h);e.push(c);a.callbackWhenReadyToTrack(a,a.track,e);return!0}return!1};a.xb=function(){var c=a.cookieRead(\"s_fid\"),b=\"\",h=\"\";var e=8;var d=4;if(!c||0\u003Ec.indexOf(\"-\")){for(c=\n0;16\u003Ec;c++)e=Math.floor(Math.random()*e),b+=\"0123456789ABCDEF\".substring(e,e+1),e=Math.floor(Math.random()*d),h+=\"0123456789ABCDEF\".substring(e,e+1),e=d=16;c=b+\"-\"+h}a.cookieWrite(\"s_fid\",c,1)||(c=0);return c};a.t=a.track=function(c,b){var h,e=new Date,f=\"s\"+Math.floor(e.getTime()\/108E5)%10+Math.floor(1E13*Math.random()),g=e.getYear();g=\"t\\x3d\"+a.escape(e.getDate()+\"\/\"+e.getMonth()+\"\/\"+(1900\u003Eg?g+1900:g)+\" \"+e.getHours()+\":\"+e.getMinutes()+\":\"+e.getSeconds()+\" \"+e.getDay()+\" \"+e.getTimezoneOffset());\na.visitor\u0026\u0026a.visitor.getAuthState\u0026\u0026(a.authState=a.visitor.getAuthState());a.p(\"_s\");a.fb(c)||(b\u0026\u0026a.R(b),c\u0026\u0026(h={},a.Va(h,0),a.R(c)),a.Db()\u0026\u0026!a.visitorOptedOut\u0026\u0026(a.analyticsVisitorID||a.marketingCloudVisitorID||(a.fid=a.xb()),a.Hb(),a.usePlugins\u0026\u0026a.doPlugins\u0026\u0026a.doPlugins(a),a.account\u0026\u0026(a.abort||(a.trackOffline\u0026\u0026!a.timestamp\u0026\u0026(a.timestamp=Math.floor(e.getTime()\/1E3)),e=d.location,a.pageURL||(a.pageURL=e.href?e.href:e),a.referrer||a.Wa||(e=a.Util.getQueryParam(\"adobe_mc_ref\",null,null,!0),a.referrer=\ne||void 0===e?void 0===e?\"\":e:m.document.referrer),a.Wa=1,a.referrer=a.vb(a.referrer),a.p(\"_g\")),a.Ab()\u0026\u0026!a.abort\u0026\u0026(a.visitor\u0026\u0026!a.supplementalDataID\u0026\u0026a.visitor.getSupplementalDataID\u0026\u0026(a.supplementalDataID=a.visitor.getSupplementalDataID(\"AppMeasurement:\"+a._in,a.expectSupplementalData?!1:!0)),a.Bb(),g+=a.zb(),a.Gb(f,g),a.p(\"_t\"),a.referrer=\"\"))),c\u0026\u0026a.R(h,1));a.abort=a.supplementalDataID=a.timestamp=a.pageURLRest=a.linkObject=a.clickObject=a.linkURL=a.linkName=a.linkType=d.s_objectID=a.pe=a.pev1=a.pev2=\na.pev3=a.e=a.lightProfileID=0};a.za=[];a.registerPreTrackCallback=function(c){for(var b=[],h=1;h\u003Carguments.length;h++)b.push(arguments[h]);\"function\"==typeof c?a.za.push([c,b]):a.debugTracking\u0026\u0026a.F(\"DEBUG: Non function type passed to registerPreTrackCallback\")};a.cb=function(c){a.wa(a.za,c)};a.ya=[];a.registerPostTrackCallback=function(c){for(var b=[],h=1;h\u003Carguments.length;h++)b.push(arguments[h]);\"function\"==typeof c?a.ya.push([c,b]):a.debugTracking\u0026\u0026a.F(\"DEBUG: Non function type passed to registerPostTrackCallback\")};\na.bb=function(c){a.wa(a.ya,c)};a.wa=function(c,b){if(\"object\"==typeof c)for(var h=0;h\u003Cc.length;h++){var e=c[h][0],d=c[h][1];d.unshift(b);if(\"function\"==typeof e)try{e.apply(null,d)}catch(T){a.debugTracking\u0026\u0026a.F(T.message)}}};a.tl=a.trackLink=function(c,b,h,e,d){a.linkObject=c;a.linkType=b;a.linkName=h;d\u0026\u0026(a.l=c,a.A=d);return a.track(e)};a.trackLight=function(c,b,h,e){a.lightProfileID=c;a.lightStoreForSeconds=b;a.lightIncrementBy=h;return a.track(e)};a.clearVars=function(){var c,b;for(c=0;c\u003Ca.g.length;c++)if(b=\na.g[c],\"prop\"==b.substring(0,4)||\"eVar\"==b.substring(0,4)||\"hier\"==b.substring(0,4)||\"list\"==b.substring(0,4)||\"channel\"==b||\"events\"==b||\"eventList\"==b||\"products\"==b||\"productList\"==b||\"purchaseID\"==b||\"transactionID\"==b||\"state\"==b||\"zip\"==b||\"campaign\"==b)a[b]=void 0};a.tagContainerMarker=\"\";a.Gb=function(c,b){var h=a.trackingServer;var e=\"\";var d=a.dc,f=\"sc.\",g=a.visitorNamespace;h?a.trackingServerSecure\u0026\u0026a.ssl\u0026\u0026(h=a.trackingServerSecure):(g||(g=a.account,h=g.indexOf(\",\"),0\u003C=h\u0026\u0026(g=g.substring(0,\nh)),g=g.replace(\/[^A-Za-z0-9]\/g,\"\")),e||(e=\"2o7.net\"),d=d?(\"\"+d).toLowerCase():\"d1\",\"2o7.net\"==e\u0026\u0026(\"d1\"==d?d=\"112\":\"d2\"==d\u0026\u0026(d=\"122\"),f=\"\"),h=g+\".\"+d+\".\"+f+e);e=a.ssl?\"https:\/\/\":\"http:\/\/\";d=a.AudienceManagement\u0026\u0026a.AudienceManagement.isReady()||0!=a.usePostbacks;e+=h+\"\/b\/ss\/\"+a.account+\"\/\"+(a.mobile?\"5.\":\"\")+(d?\"10\":\"1\")+\"\/JS-\"+a.version+(a.Kb?\"T\":\"\")+(a.tagContainerMarker?\"-\"+a.tagContainerMarker:\"\")+\"\/\"+c+\"?AQB\\x3d1\\x26ndh\\x3d1\\x26pf\\x3d1\\x26\"+(d?\"callback\\x3ds_c_il[\"+a._in+\"].doPostbacks\\x26et\\x3d1\\x26\":\n\"\")+b+\"\\x26AQE\\x3d1\";a.cb(e);a.tb(e);a.ka()};a.Ua=\/{(%?)(.*?)(%?)}\/;a.Ob=RegExp(a.Ua.source,\"g\");a.ub=function(c){if(\"object\"==typeof c.dests)for(var b=0;b\u003Cc.dests.length;++b){var d=c.dests[b];if(\"string\"==typeof d.c\u0026\u0026\"aa.\"==d.id.substr(0,3))for(var e=d.c.match(a.Ob),f=0;f\u003Ce.length;++f){var g=e[f],l=g.match(a.Ua),m=\"\";\"%\"==l[1]\u0026\u0026\"timezone_offset\"==l[2]?m=(new Date).getTimezoneOffset():\"%\"==l[1]\u0026\u0026\"timestampz\"==l[2]\u0026\u0026(m=a.yb());d.c=d.c.replace(g,a.escape(m))}}};a.yb=function(){var c=new Date,b=new Date(6E4*\nMath.abs(c.getTimezoneOffset()));return a.k(4,c.getFullYear())+\"-\"+a.k(2,c.getMonth()+1)+\"-\"+a.k(2,c.getDate())+\"T\"+a.k(2,c.getHours())+\":\"+a.k(2,c.getMinutes())+\":\"+a.k(2,c.getSeconds())+(0\u003Cc.getTimezoneOffset()?\"-\":\"+\")+a.k(2,b.getUTCHours())+\":\"+a.k(2,b.getUTCMinutes())};a.k=function(a,b){return(Array(a+1).join(0)+b).slice(-a)};a.ta={};a.doPostbacks=function(c){if(\"object\"==typeof c)if(a.ub(c),\"object\"==typeof a.AudienceManagement\u0026\u0026\"function\"==typeof a.AudienceManagement.isReady\u0026\u0026a.AudienceManagement.isReady()\u0026\u0026\n\"function\"==typeof a.AudienceManagement.passData)a.AudienceManagement.passData(c);else if(\"object\"==typeof c\u0026\u0026\"object\"==typeof c.dests)for(var b=0;b\u003Cc.dests.length;++b){var d=c.dests[b];\"object\"==typeof d\u0026\u0026\"string\"==typeof d.c\u0026\u0026\"string\"==typeof d.id\u0026\u0026\"aa.\"==d.id.substr(0,3)\u0026\u0026(a.ta[d.id]=new Image,a.ta[d.id].alt=\"\",a.ta[d.id].src=d.c)}};a.tb=function(c){a.i||a.Cb();a.i.push(c);a.ma=a.C();a.Sa()};a.Cb=function(){a.i=a.Eb();a.i||(a.i=[])};a.Eb=function(){var c,b;if(a.ra()){try{(b=d.localStorage.getItem(a.pa()))\u0026\u0026\n(c=d.JSON.parse(b))}catch(h){}return c}};a.ra=function(){var c=!0;a.trackOffline\u0026\u0026a.offlineFilename\u0026\u0026d.localStorage\u0026\u0026d.JSON||(c=!1);return c};a.Ja=function(){var c=0;a.i\u0026\u0026(c=a.i.length);a.q\u0026\u0026c++;return c};a.ka=function(){if(!a.q||(a.B\u0026\u0026a.B.complete\u0026\u0026a.B.G\u0026\u0026a.B.va(),!a.q))if(a.Ka=f,a.qa)a.ma\u003Ea.O\u0026\u0026a.Qa(a.i),a.ua(500);else{var c=a.ob();if(0\u003Cc)a.ua(c);else if(c=a.Ga())a.q=1,a.Fb(c),a.Jb(c)}};a.ua=function(c){a.Ka||(c||(c=0),a.Ka=setTimeout(a.ka,c))};a.ob=function(){if(!a.trackOffline||0\u003E=a.offlineThrottleDelay)return 0;\nvar c=a.C()-a.Pa;return a.offlineThrottleDelay\u003Cc?0:a.offlineThrottleDelay-c};a.Ga=function(){if(0\u003Ca.i.length)return a.i.shift()};a.Fb=function(c){if(a.debugTracking){var b=\"AppMeasurement Debug: \"+c;c=c.split(\"\\x26\");var d;for(d=0;d\u003Cc.length;d++)b+=\"\\n\\t\"+a.unescape(c[d]);a.F(b)}};a.gb=function(){return a.marketingCloudVisitorID||a.analyticsVisitorID};a.Y=!1;try{var g=JSON.parse('{\"x\":\"y\"}')}catch(c){g=null}g\u0026\u0026\"y\"==g.x?(a.Y=!0,a.X=function(a){return JSON.parse(a)}):d.$\u0026\u0026d.$.parseJSON?(a.X=function(a){return d.$.parseJSON(a)},\na.Y=!0):a.X=function(){return null};a.Jb=function(c){var b,h,e;a.gb()\u0026\u00262047\u003Cc.length\u0026\u0026(\"undefined\"!=typeof XMLHttpRequest\u0026\u0026(b=new XMLHttpRequest,\"withCredentials\"in b?h=1:b=0),b||\"undefined\"==typeof XDomainRequest||(b=new XDomainRequest,h=2),b\u0026\u0026(a.AudienceManagement\u0026\u0026a.AudienceManagement.isReady()||0!=a.usePostbacks)\u0026\u0026(a.Y?b.Ba=!0:b=0));!b\u0026\u0026a.Ta\u0026\u0026(c=c.substring(0,2047));!b\u0026\u0026a.d.createElement\u0026\u0026(0!=a.usePostbacks||a.AudienceManagement\u0026\u0026a.AudienceManagement.isReady())\u0026\u0026(b=a.d.createElement(\"SCRIPT\"))\u0026\u0026\n\"async\"in b\u0026\u0026((e=(e=a.d.getElementsByTagName(\"HEAD\"))\u0026\u0026e[0]?e[0]:a.d.body)?(b.type=\"text\/javascript\",b.setAttribute(\"async\",\"async\"),h=3):b=0);b||(b=new Image,b.alt=\"\",b.abort||\"undefined\"===typeof d.InstallTrigger||(b.abort=function(){b.src=f}));b.Da=function(){try{b.G\u0026\u0026(clearTimeout(b.G),b.G=0)}catch(T){}};b.onload=b.va=function(){a.bb(c);b.Da();a.sb();a.ga();a.q=0;a.ka();if(b.Ba){b.Ba=!1;try{a.doPostbacks(a.X(b.responseText))}catch(T){}}};b.onabort=b.onerror=b.Ha=function(){b.Da();(a.trackOffline||\na.qa)\u0026\u0026a.q\u0026\u0026a.i.unshift(a.rb);a.q=0;a.ma\u003Ea.O\u0026\u0026a.Qa(a.i);a.ga();a.ua(500)};b.onreadystatechange=function(){4==b.readyState\u0026\u0026(200==b.status?b.va():b.Ha())};a.Pa=a.C();if(1==h||2==h){var g=c.indexOf(\"?\");e=c.substring(0,g);g=c.substring(g+1);g=g.replace(\/\u0026callback=[a-zA-Z0-9_.\\[\\]]+\/,\"\");1==h?(b.open(\"POST\",e,!0),b.send(g)):2==h\u0026\u0026(b.open(\"POST\",e),b.send(g))}else if(b.src=c,3==h){if(a.Na)try{e.removeChild(a.Na)}catch(T){}e.firstChild?e.insertBefore(b,e.firstChild):e.appendChild(b);a.Na=a.B}b.G=setTimeout(function(){b.G\u0026\u0026\n(b.complete?b.va():(a.trackOffline\u0026\u0026b.abort\u0026\u0026b.abort(),b.Ha()))},5E3);a.rb=c;a.B=d[\"s_i_\"+a.replace(a.account,\",\",\"_\")]=b;if(a.useForcedLinkTracking\u0026\u0026a.K||a.A)a.forcedLinkTrackingTimeout||(a.forcedLinkTrackingTimeout=250),a.ha=setTimeout(a.ga,a.forcedLinkTrackingTimeout)};a.sb=function(){if(a.ra()\u0026\u0026!(a.Oa\u003Ea.O))try{d.localStorage.removeItem(a.pa()),a.Oa=a.C()}catch(c){}};a.Qa=function(c){if(a.ra()){a.Sa();try{d.localStorage.setItem(a.pa(),d.JSON.stringify(c)),a.O=a.C()}catch(b){}}};a.Sa=function(){if(a.trackOffline){if(!a.offlineLimit||\n0\u003E=a.offlineLimit)a.offlineLimit=10;for(;a.i.length\u003Ea.offlineLimit;)a.Ga()}};a.forceOffline=function(){a.qa=!0};a.forceOnline=function(){a.qa=!1};a.pa=function(){return a.offlineFilename+\"-\"+a.visitorNamespace+a.account};a.C=function(){return(new Date).getTime()};a.La=function(a){a=a.toLowerCase();return 0!=a.indexOf(\"#\")\u0026\u00260!=a.indexOf(\"about:\")\u0026\u00260!=a.indexOf(\"opera:\")\u0026\u00260!=a.indexOf(\"javascript:\")?!0:!1};a.setTagContainer=function(c){var b,d;a.Kb=c;for(b=0;b\u003Ca._il.length;b++)if((d=a._il[b])\u0026\u0026\"s_l\"==\nd._c\u0026\u0026d.tagContainerName==c){a.R(d);if(d.lmq)for(b=0;b\u003Cd.lmq.length;b++){var e=d.lmq[b];a.loadModule(e.n)}if(d.ml)for(e in d.ml)if(a[e])for(b in c=a[e],e=d.ml[e],e)!Object.prototype[b]\u0026\u0026(\"function\"!=typeof e[b]||0\u003E(\"\"+e[b]).indexOf(\"s_c_il\"))\u0026\u0026(c[b]=e[b]);if(d.mmq)for(b=0;b\u003Cd.mmq.length;b++)e=d.mmq[b],a[e.m]\u0026\u0026(c=a[e.m],c[e.f]\u0026\u0026\"function\"==typeof c[e.f]\u0026\u0026(e.a?c[e.f].apply(c,e.a):c[e.f].apply(c)));if(d.tq)for(b=0;b\u003Cd.tq.length;b++)a.track(d.tq[b]);d.s=a;break}};a.Util={urlEncode:a.escape,urlDecode:a.unescape,\ncookieRead:a.cookieRead,cookieWrite:a.cookieWrite,getQueryParam:function(c,b,h,e){var f=\"\";b||(b=a.pageURL?a.pageURL:d.location);h=h?h:\"\\x26\";if(!c||!b)return f;b=\"\"+b;var g=b.indexOf(\"?\");if(0\u003Eg)return f;b=h+b.substring(g+1)+h;if(!e||!(0\u003C=b.indexOf(h+c+h)||0\u003C=b.indexOf(h+c+\"\\x3d\"+h))){g=b.indexOf(\"#\");0\u003C=g\u0026\u0026(b=b.substr(0,g)+h);g=b.indexOf(h+c+\"\\x3d\");if(0\u003Eg)return f;b=b.substring(g+h.length+c.length+1);g=b.indexOf(h);0\u003C=g\u0026\u0026(b=b.substring(0,g));0\u003Cb.length\u0026\u0026(f=a.unescape(b));return f}}};a.H=\"supplementalDataID timestamp dynamicVariablePrefix visitorID marketingCloudVisitorID analyticsVisitorID audienceManagerLocationHint authState fid vmk visitorMigrationKey visitorMigrationServer visitorMigrationServerSecure charSet visitorNamespace cookieDomainPeriods fpCookieDomainPeriods cookieLifetime pageName pageURL customerPerspective referrer contextData currencyCode lightProfileID lightStoreForSeconds lightIncrementBy retrieveLightProfiles deleteLightProfiles retrieveLightData\".split(\" \");\na.g=a.H.concat(\"purchaseID variableProvider channel server pageType transactionID campaign state zip events events2 products audienceManagerBlob tnt\".split(\" \"));a.na=\"timestamp charSet visitorNamespace cookieDomainPeriods cookieLifetime contextData lightProfileID lightStoreForSeconds lightIncrementBy\".split(\" \");a.P=a.na.slice(0);a.Aa=\"account allAccounts debugTracking visitor visitorOptedOut trackOffline offlineLimit offlineThrottleDelay offlineFilename usePlugins doPlugins configURL visitorSampling visitorSamplingGroup linkObject clickObject linkURL linkName linkType trackDownloadLinks trackExternalLinks trackClickMap trackInlineStats linkLeaveQueryString linkTrackVars linkTrackEvents linkDownloadFileTypes linkExternalFilters linkInternalFilters useForcedLinkTracking forcedLinkTrackingTimeout trackingServer trackingServerSecure ssl abort mobile dc lightTrackVars maxDelay expectSupplementalData usePostbacks registerPreTrackCallback registerPostTrackCallback AudienceManagement\".split(\" \");\nfor(l=0;250\u003E=l;l++)76\u003El\u0026\u0026(a.g.push(\"prop\"+l),a.P.push(\"prop\"+l)),a.g.push(\"eVar\"+l),a.P.push(\"eVar\"+l),6\u003El\u0026\u0026a.g.push(\"hier\"+l),4\u003El\u0026\u0026a.g.push(\"list\"+l);l=\"pe pev1 pev2 pev3 latitude longitude resolution colorDepth javascriptVersion javaEnabled cookiesEnabled browserWidth browserHeight connectionType homepage pageURLRest marketingCloudOrgID\".split(\" \");a.g=a.g.concat(l);a.H=a.H.concat(l);a.ssl=0\u003C=d.location.protocol.toLowerCase().indexOf(\"https\");a.charSet=\"UTF-8\";a.contextData={};a.offlineThrottleDelay=\n0;a.offlineFilename=\"AppMeasurement.offline\";a.Pa=0;a.ma=0;a.O=0;a.Oa=0;a.linkDownloadFileTypes=\"exe,zip,wav,mp3,mov,mpg,avi,wmv,pdf,doc,docx,xls,xlsx,ppt,pptx\";a.w=d;a.d=d.document;try{if(a.Ta=!1,navigator){var x=navigator.userAgent;if(\"Microsoft Internet Explorer\"==navigator.appName||0\u003C=x.indexOf(\"MSIE \")||0\u003C=x.indexOf(\"Trident\/\")\u0026\u00260\u003C=x.indexOf(\"Windows NT 6\"))a.Ta=!0}}catch(c){}a.ga=function(){a.ha\u0026\u0026(d.clearTimeout(a.ha),a.ha=f);a.l\u0026\u0026a.K\u0026\u0026a.l.dispatchEvent(a.K);a.A\u0026\u0026(\"function\"==typeof a.A?a.A():\na.l\u0026\u0026a.l.href\u0026\u0026(a.d.location=a.l.href));a.l=a.K=a.A=0};a.Ra=function(){a.b=a.d.body;a.b?(a.v=function(c){var b,f,e;if(!(a.d\u0026\u0026a.d.getElementById(\"cppXYctnr\")||c\u0026\u0026c[\"s_fe_\"+a._in])){if(a.Ca)if(a.useForcedLinkTracking)a.b.removeEventListener(\"click\",a.v,!1);else{a.b.removeEventListener(\"click\",a.v,!0);a.Ca=a.useForcedLinkTracking=0;return}else a.useForcedLinkTracking=0;a.clickObject=c.srcElement?c.srcElement:c.target;try{if(!a.clickObject||a.N\u0026\u0026a.N==a.clickObject||!(a.clickObject.tagName||a.clickObject.parentElement||\na.clickObject.parentNode))a.clickObject=0;else{var g=a.N=a.clickObject;a.la\u0026\u0026(clearTimeout(a.la),a.la=0);a.la=setTimeout(function(){a.N==g\u0026\u0026(a.N=0)},1E4);var l=a.Ja();a.track();if(l\u003Ca.Ja()\u0026\u0026a.useForcedLinkTracking\u0026\u0026c.target){for(f=c.target;f\u0026\u0026f!=a.b\u0026\u0026\"A\"!=f.tagName.toUpperCase()\u0026\u0026\"AREA\"!=f.tagName.toUpperCase();)f=f.parentNode;if(f\u0026\u0026(e=f.href,a.La(e)||(e=0),b=f.target,c.target.dispatchEvent\u0026\u0026e\u0026\u0026(!b||\"_self\"==b||\"_top\"==b||\"_parent\"==b||d.name\u0026\u0026b==d.name))){try{var m=a.d.createEvent(\"MouseEvents\")}catch(H){m=\nnew d.MouseEvent}if(m){try{m.initMouseEvent(\"click\",c.bubbles,c.cancelable,c.view,c.detail,c.screenX,c.screenY,c.clientX,c.clientY,c.ctrlKey,c.altKey,c.shiftKey,c.metaKey,c.button,c.relatedTarget)}catch(H){m=0}m\u0026\u0026(m[\"s_fe_\"+a._in]=m.s_fe=1,c.stopPropagation(),c.stopImmediatePropagation\u0026\u0026c.stopImmediatePropagation(),c.preventDefault(),a.l=c.target,a.K=m)}}}}}catch(H){a.clickObject=0}}},a.b\u0026\u0026a.b.attachEvent?a.b.attachEvent(\"onclick\",a.v):a.b\u0026\u0026a.b.addEventListener\u0026\u0026(navigator\u0026\u0026(0\u003C=navigator.userAgent.indexOf(\"WebKit\")\u0026\u0026\na.d.createEvent||0\u003C=navigator.userAgent.indexOf(\"Firefox\/2\")\u0026\u0026d.MouseEvent)\u0026\u0026(a.Ca=1,a.useForcedLinkTracking=1,a.b.addEventListener(\"click\",a.v,!0)),a.b.addEventListener(\"click\",a.v,!1))):setTimeout(a.Ra,30)};a.Ra();k?a.setAccount(k):a.F(\"Error, missing Report Suite ID in AppMeasurement initialization\");a.loadModule(\"ActivityMap\")}function O(k){var a=window.s_c_il,d,f=k.split(\",\"),m,n,l=0;if(a)for(d=0;!l\u0026\u0026d\u003Ca.length;){var g=a[d];if(\"s_c\"==g._c\u0026\u0026(g.account||g.oun))if(g.account\u0026\u0026g.account==k)l=1;else{var x=\ng.account?g.account:g.oun;x=g.allAccounts?g.allAccounts:x.split(\",\");for(m=0;m\u003Cf.length;m++)for(n=0;n\u003Cx.length;n++)f[m]==x[n]\u0026\u0026(l=1)}d++}l||(g=new P(k));return g}function V(){var k=window,a=k.s_giq,d;if(a)for(d=0;d\u003Ca.length;d++){var f=a[d];var m=O(f.oun);m.setAccount(f.un);m.setTagContainer(f.tagContainerName)}k.s_giq=0}try{var I=!1;I=\"object\"==typeof ensightenOptions}catch(k){}console.log(\"Adobe AppMeasurement 2.3.0\",\"18.04.09c\",I?\"via Ensighten\":\"via GTM\");AppMeasurement_Module_ActivityMap=function(k){function a(a,\nc){var b,d,f;if(a\u0026\u0026c\u0026\u0026(b=l.c[c]||(l.c[c]=c.split(\",\"))))for(f=0;f\u003Cb.length\u0026\u0026(d=b[f++]);)if(-1\u003Ca.indexOf(d))return null;x=1;return a}function d(a,c,d,f,g){var b;if(a.dataset\u0026\u0026(b=a.dataset[c]))var e=b;else if(a.getAttribute)if(b=a.getAttribute(\"data-\"+d))e=b;else if(b=a.getAttribute(d))e=b;if(!e\u0026\u0026k.useForcedLinkTracking\u0026\u0026g\u0026\u0026(e=\"\",c=a.onclick?\"\"+a.onclick:\"\")){d=c.indexOf(f);var h,l;if(0\u003C=d){for(d+=10;d\u003Cc.length\u0026\u00260\u003C=\"\\x3d \\t\\r\\n\".indexOf(c.charAt(d));)d++;if(d\u003Cc.length){b=d;for(h=l=0;b\u003Cc.length\u0026\u0026(\";\"!=\nc.charAt(b)||h);)h?c.charAt(b)!=h||l?l=\"\\\\\"==c.charAt(b)?!l:0:h=0:(h=c.charAt(b),'\"'!=h\u0026\u0026\"'\"!=h\u0026\u0026(h=0)),b++;if(c=c.substring(d,b))a.e=new Function(\"s\",\"var e;try{s.w.\"+f+\"\\x3d\"+c+\"}catch(e){}\"),a.e(k)}}}return e||g\u0026\u0026k.w[f]}function f(b,c,d){var e;return(e=l[c](b,d))\u0026\u0026(x?(x=0,e):a(n(e),l[c+\"Exclusions\"]))}function m(a,d,e){var b;if(a\u0026\u0026!(1===(b=a.nodeType)\u0026\u0026(b=a.nodeName)\u0026\u0026(b=b.toUpperCase())\u0026\u0026c[b])\u0026\u0026(1===a.nodeType\u0026\u0026(b=a.nodeValue)\u0026\u0026(d[d.length]=b),e.a||e.t||e.s||!a.getAttribute||((b=a.getAttribute(\"alt\"))?\ne.a=b:(b=a.getAttribute(\"title\"))?e.t=b:\"IMG\"==(\"\"+a.nodeName).toUpperCase()\u0026\u0026(b=a.getAttribute(\"src\")||a.src)\u0026\u0026(e.s=b)),(b=a.childNodes)\u0026\u0026b.length))for(a=0;a\u003Cb.length;a++)m(b[a],d,e)}function n(a){if(null==a||void 0==a)return a;try{return a.replace(RegExp(\"^[\\\\s\\\\n\\\\f\\\\r\\\\t\\t-\\r \\u00a0\\u1680\\u180e\\u2000-\\u200a\\u2028\\u2029\\u205f\\u3000\\ufeff]+\",\"mg\"),\"\").replace(RegExp(\"[\\\\s\\\\n\\\\f\\\\r\\\\t\\t-\\r \\u00a0\\u1680\\u180e\\u2000-\\u200a\\u2028\\u2029\\u205f\\u3000\\ufeff]+$\",\"mg\"),\"\").replace(RegExp(\"[\\\\s\\\\n\\\\f\\\\r\\\\t\\t-\\r \\u00a0\\u1680\\u180e\\u2000-\\u200a\\u2028\\u2029\\u205f\\u3000\\ufeff]{1,}\",\n\"mg\"),\" \").substring(0,254)}catch(h){}}var l=this;l.s=k;var g=window;g.s_c_in||(g.s_c_il=[],g.s_c_in=0);l._il=g.s_c_il;l._in=g.s_c_in;l._il[l._in]=l;g.s_c_in++;l._c=\"s_m\";l.c={};var x=0,c={SCRIPT:1,STYLE:1,LINK:1,CANVAS:1};l._g=function(){var a,c,d,g=k.contextData,l=k.linkObject;(a=k.pageName||k.pageURL)\u0026\u0026(c=f(l,\"link\",k.linkName))\u0026\u0026(d=f(l,\"region\"))\u0026\u0026(g[\"a.activitymap.page\"]=a.substring(0,255),g[\"a.activitymap.link\"]=128\u003Cc.length?c.substring(0,128):c,g[\"a.activitymap.region\"]=127\u003Cd.length?d.substring(0,\n127):d,g[\"a.activitymap.pageIDType\"]=k.pageName?1:0)};l.link=function(b,c){if(c)var e=a(n(c),l.linkExclusions);else if((e=b)\u0026\u0026!(e=d(b,\"sObjectId\",\"s-object-id\",\"s_objectID\",1))){var f,g;(g=a(n(b.innerText||b.textContent),l.linkExclusions))||(m(b,f=[],e={a:void 0,t:void 0,s:void 0}),(g=a(n(f.join(\"\"))))||(g=a(n(e.a?e.a:e.t?e.t:e.s?e.s:void 0)))||!(f=(f=b.tagName)\u0026\u0026f.toUpperCase?f.toUpperCase():\"\")||(\"INPUT\"==f||\"SUBMIT\"==f\u0026\u0026b.value?g=a(n(b.value)):\"IMAGE\"==f\u0026\u0026b.src\u0026\u0026(g=a(n(b.src)))));e=g}return e};\nl.region=function(a){for(var b,c=l.regionIDAttribute||\"id\";a\u0026\u0026(a=a.parentNode);){if(b=d(a,c,c,c))return b;if(\"BODY\"==a.nodeName)return\"BODY\"}}};AppMeasurement_Module_Media=function(k){var a=this;a.s=k;k=window;k.s_c_in||(k.s_c_il=[],k.s_c_in=0);a._il=k.s_c_il;a._in=k.s_c_in;a._il[a._in]=a;k.s_c_in++;a._c=\"s_m\";a.list=[];a.open=function(d,f,m,n){var l={},g=new Date,k=\"\",c;f||(f=-1);if(d\u0026\u0026m){a.list||(a.list={});a.list[d]\u0026\u0026a.close(d);n\u0026\u0026n.id\u0026\u0026(k=n.id);if(k)for(c in a.list)!Object.prototype[c]\u0026\u0026a.list[c]\u0026\u0026\na.list[c].R==k\u0026\u0026a.close(a.list[c].name);l.name=d;l.length=f;l.offset=0;l.e=0;l.playerName=a.playerName?a.playerName:m;l.R=k;l.C=0;l.a=0;l.timestamp=Math.floor(g.getTime()\/1E3);l.k=0;l.u=l.timestamp;l.c=-1;l.n=\"\";l.g=-1;l.D=0;l.I={};l.G=0;l.m=0;l.f=\"\";l.B=0;l.L=0;l.A=0;l.F=0;l.l=!1;l.v=\"\";l.J=\"\";l.K=0;l.r=!1;l.H=\"\";l.complete=0;l.Q=0;l.p=0;l.q=0;a.list[d]=l}};a.openAd=function(d,f,m,n,l,g,k,c){a.open(d,f,m,c);if(d=a.list[d])d.l=!0,d.v=n,d.J=l,d.K=g,d.H=k};a.M=function(d){var f=a.list[d];a.list[d]=\n0;f\u0026\u0026f.monitor\u0026\u0026clearTimeout(f.monitor.interval)};a.close=function(d){a.i(d,0,-1)};a.play=function(d,f,m,n){var l=a.i(d,1,f,m,n);l\u0026\u0026!l.monitor\u0026\u0026(l.monitor={},l.monitor.update=function(){1==l.k\u0026\u0026a.i(l.name,3,-1);l.monitor.interval=setTimeout(l.monitor.update,1E3)},l.monitor.update())};a.click=function(d,f){a.i(d,7,f)};a.complete=function(d,f){a.i(d,5,f)};a.stop=function(d,f){a.i(d,2,f)};a.track=function(d){a.i(d,4,-1)};a.P=function(d,f){var m=\"a.media.\",n=d.linkTrackVars,l=d.linkTrackEvents,g=\"m_i\",\nk=d.contextData;f.l\u0026\u0026(m+=\"ad.\",f.v\u0026\u0026(k[\"a.media.name\"]=f.v,k[m+\"pod\"]=f.J,k[m+\"podPosition\"]=f.K),f.G||(k[m+\"CPM\"]=f.H));f.r\u0026\u0026(k[m+\"clicked\"]=!0,f.r=!1);k[\"a.contentType\"]=\"video\"+(f.l?\"Ad\":\"\");k[\"a.media.channel\"]=a.channel;k[m+\"name\"]=f.name;k[m+\"playerName\"]=f.playerName;0\u003Cf.length\u0026\u0026(k[m+\"length\"]=f.length);k[m+\"timePlayed\"]=Math.floor(f.a);0\u003CMath.floor(f.a)\u0026\u0026(k[m+\"timePlayed\"]=Math.floor(f.a));f.G||(k[m+\"view\"]=!0,g=\"m_s\",a.Heartbeat\u0026\u0026a.Heartbeat.enabled\u0026\u0026(g=f.l?a.__primetime?\"mspa_s\":\"msa_s\":\na.__primetime?\"msp_s\":\"ms_s\"),f.G=1);f.f\u0026\u0026(k[m+\"segmentNum\"]=f.m,k[m+\"segment\"]=f.f,0\u003Cf.B\u0026\u0026(k[m+\"segmentLength\"]=f.B),f.A\u0026\u00260\u003Cf.a\u0026\u0026(k[m+\"segmentView\"]=!0));!f.Q\u0026\u0026f.complete\u0026\u0026(k[m+\"complete\"]=!0,f.S=1);0\u003Cf.p\u0026\u0026(k[m+\"milestone\"]=f.p);0\u003Cf.q\u0026\u0026(k[m+\"offsetMilestone\"]=f.q);if(n)for(e in k)Object.prototype[e]||(n+=\",contextData.\"+e);var c=k[\"a.contentType\"];d.pe=g;d.pev3=c;var b;if(a.contextDataMapping)for(e in d.events2||(d.events2=\"\"),n\u0026\u0026(n+=\",events\"),a.contextDataMapping)if(!Object.prototype[e]){g=e.length\u003E\nm.length\u0026\u0026e.substring(0,m.length)==m?e.substring(m.length):\"\";c=a.contextDataMapping[e];if(\"string\"==typeof c){var h=c.split(\",\");for(b=0;b\u003Ch.length;b++)c=h[b],\"a.contentType\"==e?(n\u0026\u0026(n+=\",\"+c),d[c]=k[e]):\"view\"==g||\"segmentView\"==g||\"clicked\"==g||\"complete\"==g||\"timePlayed\"==g||\"CPM\"==g?(l\u0026\u0026(l+=\",\"+c),\"timePlayed\"==g||\"CPM\"==g?k[e]\u0026\u0026(d.events2+=(d.events2?\",\":\"\")+c+\"\\x3d\"+k[e]):k[e]\u0026\u0026(d.events2+=(d.events2?\",\":\"\")+c)):\"segment\"==g\u0026\u0026k[e+\"Num\"]?(n\u0026\u0026(n+=\",\"+c),d[c]=k[e+\"Num\"]+\":\"+k[e]):(n\u0026\u0026(n+=\",\"+\nc),d[c]=k[e])}else if(\"milestones\"==g||\"offsetMilestones\"==g){var e=e.substring(0,e.length-1);k[e]\u0026\u0026a.contextDataMapping[e+\"s\"][k[e]]\u0026\u0026(l\u0026\u0026(l+=\",\"+a.contextDataMapping[e+\"s\"][k[e]]),d.events2+=(d.events2?\",\":\"\")+a.contextDataMapping[e+\"s\"][k[e]])}k[e]\u0026\u0026(k[e]=0);\"segment\"==g\u0026\u0026k[e+\"Num\"]\u0026\u0026(k[e+\"Num\"]=0)}d.linkTrackVars=n;d.linkTrackEvents=l};a.i=function(d,f,m,k,l){var g,n=(new Date).getTime()\/1E3,c,b=a.trackVars,h=a.trackEvents,e=a.trackSeconds,p=a.trackMilestones,q=a.trackOffsetMilestones,L=a.segmentByMilestones,\nH=a.segmentByOffsetMilestones,u,G=1,t={},I;a.channel||(a.channel=a.s.w.location.hostname);if(g=d\u0026\u0026a.list\u0026\u0026a.list[d]?a.list[d]:0)if(g.l\u0026\u0026(e=a.adTrackSeconds,p=a.adTrackMilestones,q=a.adTrackOffsetMilestones,L=a.adSegmentByMilestones,H=a.adSegmentByOffsetMilestones),0\u003Em\u0026\u0026(m=1==g.k\u0026\u00260\u003Cg.u?n-g.u+g.c:g.c),0\u003Cg.length\u0026\u0026(m=m\u003Cg.length?m:g.length),0\u003Em\u0026\u0026(m=0),g.offset=m,0\u003Cg.length\u0026\u0026(g.e=g.offset\/g.length*100,g.e=100\u003Cg.e?100:g.e),0\u003Eg.c\u0026\u0026(g.c=m),I=g.D,t.name=d,t.ad=g.l,t.length=g.length,t.openTime=new Date,t.openTime.setTime(1E3*\ng.timestamp),t.offset=g.offset,t.percent=g.e,t.playerName=g.playerName,t.mediaEvent=0\u003Eg.g?\"OPEN\":1==f?\"PLAY\":2==f?\"STOP\":3==f?\"MONITOR\":4==f?\"TRACK\":5==f?\"COMPLETE\":7==f?\"CLICK\":\"CLOSE\",2\u003Cf||f!=g.k\u0026\u0026(2!=f||1==g.k)){l||(k=g.m,l=g.f);if(f){1==f\u0026\u0026(g.c=m);if((3\u003E=f||5\u003C=f)\u0026\u00260\u003C=g.g\u0026\u0026(G=!1,b=h=\"None\",g.g!=m)){var D=g.g;D\u003Em\u0026\u0026(D=g.c,D\u003Em\u0026\u0026(D=m));var y=p?p.split(\",\"):0;if(0\u003Cg.length\u0026\u0026y\u0026\u0026m\u003E=D)for(u=0;u\u003Cy.length;u++)(c=y[u]?parseFloat(\"\"+y[u]):0)\u0026\u0026D\/g.length*100\u003Cc\u0026\u0026g.e\u003E=c\u0026\u0026(G=!0,u=y.length,t.mediaEvent=\"MILESTONE\",\ng.p=t.milestone=c);if((y=q?q.split(\",\"):0)\u0026\u0026m\u003E=D)for(u=0;u\u003Cy.length;u++)(c=y[u]?parseFloat(\"\"+y[u]):0)\u0026\u0026D\u003Cc\u0026\u0026m\u003E=c\u0026\u0026(G=!0,u=y.length,t.mediaEvent=\"OFFSET_MILESTONE\",g.q=t.offsetMilestone=c)}if(g.L||!l){if(L\u0026\u0026p\u0026\u00260\u003Cg.length){if(y=p.split(\",\"))for(y.push(\"100\"),u=D=0;u\u003Cy.length;u++)if(c=y[u]?parseFloat(\"\"+y[u]):0)g.e\u003Cc\u0026\u0026(k=u+1,l=\"M:\"+D+\"-\"+c,u=y.length),D=c}else if(H\u0026\u0026q\u0026\u0026(y=q.split(\",\")))for(y.push(\"\"+(0\u003Cg.length?g.length:\"E\")),u=D=0;u\u003Cy.length;u++)if((c=y[u]?parseFloat(\"\"+y[u]):0)||\"E\"==y[u]){if(m\u003Cc||\n\"E\"==y[u])k=u+1,l=\"O:\"+D+\"-\"+c,u=y.length;D=c}l\u0026\u0026(g.L=!0)}(l||g.f)\u0026\u0026l!=g.f\u0026\u0026(g.F=!0,g.f||(g.m=k,g.f=l),0\u003C=g.g\u0026\u0026(G=!0));(2\u003C=f||100\u003C=g.e)\u0026\u0026g.c\u003Cm\u0026\u0026(g.C+=m-g.c,g.a+=m-g.c);if(2\u003E=f||3==f\u0026\u0026!g.k)g.n+=(1==f||3==f?\"S\":\"E\")+Math.floor(m),g.k=3==f?1:f;!G\u0026\u00260\u003C=g.g\u0026\u00263\u003E=f\u0026\u0026(e=e?e:0)\u0026\u0026g.a\u003E=e\u0026\u0026(G=!0,t.mediaEvent=\"SECONDS\");g.u=n;g.c=m}if(!f||3\u003E=f\u0026\u0026100\u003C=g.e)2!=g.k\u0026\u0026(g.n+=\"E\"+Math.floor(m)),f=0,b=h=\"None\",t.mediaEvent=\"CLOSE\";7==f\u0026\u0026(G=t.clicked=g.r=!0);if(5==f||a.completeByCloseOffset\u0026\u0026(!f||100\u003C=g.e)\u0026\u00260\u003Cg.length\u0026\u0026m\u003E=\ng.length-a.completeCloseOffsetThreshold)G=t.complete=g.complete=!0;n=t.mediaEvent;\"MILESTONE\"==n?n+=\"_\"+t.milestone:\"OFFSET_MILESTONE\"==n\u0026\u0026(n+=\"_\"+t.offsetMilestone);g.I[n]?t.eventFirstTime=!1:(t.eventFirstTime=!0,g.I[n]=1);t.event=t.mediaEvent;t.timePlayed=g.C;t.segmentNum=g.m;t.segment=g.f;t.segmentLength=g.B;a.monitor\u0026\u00264!=f\u0026\u0026a.monitor(a.s,t);a.Heartbeat\u0026\u0026a.Heartbeat.enabled\u0026\u00260\u003C=g.g\u0026\u0026(G=!1);0==f\u0026\u0026a.M(d);G\u0026\u0026g.D==I\u0026\u0026(d={contextData:{}},d.linkTrackVars=b,d.linkTrackEvents=h,d.linkTrackVars||(d.linkTrackVars=\n\"\"),d.linkTrackEvents||(d.linkTrackEvents=\"\"),a.P(d,g),d.linkTrackVars||(d[\"!linkTrackVars\"]=1),d.linkTrackEvents||(d[\"!linkTrackEvents\"]=1),a.s.track(d),g.F?(g.m=k,g.f=l,g.A=!0,g.F=!1):0\u003Cg.a\u0026\u0026(g.A=!1),g.n=\"\",g.p=g.q=0,g.a-=Math.floor(g.a),g.g=m,g.D++)}return g};a.O=function(d,f,m,k,l){var g=0;if(d\u0026\u0026(!a.autoTrackMediaLengthRequired||f\u0026\u00260\u003Cf)){if(a.list\u0026\u0026a.list[d])g=1;else if(1==m||3==m)a.open(d,f,\"HTML5 Video\",l),g=1;g\u0026\u0026a.i(d,m,k,-1,0)}};a.attach=function(d){var f,m,k;d\u0026\u0026d.tagName\u0026\u0026\"VIDEO\"==d.tagName.toUpperCase()\u0026\u0026\n(a.o||(a.o=function(d,f,k){var c,b;a.autoTrack\u0026\u0026(c=d.currentSrc,(b=d.duration)||(b=-1),0\u003Ek\u0026\u0026(k=d.currentTime),a.O(c,b,f,k,d))}),f=function(){a.o(d,1,-1)},m=function(){a.o(d,1,-1)},a.j(d,\"play\",f),a.j(d,\"pause\",m),a.j(d,\"seeking\",m),a.j(d,\"seeked\",f),a.j(d,\"ended\",function(){a.o(d,0,-1)}),a.j(d,\"timeupdate\",f),k=function(){d.paused||d.ended||d.seeking||a.o(d,3,-1);setTimeout(k,1E3)},k())};a.j=function(a,f,k){a.attachEvent?a.attachEvent(\"on\"+f,k):a.addEventListener\u0026\u0026a.addEventListener(f,k,!1)};void 0==\na.completeByCloseOffset\u0026\u0026(a.completeByCloseOffset=1);void 0==a.completeCloseOffsetThreshold\u0026\u0026(a.completeCloseOffsetThreshold=1);a.Heartbeat={};a.N=function(){var d,f;if(a.autoTrack\u0026\u0026(d=a.s.d.getElementsByTagName(\"VIDEO\")))for(f=0;f\u003Cd.length;f++)a.attach(d[f])};a.j(k,\"load\",a.N)};AppMeasurement_Module_Integrate=function(k){var a=this;a.s=k;var d=window;d.s_c_in||(d.s_c_il=[],d.s_c_in=0);a._il=d.s_c_il;a._in=d.s_c_in;a._il[a._in]=a;d.s_c_in++;a._c=\"s_m\";a.list=[];a.add=function(f,m){m||(m=\"s_Integrate_\"+\nf);d[m]||(d[m]={});var n=a[f]=d[m];n.a=f;n.e=a;n._c=0;n._d=0;void 0==n.disable\u0026\u0026(n.disable=0);n.get=function(f,g){var k=document,c=k.getElementsByTagName(\"HEAD\");if(!n.disable\u0026\u0026(g||(v=\"s_\"+a._in+\"_Integrate_\"+n.a+\"_get_\"+n._c),n._c++,n.VAR=v,n.CALLBACK=\"s_c_il[\"+a._in+\"].\"+n.a+\".callback\",n.delay(),c=c\u0026\u00260\u003Cc.length?c[0]:k.body))try{var b=k.createElement(\"SCRIPT\");b.type=\"text\/javascript\";b.setAttribute(\"async\",\"async\");b.src=a.c(n,f);0\u003Ef.indexOf(\"[CALLBACK]\")\u0026\u0026(b.onload=b.onreadystatechange=function(){n.callback(d[v])});\nc.firstChild?c.insertBefore(b,c.firstChild):c.appendChild(b)}catch(h){}};n.callback=function(a){var d;if(a)for(d in a)Object.prototype[d]||(n[d]=a[d]);n.ready()};n.beacon=function(f){var g=\"s_i_\"+a._in+\"_Integrate_\"+n.a+\"_\"+n._c;n.disable||(n._c++,g=d[g]=new Image,g.src=a.c(n,f))};n.script=function(a){n.get(a,1)};n.delay=function(){n._d++};n.ready=function(){n._d--;n.disable||k.delayReady()};a.list.push(f)};a._g=function(d){var f,n=(d?\"use\":\"set\")+\"Vars\";for(d=0;d\u003Ca.list.length;d++)if((f=a[a.list[d]])\u0026\u0026\n!f.disable\u0026\u0026f[n])try{f[n](k,f)}catch(l){}};a._t=function(){a._g(1)};a._d=function(){var d,k;for(d=0;d\u003Ca.list.length;d++)if((k=a[a.list[d]])\u0026\u0026!k.disable\u0026\u00260\u003Ck._d)return 1;return 0};a.c=function(a,d){var f,l,g,m;\"http\"!=d.toLowerCase().substring(0,4)\u0026\u0026(d=\"http:\/\/\"+d);k.ssl\u0026\u0026(d=k.replace(d,\"http:\",\"https:\"));a.RAND=Math.floor(1E13*Math.random());for(f=0;0\u003C=f;)f=d.indexOf(\"[\",f),0\u003C=f\u0026\u0026(l=d.indexOf(\"]\",f),l\u003Ef\u0026\u0026(g=d.substring(f+1,l),2\u003Cg.length\u0026\u0026\"s.\"==g.substring(0,2)?(m=k[g.substring(2)])||(m=\"\"):(m=\"\"+\na[g],m!=a[g]\u0026\u0026parseFloat(m)!=a[g]\u0026\u0026(g=0)),g\u0026\u0026(d=d.substring(0,f)+encodeURIComponent(m)+d.substring(l+1)),f=l));return d}};AppMeasurement_Module_AudienceManagement=function(k){var a=this;a.s=k;var d=window;d.s_c_in||(d.s_c_il=[],d.s_c_in=0);a._il=d.s_c_il;a._in=d.s_c_in;a._il[a._in]=a;d.s_c_in++;a._c=\"s_m\";a.setup=function(f){d.DIL\u0026\u0026f\u0026\u0026(f.disableDefaultRequest=!0,f.disableScriptAttachment=!0,f.disableCORS=!0,f.secureDataCollection=!1,a.instance=d.DIL.create(f),a.tools=d.DIL.tools)};a.isReady=function(){return a.instance?\n!0:!1};a.getEventCallConfigParams=function(){return a.instance\u0026\u0026a.instance.api\u0026\u0026a.instance.api.getEventCallConfigParams?a.instance.api.getEventCallConfigParams():{}};a.passData=function(d){a.instance\u0026\u0026a.instance.api\u0026\u0026a.instance.api.passData\u0026\u0026a.instance.api.passData(d)}};\"function\"!==typeof window.DIL\u0026\u0026(window.DIL=function(k,a){var d=[],f;k!==Object(k)\u0026\u0026(k={});var m=k.partner;var n=k.containerNSID;var l=!!k.disableDestinationPublishingIframe;var g=k.iframeAkamaiHTTPS;var q=k.mappings;var c=k.uuidCookie;\nvar b=!0===k.enableErrorReporting;var h=k.visitorService;var e=k.declaredId;var p=!0===k.removeFinishedScriptsAndCallbacks;var I=!0===k.delayAllUntilWindowLoad;var L=!0===k.disableIDSyncs;var H=\"undefined\"===typeof k.secureDataCollection||!0===k.secureDataCollection;var u=!0===k.useCORSOnly;var G=!0===k.disableScriptAttachment;var t=!0===k.disableDefaultRequest;var K=k.afterResultForDefaultRequest;var D=k.dpIframeSrc;var y=!0===k.testCORS;var O=!0===k.useJSONPOnly;var P=k.visitorConstructor;var R=\n!0===k.disableCORS;b\u0026\u0026DIL.errorModule.activate();var S=!0===window._dil_unit_tests;(f=a)\u0026\u0026d.push(f+\"\");if(!m||\"string\"!==typeof m)return f=\"DIL partner is invalid or not specified in initConfig\",DIL.errorModule.handleError({name:\"error\",message:f,filename:\"dil.js\"}),Error(f);f=\"DIL containerNSID is invalid or not specified in initConfig, setting to default of 0\";if(n||\"number\"===typeof n)n=parseInt(n,10),!isNaN(n)\u0026\u00260\u003C=n\u0026\u0026(f=\"\");f\u0026\u0026(n=0,d.push(f),f=\"\");var M=DIL.getDil(m,n);if(M instanceof DIL\u0026\u0026M.api.getPartner()===\nm\u0026\u0026M.api.getContainerNSID()===n)return M;if(this instanceof DIL)DIL.registerDil(this,m,n);else return new DIL(k,\"DIL was not instantiated with the 'new' operator, returning a valid instance with partner \\x3d \"+m+\" and containerNSID \\x3d \"+n);var E={IS_HTTPS:H||\"https:\"===document.location.protocol,POST_MESSAGE_ENABLED:!!window.postMessage,COOKIE_MAX_EXPIRATION_DATE:\"Tue, 19 Jan 2038 03:14:07 UTC\",MILLIS_PER_DAY:864E5,DIL_COOKIE_NAME:\"AAMC_\"+encodeURIComponent(m)+\"_\"+n,FIRST_PARTY_SYNCS:\"AMSYNCS\",\nFIRST_PARTY_SYNCS_ON_PAGE:\"AMSYNCSOP\",HAS_JSON_STRINGIFY:window.JSON===Object(window.JSON)\u0026\u0026\"function\"===typeof window.JSON.stringify},N={stuffed:{}},B={},w={firingQueue:[],fired:[],firing:!1,sent:[],errored:[],reservedKeys:{sids:!0,pdata:!0,logdata:!0,callback:!0,postCallbackFn:!0,useImageRequest:!0},callbackPrefix:\"demdexRequestCallback\",firstRequestHasFired:!1,useJSONP:!0,abortRequests:!1,num_of_jsonp_responses:0,num_of_jsonp_errors:0,num_of_cors_responses:0,num_of_cors_errors:0,corsErrorSources:[],\nnum_of_img_responses:0,num_of_img_errors:0,toRemove:[],removed:[],readyToRemove:!1,platformParams:{d_nsid:n+\"\",d_rtbd:\"json\",d_jsonv:DIL.jsonVersion+\"\",d_dst:\"1\"},nonModStatsParams:{d_rtbd:!0,d_dst:!0,d_cts:!0,d_rs:!0},modStatsParams:null,adms:{TIME_TO_CATCH_ALL_REQUESTS_RELEASE:2E3,calledBack:!1,mid:null,noVisitorAPI:!1,VisitorAPI:null,instance:null,releaseType:\"no VisitorAPI\",isOptedOut:!0,isOptedOutCallbackCalled:!1,admsProcessingStarted:!1,process:function(a){try{if(!this.admsProcessingStarted){this.admsProcessingStarted=\n!0;var b=this,c;if(\"function\"===typeof a\u0026\u0026\"function\"===typeof a.getInstance){if(h===Object(h)\u0026\u0026(c=h.namespace)\u0026\u0026\"string\"===typeof c)var d=a.getInstance(c,{idSyncContainerID:n});else{this.releaseType=\"no namespace\";this.releaseRequests();return}if(d===Object(d)\u0026\u0026d instanceof a\u0026\u0026\"function\"===typeof d.isAllowed\u0026\u0026\"function\"===typeof d.getMarketingCloudVisitorID\u0026\u0026\"function\"===typeof d.getCustomerIDs\u0026\u0026\"function\"===typeof d.isOptedOut){this.VisitorAPI=a;if(!d.isAllowed()){this.releaseType=\"VisitorAPI not allowed\";\nthis.releaseRequests();return}this.instance=d;var r=function(a){\"VisitorAPI\"!==b.releaseType\u0026\u0026(b.mid=a,b.releaseType=\"VisitorAPI\",b.releaseRequests())};var f=d.getMarketingCloudVisitorID(r);if(\"string\"===typeof f\u0026\u0026f.length){r(f);return}setTimeout(function(){\"VisitorAPI\"!==b.releaseType\u0026\u0026(b.releaseType=\"timeout\",b.releaseRequests())},this.getLoadTimeout());return}this.releaseType=\"invalid instance\"}else this.noVisitorAPI=!0;this.releaseRequests()}}catch(Z){this.releaseRequests()}},releaseRequests:function(){this.calledBack=\n!0;w.registerRequest()},getMarketingCloudVisitorID:function(){return this.instance?this.instance.getMarketingCloudVisitorID():null},getMIDQueryString:function(){var a=C.isPopulatedString,b=this.getMarketingCloudVisitorID();a(this.mid)\u0026\u0026this.mid===b||(this.mid=b);return a(this.mid)?\"d_mid\\x3d\"+this.mid+\"\\x26\":\"\"},getCustomerIDs:function(){return this.instance?this.instance.getCustomerIDs():null},getCustomerIDsQueryString:function(a){if(a===Object(a)){var b=\"\",c=[],d=[],f,r;for(f in a)a.hasOwnProperty(f)\u0026\u0026\n(d[0]=f,r=a[f],r===Object(r)\u0026\u0026(d[1]=r.id||\"\",d[2]=r.authState||0,c.push(d),d=[]));if(d=c.length)for(a=0;a\u003Cd;a++)b+=\"\\x26d_cid_ic\\x3d\"+z.encodeAndBuildRequest(c[a],\"%01\");return b}return\"\"},getIsOptedOut:function(){this.instance?this.instance.isOptedOut([this,this.isOptedOutCallback],this.VisitorAPI.OptOut.GLOBAL,!0):(this.isOptedOut=!1,this.isOptedOutCallbackCalled=!0)},isOptedOutCallback:function(a){this.isOptedOut=a;this.isOptedOutCallbackCalled=!0;w.registerRequest()},getLoadTimeout:function(){var a=\nthis.instance;if(a){if(\"function\"===typeof a.getLoadTimeout)return a.getLoadTimeout();if(\"undefined\"!==typeof a.loadTimeout)return a.loadTimeout}return this.TIME_TO_CATCH_ALL_REQUESTS_RELEASE}},declaredId:{declaredId:{init:null,request:null},declaredIdCombos:{},setDeclaredId:function(a,b){var c=C.isPopulatedString,d=encodeURIComponent;if(a===Object(a)\u0026\u0026c(b)){var f=a.dpid,e=a.dpuuid;if(c(f)\u0026\u0026c(e)){c=d(f)+\"$\"+d(e);if(!0===this.declaredIdCombos[c])return\"setDeclaredId: combo exists for type '\"+b+\"'\";\nthis.declaredIdCombos[c]=!0;this.declaredId[b]={dpid:f,dpuuid:e};return\"setDeclaredId: succeeded for type '\"+b+\"'\"}}return\"setDeclaredId: failed for type '\"+b+\"'\"},getDeclaredIdQueryString:function(){var a=this.declaredId.request,b=this.declaredId.init,c=encodeURIComponent,d=\"\";null!==a?d=\"\\x26d_dpid\\x3d\"+c(a.dpid)+\"\\x26d_dpuuid\\x3d\"+c(a.dpuuid):null!==b\u0026\u0026(d=\"\\x26d_dpid\\x3d\"+c(b.dpid)+\"\\x26d_dpuuid\\x3d\"+c(b.dpuuid));return d}},registerRequest:function(a){var b=this.firingQueue;a===Object(a)\u0026\u0026b.push(a);\nthis.firing||!b.length||I\u0026\u0026!DIL.windowLoaded||(this.adms.isOptedOutCallbackCalled||this.adms.getIsOptedOut(),this.adms.calledBack\u0026\u0026!this.adms.isOptedOut\u0026\u0026this.adms.isOptedOutCallbackCalled\u0026\u0026(this.adms.isOptedOutCallbackCalled=!1,a=b.shift(),a.src=a.src.replace(\/demdex.net\\\/event\\?d_nsid=\/,\"demdex.net\/event?\"+this.adms.getMIDQueryString()+\"d_nsid\\x3d\"),C.isPopulatedString(a.corsPostData)\u0026\u0026(a.corsPostData=a.corsPostData.replace(\/^d_nsid=\/,this.adms.getMIDQueryString()+\"d_nsid\\x3d\")),Q.fireRequest(a),\nthis.firstRequestHasFired||\"script\"!==a.tag\u0026\u0026\"cors\"!==a.tag||(this.firstRequestHasFired=!0)))},processVisitorAPI:function(){this.adms.process(P||window.Visitor)},requestRemoval:function(a){if(!p)return\"removeFinishedScriptsAndCallbacks is not boolean true\";var b=this.toRemove,c,d;a===Object(a)\u0026\u0026(c=a.script,d=a.callbackName,(c===Object(c)\u0026\u0026\"SCRIPT\"===c.nodeName||\"no script created\"===c)\u0026\u0026\"string\"===typeof d\u0026\u0026d.length\u0026\u0026b.push(a));if(this.readyToRemove\u0026\u0026b.length){d=b.shift();c=d.script;d=d.callbackName;\n\"no script created\"!==c?(a=c.src,c.parentNode.removeChild(c)):a=c;window[d]=null;try{delete window[d]}catch(aa){}this.removed.push({scriptSrc:a,callbackName:d});DIL.variables.scriptsRemoved.push(a);DIL.variables.callbacksRemoved.push(d);return this.requestRemoval()}return\"requestRemoval() processed\"}};M=function(){var a=\"http:\/\/fast.\",b=\"?d_nsid\\x3d\"+n+\"#\"+encodeURIComponent(document.location.href);if(\"string\"===typeof D\u0026\u0026D.length)return D+b;E.IS_HTTPS\u0026\u0026(a=!0===g?\"https:\/\/fast.\":\"https:\/\/\");return a+\nm+\".demdex.net\/dest5.html\"+b};var F={THROTTLE_START:3E4,MAX_SYNCS_LENGTH:649,throttleTimerSet:!1,id:\"destination_publishing_iframe_\"+m+\"_\"+n,url:M(),onPagePixels:[],iframeHost:null,getIframeHost:function(a){if(\"string\"===typeof a){var b=a.split(\"\/\");if(3\u003C=b.length)return b[0]+\"\/\/\"+b[2];d.push(\"getIframeHost: url is malformed: \"+a);return a}},iframe:null,iframeHasLoaded:!1,sendingMessages:!1,messages:[],messagesPosted:[],messagesReceived:[],messageSendingInterval:E.POST_MESSAGE_ENABLED?null:100,ibsDeleted:[],\njsonForComparison:[],jsonDuplicates:[],jsonWaiting:[],jsonProcessed:[],canSetThirdPartyCookies:!0,receivedThirdPartyCookiesNotification:!1,newIframeCreated:null,iframeIdChanged:!1,originalIframeHasLoadedAlready:null,attachIframe:function(){function a(){d=document.createElement(\"iframe\");d.sandbox=\"allow-scripts allow-same-origin\";d.title=\"Adobe ID Syncing iFrame\";d.id=c.id;d.style.cssText=\"display: none; width: 0; height: 0;\";d.src=c.url;c.newIframeCreated=!0;b();document.body.appendChild(d)}function b(){z.addListener(d,\n\"load\",function(){d.className=\"aamIframeLoaded\";c.iframeHasLoaded=!0;c.requestToProcess()})}var c=this,d=document.getElementById(this.id);d?\"IFRAME\"!==d.nodeName?(this.id+=\"_2\",this.iframeIdChanged=!0,a()):(this.newIframeCreated=!1,\"aamIframeLoaded\"!==d.className?(this.originalIframeHasLoadedAlready=!1,b()):(this.iframeHasLoaded=this.originalIframeHasLoadedAlready=!0,this.iframe=d,this.requestToProcess())):a();this.iframe=d},requestToProcess:function(a,b){function c(){d.jsonForComparison.push(a);\nd.jsonWaiting.push([a,b])}var d=this,f;var e=w.adms.instance;a===Object(a)\u0026\u0026e===Object(e)\u0026\u0026e.idSyncContainerID===n\u0026\u0026(F.ibsDeleted.push(a.ibs),delete a.ibs);if(a\u0026\u0026!C.isEmptyObject(a))if(E.HAS_JSON_STRINGIFY)if(e=JSON.stringify(a.ibs||[]),f=JSON.stringify(a.dests||[]),this.jsonForComparison.length){var g=!1,r,h;var k=0;for(r=this.jsonForComparison.length;k\u003Cr;k++)if(h=this.jsonForComparison[k],e===JSON.stringify(h.ibs||[])\u0026\u0026f===JSON.stringify(h.dests||[])){g=!0;break}g?this.jsonDuplicates.push(a):c()}else c();\nelse c();(this.receivedThirdPartyCookiesNotification||!E.POST_MESSAGE_ENABLED||this.iframeHasLoaded)\u0026\u0026this.jsonWaiting.length\u0026\u0026(e=this.jsonWaiting.shift(),!1===this.newIframeCreated\u0026\u0026delete e[0].ibs,this.process(e[0],e[1]),this.requestToProcess());this.iframeHasLoaded\u0026\u0026this.messages.length\u0026\u0026!this.sendingMessages\u0026\u0026(this.throttleTimerSet||(this.throttleTimerSet=!0,setTimeout(function(){d.messageSendingInterval=E.POST_MESSAGE_ENABLED?null:150},this.THROTTLE_START)),this.sendingMessages=!0,this.sendMessages())},\nprocessSyncOnPage:function(a){var b,c;if((b=a.ibs)\u0026\u0026b instanceof Array\u0026\u0026(c=b.length))for(a=0;a\u003Cc;a++){var d=b[a];d.syncOnPage\u0026\u0026this.checkFirstPartyCookie(d,\"\",\"syncOnPage\")}},process:function(a,b){var c=encodeURIComponent,d,f,e,g;b===Object(b)\u0026\u0026(g=z.encodeAndBuildRequest([\"\",b.dpid||\"\",b.dpuuid||\"\"],\",\"));if((d=a.dests)\u0026\u0026d instanceof Array\u0026\u0026(f=d.length))for(e=0;e\u003Cf;e++){var r=d[e];var h=[c(\"dests\"),c(r.id||\"\"),c(r.y||\"\"),c(r.c||\"\")];this.addMessage(h.join(\"|\"))}if((d=a.ibs)\u0026\u0026d instanceof Array\u0026\u0026(f=\nd.length))for(e=0;e\u003Cf;e++)r=d[e],h=[c(\"ibs\"),c(r.id||\"\"),c(r.tag||\"\"),z.encodeAndBuildRequest(r.url||[],\",\"),c(r.ttl||\"\"),\"\",g,r.fireURLSync?\"true\":\"false\"],r.syncOnPage||(this.canSetThirdPartyCookies?this.addMessage(h.join(\"|\")):r.fireURLSync\u0026\u0026this.checkFirstPartyCookie(r,h.join(\"|\")));this.jsonProcessed.push(a)},checkFirstPartyCookie:function(a,b,c){var d=(c=\"syncOnPage\"===c?!0:!1)?E.FIRST_PARTY_SYNCS_ON_PAGE:E.FIRST_PARTY_SYNCS,e=this.getOnPageSyncData(d),f=!1,g=!1,r=Math.ceil((new Date).getTime()\/\nE.MILLIS_PER_DAY);e?(e=e.split(\"*\"),g=this.pruneSyncData(e,a.id,r),f=g.dataPresent,g=g.dataValid,f\u0026\u0026g||this.fireSync(c,a,b,e,d,r)):(e=[],this.fireSync(c,a,b,e,d,r))},getOnPageSyncData:function(a){var b=w.adms.instance;return b\u0026\u0026\"function\"===typeof b.idSyncGetOnPageSyncInfo?b.idSyncGetOnPageSyncInfo():z.getDilCookieField(a)},pruneSyncData:function(a,b,c){var d=!1,e=!1,f;if(a instanceof Array)for(f=0;f\u003Ca.length;f++){var g=a[f];var r=parseInt(g.split(\"-\")[1],10);g.match(\"^\"+b+\"-\")?(d=!0,c\u003Cr?e=!0:(a.splice(f,\n1),f--)):c\u003E=r\u0026\u0026(a.splice(f,1),f--)}return{dataPresent:d,dataValid:e}},manageSyncsSize:function(a){if(a.join(\"*\").length\u003Ethis.MAX_SYNCS_LENGTH)for(a.sort(function(a,b){return parseInt(a.split(\"-\")[1],10)-parseInt(b.split(\"-\")[1],10)});a.join(\"*\").length\u003Ethis.MAX_SYNCS_LENGTH;)a.shift()},fireSync:function(a,b,c,d,f,e){function g(a,b,c,d){return function(){r.onPagePixels[a]=null;var f=r.getOnPageSyncData(c),e=[];if(f){f=f.split(\"*\");var g;var h=0;for(g=f.length;h\u003Cg;h++){var k=f[h];k.match(\"^\"+b.id+\"-\")||\ne.push(k)}}r.setSyncTrackingData(e,b,c,d)}}var r=this;if(a){if(\"img\"===b.tag){a=b.url;c=E.IS_HTTPS?\"https:\":\"http:\";var h;d=0;for(h=a.length;d\u003Ch;d++){var k=a[d];var l=\/^\\\/\\\/\/.test(k);var m=new Image;z.addListener(m,\"load\",g(this.onPagePixels.length,b,f,e));m.src=(l?c:\"\")+k;this.onPagePixels.push(m)}}}else this.addMessage(c),this.setSyncTrackingData(d,b,f,e)},addMessage:function(a){var c=encodeURIComponent;c=b?c(\"---destpub-debug---\"):c(\"---destpub---\");this.messages.push((E.POST_MESSAGE_ENABLED?\"\":\nc)+a)},setSyncTrackingData:function(a,b,c,d){a.push(b.id+\"-\"+(d+Math.ceil(b.ttl\/60\/24)));this.manageSyncsSize(a);z.setDilCookieField(c,a.join(\"*\"))},sendMessages:function(){var a=this,b;this.messages.length?E.POST_MESSAGE_ENABLED?(b=encodeURIComponent(\"---destpub-combined---\")+this.messages.join(\"%01\"),this.postMessage(b),this.messages=[],this.sendingMessages=!1):(b=this.messages.shift(),this.postMessage(b),setTimeout(function(){a.sendMessages()},this.messageSendingInterval)):this.sendingMessages=\n!1},postMessage:function(a){DIL.xd.postMessage(a,this.url,this.iframe.contentWindow);this.messagesPosted.push(a)},receiveMessage:function(a){var b=\/^---destpub-to-parent---\/;\"string\"===typeof a\u0026\u0026b.test(a)\u0026\u0026(b=a.replace(b,\"\").split(\"|\"),\"canSetThirdPartyCookies\"===b[0]\u0026\u0026(this.canSetThirdPartyCookies=\"true\"===b[1]?!0:!1,this.receivedThirdPartyCookiesNotification=!0,this.requestToProcess()),this.messagesReceived.push(a))}},W={traits:function(a){C.isValidPdata(a)\u0026\u0026(B.sids instanceof Array||(B.sids=[]),\nz.extendArray(B.sids,a));return this},pixels:function(a){C.isValidPdata(a)\u0026\u0026(B.pdata instanceof Array||(B.pdata=[]),z.extendArray(B.pdata,a));return this},logs:function(a){C.isValidLogdata(a)\u0026\u0026(B.logdata!==Object(B.logdata)\u0026\u0026(B.logdata={}),z.extendObject(B.logdata,a));return this},customQueryParams:function(a){C.isEmptyObject(a)||z.extendObject(B,a,w.reservedKeys);return this},signals:function(a,b){var c,d=a;if(!C.isEmptyObject(d)){if(b\u0026\u0026\"string\"===typeof b)for(c in d={},a)a.hasOwnProperty(c)\u0026\u0026(d[b+\nc]=a[c]);z.extendObject(B,d,w.reservedKeys)}return this},declaredId:function(a){w.declaredId.setDeclaredId(a,\"request\");return this},result:function(a){\"function\"===typeof a\u0026\u0026(B.callback=a);return this},afterResult:function(a){\"function\"===typeof a\u0026\u0026(B.postCallbackFn=a);return this},useImageRequest:function(){B.useImageRequest=!0;return this},clearData:function(){B={};return this},submit:function(){Q.submitRequest(B);B={};return this},getPartner:function(){return m},getContainerNSID:function(){return n},\ngetEventLog:function(){return d},getState:function(){var a={},b={};z.extendObject(a,w,{callbackPrefix:!0,useJSONP:!0,registerRequest:!0});z.extendObject(b,F,{attachIframe:!0,requestToProcess:!0,process:!0,sendMessages:!0});return{initConfig:k,pendingRequest:B,otherRequestInfo:a,destinationPublishingInfo:b}},idSync:function(a){if(L)return\"Error: id syncs have been disabled\";if(a!==Object(a)||\"string\"!==typeof a.dpid||!a.dpid.length)return\"Error: config or config.dpid is empty\";if(\"string\"!==typeof a.url||\n!a.url.length)return\"Error: config.url is empty\";var b=a.url,c=a.minutesToLive,d=encodeURIComponent,f=F;b=b.replace(\/^https:\/,\"\").replace(\/^http:\/,\"\");if(\"undefined\"===typeof c)c=20160;else if(c=parseInt(c,10),isNaN(c)||0\u003E=c)return\"Error: config.minutesToLive needs to be a positive number\";var e=z.encodeAndBuildRequest([\"\",a.dpid,a.dpuuid||\"\"],\",\");a=[\"ibs\",d(a.dpid),\"img\",d(b),c,\"\",e];f.addMessage(a.join(\"|\"));w.firstRequestHasFired\u0026\u0026f.requestToProcess();return\"Successfully queued\"},aamIdSync:function(a){if(L)return\"Error: id syncs have been disabled\";\nif(a!==Object(a)||\"string\"!==typeof a.dpuuid||!a.dpuuid.length)return\"Error: config or config.dpuuid is empty\";a.url=\"\/\/dpm.demdex.net\/ibs:dpid\\x3d\"+a.dpid+\"\\x26dpuuid\\x3d\"+a.dpuuid;return this.idSync(a)},passData:function(a){if(C.isEmptyObject(a))return\"Error: json is empty or not an object\";F.ibsDeleted.push(a.ibs);delete a.ibs;Q.defaultCallback(a);return a},getPlatformParams:function(){return w.platformParams},getEventCallConfigParams:function(){var a=w,b=a.modStatsParams,c=a.platformParams,d;\nif(!b){b={};for(d in c)c.hasOwnProperty(d)\u0026\u0026!a.nonModStatsParams[d]\u0026\u0026(b[d.replace(\/^d_\/,\"\")]=c[d]);a.modStatsParams=b}return b}},Q={corsMetadata:function(){var a=\"none\",b=!0;\"undefined\"!==typeof XMLHttpRequest\u0026\u0026XMLHttpRequest===Object(XMLHttpRequest)\u0026\u0026(\"withCredentials\"in new XMLHttpRequest?a=\"XMLHttpRequest\":(new Function(\"\/*@cc_on return \/^10\/.test(@_jscript_version) @*\/\"))()?a=\"XMLHttpRequest\":\"undefined\"!==typeof XDomainRequest\u0026\u0026XDomainRequest===Object(XDomainRequest)\u0026\u0026(b=!1),0\u003CObject.prototype.toString.call(window.HTMLElement).indexOf(\"Constructor\")\u0026\u0026\n(b=!1));return{corsType:a,corsCookiesEnabled:b}}(),getCORSInstance:function(){return\"none\"===this.corsMetadata.corsType?null:new window[this.corsMetadata.corsType]},submitRequest:function(a){w.registerRequest(Q.createQueuedRequest(a));return!0},createQueuedRequest:function(a){var b=w,c,d=a.callback,f=\"img\",e;if(!C.isEmptyObject(q)){var g,h,k;for(g in q)q.hasOwnProperty(g)\u0026\u0026(h=q[g],null!=h\u0026\u0026\"\"!==h\u0026\u0026g in a\u0026\u0026!(h in a||h in w.reservedKeys)\u0026\u0026(k=a[g],null!=k\u0026\u0026\"\"!==k\u0026\u0026(a[h]=k)))}C.isValidPdata(a.sids)||\n(a.sids=[]);C.isValidPdata(a.pdata)||(a.pdata=[]);C.isValidLogdata(a.logdata)||(a.logdata={});a.logdataArray=z.convertObjectToKeyValuePairs(a.logdata,\"\\x3d\",!0);a.logdataArray.push(\"_ts\\x3d\"+(new Date).getTime());\"function\"!==typeof d\u0026\u0026(d=this.defaultCallback);b.useJSONP=!0!==a.useImageRequest;b.useJSONP\u0026\u0026(f=\"script\",c=b.callbackPrefix+\"_\"+n+\"_\"+(new Date).getTime());b=this.makeRequestSrcData(a,c);O\u0026\u0026!u||!(e=this.getCORSInstance())||(f=\"cors\");return{tag:f,src:b.src,corsSrc:b.corsSrc,internalCallbackName:c,\ncallbackFn:d,postCallbackFn:a.postCallbackFn,useImageRequest:!!a.useImageRequest,requestData:a,corsInstance:e,corsPostData:b.corsPostData}},defaultCallback:function(a,b){F.processSyncOnPage(a);var d,f,e,g;if((d=a.stuff)\u0026\u0026d instanceof Array\u0026\u0026(f=d.length))for(e=0;e\u003Cf;e++)if((g=d[e])\u0026\u0026g===Object(g)){var h=g.cn;var k=g.cv;var m=g.ttl;if(\"undefined\"===typeof m||\"\"===m)m=Math.floor(z.getMaxCookieExpiresInMinutes()\/60\/24);var r=g.dmn||\".\"+document.domain.replace(\/^www\\.\/,\"\");var n=g.type;h\u0026\u0026(k||\"number\"===\ntypeof k)\u0026\u0026(\"var\"!==n\u0026\u0026(m=parseInt(m,10))\u0026\u0026!isNaN(m)\u0026\u0026z.setCookie(h,k,1440*m,\"\/\",r,!1),N.stuffed[h]=k)}d=a.uuid;C.isPopulatedString(d)\u0026\u0026!C.isEmptyObject(c)\u0026\u0026(f=c.path,\"string\"===typeof f\u0026\u0026f.length||(f=\"\/\"),e=parseInt(c.days,10),isNaN(e)\u0026\u0026(e=100),z.setCookie(c.name||\"aam_did\",d,1440*e,f,c.domain||\".\"+document.domain.replace(\/^www\\.\/,\"\"),!0===c.secure));l||w.abortRequests||F.requestToProcess(a,b)},makeRequestSrcData:function(a,b){a.sids=C.removeEmptyArrayValues(a.sids||[]);a.pdata=C.removeEmptyArrayValues(a.pdata||\n[]);var c=w,d=c.platformParams,f=z.encodeAndBuildRequest(a.sids,\",\"),e=z.encodeAndBuildRequest(a.pdata,\",\"),g=(a.logdataArray||[]).join(\"\\x26\");delete a.logdataArray;var h=E.IS_HTTPS?\"https:\/\/\":\"http:\/\/\",k=c.declaredId.getDeclaredIdQueryString(),l=c.adms.instance?c.adms.getCustomerIDsQueryString(c.adms.getCustomerIDs()):\"\";var r=[];var J,p,q;for(J in a)if(!(J in c.reservedKeys)\u0026\u0026a.hasOwnProperty(J))if(p=a[J],J=encodeURIComponent(J),p instanceof Array){var t=0;for(q=p.length;t\u003Cq;t++)r.push(J+\"\\x3d\"+\nencodeURIComponent(p[t]))}else r.push(J+\"\\x3d\"+encodeURIComponent(p));r=r.length?\"\\x26\"+r.join(\"\\x26\"):\"\";f=\"d_nsid\\x3d\"+d.d_nsid+k+l+(f.length?\"\\x26d_sid\\x3d\"+f:\"\")+(e.length?\"\\x26d_px\\x3d\"+e:\"\")+(g.length?\"\\x26d_ld\\x3d\"+encodeURIComponent(g):\"\");d=\"\\x26d_rtbd\\x3d\"+d.d_rtbd+\"\\x26d_jsonv\\x3d\"+d.d_jsonv+\"\\x26d_dst\\x3d\"+d.d_dst;h=h+m+\".demdex.net\/event\";e=c=h+\"?\"+f+(c.useJSONP?d+\"\\x26d_cb\\x3d\"+(b||\"\"):\"\")+r;2048\u003Cc.length\u0026\u0026(c=c.substring(0,2048).substring(0,c.lastIndexOf(\"\\x26\")));return{corsSrc:h+\"?\"+\n(y?\"testcors\\x3d1\\x26d_nsid\\x3d\"+n+\"\\x26\":\"\")+\"_ts\\x3d\"+(new Date).getTime(),src:c,originalSrc:e,corsPostData:f+d+r,isDeclaredIdCall:\"\"!==k}},fireRequest:function(a){if(\"img\"===a.tag)this.fireImage(a);else{var b=w.declaredId;b=b.declaredId.request||b.declaredId.init||{};b={dpid:b.dpid||\"\",dpuuid:b.dpuuid||\"\"};\"script\"===a.tag?this.fireScript(a,b):\"cors\"===a.tag\u0026\u0026this.fireCORS(a,b)}},fireImage:function(a){var b=w,c,e;b.abortRequests||(b.firing=!0,c=new Image(0,0),b.sent.push(a),c.onload=function(){b.firing=\n!1;b.fired.push(a);b.num_of_img_responses++;b.registerRequest()},e=function(c){f=\"imgAbortOrErrorHandler received the event of type \"+c.type;d.push(f);b.abortRequests=!0;b.firing=!1;b.errored.push(a);b.num_of_img_errors++;b.registerRequest()},c.addEventListener?(c.addEventListener(\"error\",e,!1),c.addEventListener(\"abort\",e,!1)):c.attachEvent\u0026\u0026(c.attachEvent(\"onerror\",e),c.attachEvent(\"onabort\",e)),c.src=a.src)},fireScript:function(a,b){var c=this,e=w,g,h,k=a.src,l=a.postCallbackFn,n=\"function\"===\ntypeof l,r=a.internalCallbackName;e.abortRequests||(e.firing=!0,window[r]=function(c){try{c!==Object(c)\u0026\u0026(c={});L\u0026\u0026(F.ibsDeleted.push(c.ibs),delete c.ibs);var g=a.callbackFn;e.firing=!1;e.fired.push(a);e.num_of_jsonp_responses++;g(c,b);n\u0026\u0026l(c,b)}catch(A){A.message=\"DIL jsonp callback caught error with message \"+A.message;f=A.message;d.push(f);A.filename=A.filename||\"dil.js\";A.partner=m;DIL.errorModule.handleError(A);try{g({error:A.name+\"|\"+A.message},b),n\u0026\u0026l({error:A.name+\"|\"+A.message},b)}catch(Y){}}finally{e.requestRemoval({script:h,\ncallbackName:r}),e.registerRequest()}},G||u?(e.firing=!1,e.requestRemoval({script:\"no script created\",callbackName:r})):(h=document.createElement(\"script\"),h.addEventListener\u0026\u0026h.addEventListener(\"error\",function(b){e.requestRemoval({script:h,callbackName:r});f=\"jsonp script tag error listener received the event of type \"+b.type+\" with src \"+k;c.handleScriptError(f,a)},!1),h.type=\"text\/javascript\",h.src=k,g=DIL.variables.scriptNodeList[0],g.parentNode.insertBefore(h,g)),e.sent.push(a),e.declaredId.declaredId.request=\nnull)},fireCORS:function(a,b){var c=this,e=w,g=this.corsMetadata.corsType,h=a.corsSrc,k=a.corsInstance,l=a.corsPostData,n=a.postCallbackFn,r=\"function\"===typeof n;if(!e.abortRequests\u0026\u0026!R){e.firing=!0;try{k.open(\"post\",h,!0),\"XMLHttpRequest\"===g\u0026\u0026(k.withCredentials=!0,k.setRequestHeader(\"Content-Type\",\"application\/x-www-form-urlencoded\"),k.onreadystatechange=function(){if(4===this.readyState\u0026\u0026200===this.status)a:{var g;try{if(g=JSON.parse(this.responseText),g!==Object(g)){c.handleCORSError(a,b,\"Response is not JSON\");\nbreak a}}catch(A){c.handleCORSError(a,b,\"Error parsing response as JSON\");break a}L\u0026\u0026(F.ibsDeleted.push(g.ibs),delete g.ibs);try{var h=a.callbackFn;e.firing=!1;e.fired.push(a);e.num_of_cors_responses++;h(g,b);r\u0026\u0026n(g,b)}catch(A){A.message=\"DIL handleCORSResponse caught error with message \"+A.message;f=A.message;d.push(f);A.filename=A.filename||\"dil.js\";A.partner=m;DIL.errorModule.handleError(A);try{h({error:A.name+\"|\"+A.message},b),r\u0026\u0026n({error:A.name+\"|\"+A.message},b)}catch(Y){}}finally{e.registerRequest()}}}),\nk.onerror=function(){c.handleCORSError(a,b,\"onerror\")},k.ontimeout=function(){c.handleCORSError(a,b,\"ontimeout\")},k.send(l)}catch(ba){this.handleCORSError(a,b,\"try-catch\")}e.sent.push(a);e.declaredId.declaredId.request=null}},handleCORSError:function(a,b,c){w.num_of_cors_errors++;w.corsErrorSources.push(c);\"ontimeout\"===c||u||(a.tag=\"script\",this.fireScript(a,b))},handleScriptError:function(a,b){w.num_of_jsonp_errors++;this.handleRequestError(a,b)},handleRequestError:function(a,b){var c=w;d.push(a);\nc.abortRequests=!0;c.firing=!1;c.errored.push(b);c.registerRequest()}},C={isValidPdata:function(a){return a instanceof Array\u0026\u0026this.removeEmptyArrayValues(a).length?!0:!1},isValidLogdata:function(a){return!this.isEmptyObject(a)},isEmptyObject:function(a){if(a!==Object(a))return!0;for(var b in a)if(a.hasOwnProperty(b))return!1;return!0},removeEmptyArrayValues:function(a){var b,c=a.length,d=[];for(b=0;b\u003Cc;b++){var e=a[b];\"undefined\"!==typeof e\u0026\u0026null!==e\u0026\u0026\"\"!==e\u0026\u0026d.push(e)}return d},isPopulatedString:function(a){return\"string\"===\ntypeof a\u0026\u0026a.length}},z={addListener:function(){if(document.addEventListener)return function(a,b,c){a.addEventListener(b,function(a){\"function\"===typeof c\u0026\u0026c(a)},!1)};if(document.attachEvent)return function(a,b,c){a.attachEvent(\"on\"+b,function(a){\"function\"===typeof c\u0026\u0026c(a)})}}(),convertObjectToKeyValuePairs:function(a,b,c){var d=[],e,f;b||(b=\"\\x3d\");for(e in a)a.hasOwnProperty(e)\u0026\u0026(f=a[e],\"undefined\"!==typeof f\u0026\u0026null!==f\u0026\u0026\"\"!==f\u0026\u0026d.push(e+b+(c?encodeURIComponent(f):f)));return d},encodeAndBuildRequest:function(a,\nb){return this.map(a,function(a){return encodeURIComponent(a)}).join(b)},map:function(a,b){if(Array.prototype.map)return a.map(b);if(void 0===a||null===a)throw new TypeError;var c=Object(a),d=c.length\u003E\u003E\u003E0;if(\"function\"!==typeof b)throw new TypeError;for(var e=Array(d),f=0;f\u003Cd;f++)f in c\u0026\u0026(e[f]=b.call(b,c[f],f,c));return e},filter:function(a,b){if(!Array.prototype.filter){if(void 0===a||null===a)throw new TypeError;var c=Object(a),d=c.length\u003E\u003E\u003E0;if(\"function\"!==typeof b)throw new TypeError;for(var e=\n[],f=0;f\u003Cd;f++)if(f in c){var g=c[f];b.call(b,g,f,c)\u0026\u0026e.push(g)}return e}return a.filter(b)},getCookie:function(a){a+=\"\\x3d\";var b=document.cookie.split(\";\"),c,d;var e=0;for(c=b.length;e\u003Cc;e++){for(d=b[e];\" \"===d.charAt(0);)d=d.substring(1,d.length);if(0===d.indexOf(a))return decodeURIComponent(d.substring(a.length,d.length))}return null},setCookie:function(a,b,c,d,e,f){var g=new Date;c\u0026\u0026(c*=6E4);document.cookie=a+\"\\x3d\"+encodeURIComponent(b)+(c?\";expires\\x3d\"+(new Date(g.getTime()+c)).toUTCString():\n\"\")+(d?\";path\\x3d\"+d:\"\")+(e?\";domain\\x3d\"+e:\"\")+(f?\";secure\":\"\")},extendArray:function(a,b){return a instanceof Array\u0026\u0026b instanceof Array?(Array.prototype.push.apply(a,b),!0):!1},extendObject:function(a,b,c){var d;if(a===Object(a)\u0026\u0026b===Object(b)){for(d in b)!b.hasOwnProperty(d)||!C.isEmptyObject(c)\u0026\u0026d in c||(a[d]=b[d]);return!0}return!1},getMaxCookieExpiresInMinutes:function(){return((new Date(E.COOKIE_MAX_EXPIRATION_DATE)).getTime()-(new Date).getTime())\/1E3\/60},getCookieField:function(a,b){var c=\nthis.getCookie(a),d=decodeURIComponent;if(\"string\"===typeof c){c=c.split(\"|\");var e;var f=0;for(e=c.length-1;f\u003Ce;f++)if(d(c[f])===b)return d(c[f+1])}return null},getDilCookieField:function(a){return this.getCookieField(E.DIL_COOKIE_NAME,a)},setCookieField:function(a,b,c){var d=this.getCookie(a),e=!1,f=encodeURIComponent;b=f(b);c=f(c);if(\"string\"===typeof d){d=d.split(\"|\");var g;f=0;for(g=d.length-1;f\u003Cg;f++)if(d[f]===b){d[f+1]=c;e=!0;break}e||(f=d.length,d[f]=b,d[f+1]=c)}else d=[b,c];this.setCookie(a,\nd.join(\"|\"),this.getMaxCookieExpiresInMinutes(),\"\/\",this.getDomain(),!1)},setDilCookieField:function(a,b){return this.setCookieField(E.DIL_COOKIE_NAME,a,b)},getDomain:function(a){!a\u0026\u0026window.location\u0026\u0026(a=window.location.hostname);if(a)if(\/^[0-9.]+$\/.test(a))a=\"\";else{var b=a.split(\".\"),c=b.length-1,d=c-1;1\u003Cc\u0026\u00262\u003E=b[c].length\u0026\u0026(2===b[c-1].length||0\u003E\",DOMAIN_2_CHAR_EXCEPTIONS,\".indexOf(\",\"+b[c]+\",\"))\u0026\u0026d--;if(0\u003Cd)for(a=\"\";c\u003E=d;)a=b[c]+(a?\".\":\"\")+a,c--}return a}};\"error\"===m\u0026\u00260===n\u0026\u0026z.addListener(window,\n\"load\",function(){DIL.windowLoaded=!0});var X=!1,U=function(){X||(X=!0,w.registerRequest(),V(),l||w.abortRequests||F.attachIframe(),w.readyToRemove=!0,w.requestRemoval())},V=function(){l||setTimeout(function(){t||w.firstRequestHasFired||(\"function\"===typeof K?W.afterResult(K).submit():W.submit())},DIL.constants.TIME_TO_DEFAULT_REQUEST)};H=document;\"error\"!==m\u0026\u0026(DIL.windowLoaded?U():\"complete\"!==H.readyState\u0026\u0026\"loaded\"!==H.readyState?z.addListener(window,\"load\",function(){DIL.windowLoaded=!0;U()}):\n(DIL.windowLoaded=!0,U()));if(\"error\"!==m)try{DIL.xd.receiveMessage(function(a){F.receiveMessage(a.data)},F.getIframeHost(F.url))}catch(r){}w.declaredId.setDeclaredId(e,\"init\");w.processVisitorAPI();this.api=W;this.getStuffedVariable=function(a){var b=N.stuffed[a];b||\"number\"===typeof b||(b=z.getCookie(a))||\"number\"===typeof b||(b=\"\");return b};this.validators=C;this.helpers=z;this.constants=E;this.log=d;S\u0026\u0026(this.pendingRequest=B,this.requestController=w,this.setDestinationPublishingUrl=M,this.destinationPublishing=\nF,this.requestProcs=Q,this.variables=N,this.callWindowLoadFunctions=U)},function(){var k=document,a;null==k.readyState\u0026\u0026k.addEventListener\u0026\u0026(k.readyState=\"loading\",k.addEventListener(\"DOMContentLoaded\",a=function(){k.removeEventListener(\"DOMContentLoaded\",a,!1);k.readyState=\"complete\"},!1))}(),DIL.extendStaticPropertiesAndMethods=function(k){var a;if(k===Object(k))for(a in k)k.hasOwnProperty(a)\u0026\u0026(this[a]=k[a])},DIL.extendStaticPropertiesAndMethods({version:\"6.10\",jsonVersion:1,constants:{TIME_TO_DEFAULT_REQUEST:50},\nvariables:{scriptNodeList:document.getElementsByTagName(\"script\"),scriptsRemoved:[],callbacksRemoved:[]},windowLoaded:!1,dils:{},isAddedPostWindowLoad:function(k){this.windowLoaded=\"function\"===typeof k?!!k():\"boolean\"===typeof k?k:!0},create:function(k){try{return new DIL(k)}catch(a){throw Error(\"Error in attempt to create DIL instance with DIL.create(): \"+a.message);}},registerDil:function(k,a,d){a=a+\"$\"+d;a in this.dils||(this.dils[a]=k)},getDil:function(k,a){\"string\"!==typeof k\u0026\u0026(k=\"\");a||(a=\n0);var d=k+\"$\"+a;return d in this.dils?this.dils[d]:Error(\"The DIL instance with partner \\x3d \"+k+\" and containerNSID \\x3d \"+a+\" was not found\")},dexGetQSVars:function(k,a,d){a=this.getDil(a,d);return a instanceof this?a.getStuffedVariable(k):\"\"},xd:{postMessage:function(k,a,d){var f=1;a\u0026\u0026(window.postMessage?d.postMessage(k,a.replace(\/([^:]+:\\\/\\\/[^\\\/]+).*\/,\"$1\")):a\u0026\u0026(d.location=a.replace(\/#.*$\/,\"\")+\"#\"+ +new Date+f++ +\"\\x26\"+k))},receiveMessage:function(k,a){var d;try{if(window.postMessage)if(k\u0026\u0026\n(d=function(d){if(\"string\"===typeof a\u0026\u0026d.origin!==a||\"[object Function]\"===Object.prototype.toString.call(a)\u0026\u0026!1===a(d.origin))return!1;k(d)}),window.addEventListener)window[k?\"addEventListener\":\"removeEventListener\"](\"message\",d,!1);else window[k?\"attachEvent\":\"detachEvent\"](\"onmessage\",d)}catch(f){}}}}),DIL.errorModule=function(){var k=DIL.create({partner:\"error\",containerNSID:0,disableDestinationPublishingIframe:!0}),a={harvestererror:14138,destpuberror:14139,dpmerror:14140,generalerror:14137,\nerror:14137,noerrortypedefined:15021,evalerror:15016,rangeerror:15017,referenceerror:15018,typeerror:15019,urierror:15020},d=!1;return{activate:function(){d=!0},handleError:function(f){if(!d)return\"DIL error module has not been activated\";f!==Object(f)\u0026\u0026(f={});var m=f.name?(f.name+\"\").toLowerCase():\"\",n=[];f={name:m,filename:f.filename?f.filename+\"\":\"\",partner:f.partner?f.partner+\"\":\"no_partner\",site:f.site?f.site+\"\":document.location.href,message:f.message?f.message+\"\":\"\"};n.push(m in a?a[m]:a.noerrortypedefined);\nk.api.pixels(n).logs(f).useImageRequest().submit();return\"DIL error report sent\"},pixelMap:a}}(),DIL.tools={},DIL.modules={helpers:{handleModuleError:function(k,a,d){var f=\"\";a=a||\"Error caught in DIL module\/submodule: \";k===Object(k)?f=a+(k.message||\"err has no message\"):(f=a+\"err is not a valid object\",k={});k.message=f;d instanceof DIL\u0026\u0026(k.partner=d.api.getPartner());DIL.errorModule.handleError(k);return this.errorMessage=f}}});P.getInstance=O;window.s_objectID||(window.s_objectID=0);V();var K=\nwindow;I=\"object\"==typeof K._A\u0026\u0026K._A.constructor!==Array;var q=O(\"dummyRSID\"),R=\"UDL ERROR in\",S=\": Direct access to Adobe Analytics not allowed. Analytics data must be pushed on window.dataLayer.\",N=function(){var k=\"\",a=\"object\"==typeof K._A\u0026\u0026window.s.constructor!==Array?_A.getStackTrace():[],d;for(d=0;d\u003Ca.length;d++)k+=\"\\n\"+a[d];return k};K.s_gi=function(){console.log(R,\"s_gi()\"+S,N())};K.s={t:function(){console.log(R,\"s.t()\"+S,N())},tl:function(){console.log(R,\"s.tl()\"+S,N())}};q.charSet=(I?_A.getCharSet():\n\"\")||\"UTF-8\";q.visitorNamespace=\"hpcorp\";q.trackingServer=\"met1.hp.com\";q.trackingServerSecure=\"met2.hp.com\";q.linkInternalFilters=\"hp.com,hpconnected.com,hpsalescentral.com,compaq.com,hpcontent.com,hp-mpp.com,hpautodelivery.com,hpdirect.com.hk,hpshopping.co.nz,hpshopping.id,hpshopping.in,hpstore.cn,hpstorethailand.com,hponline.cl,hponline.com.ar,hponline.com.co,hponline.com.mx,hponlinestore.com.pe,lojahp.com.br\";q.linkDownloadFileTypes=\"7z,adpp,air,app,avi,bin,cnf,cptx,dmg,doc,docx,ds_tore,exe,flv,gif,gz,hqx,icns,iso,jar,jpeg,jpg,kext,mov,mp3,mpeg,mpg,msi,mxp,otf,pdf,pfx,plist,png,ppt,pptx,scpt,snd,swp,tgz,thm,tiff,ttf,vcf,wav,wmv,xls,xlsx,xml,zip,zxp\";\nq.trackDownloadLinks=!0;q.trackExternalLinks=!0;q.trackInlineStats=!0;q.linkLeaveQueryString=!1;q.usePlugins=!0;s_doPlugins=function(k){try{k.callType()}catch(a){console.log(\"UDL ERROR in s.doPlugins\",a)}};q.doPlugins=s_doPlugins;q.wd=window;q.fl=new Function(\"x\",\"l\",\"return x?(''+x).substring(0,l):x\");q.pt=new Function(\"x\",\"d\",\"f\",\"a\",\"var s\\x3dthis,t\\x3dx,z\\x3d0,y,r,l\\x3d'length';while(t){y\\x3dt.indexOf(d);y\\x3dy\\x3c0?t[l]:y;t\\x3dt.substring(0,y);r\\x3ds[f](t,a);if(r)return r;z+\\x3dy+d[l];t\\x3dx.substring(z,x[l]);t\\x3dz\\x3cx[l]?t:''}return''\");\nq.rep=new Function(\"x\",\"o\",\"n\",\"var a\\x3dnew Array,i\\x3d0,j;if(x){if(x.split)a\\x3dx.split(o);else if(!o)for(i\\x3d0;i\\x3cx.length;i++)a[a.length]\\x3dx.substring(i,i+1);else while(i\\x3e\\x3d0){j\\x3dx.indexOf(o,i);a[a.length]\\x3dx.substring(i,j\\x3c0?x.length:j);i\\x3dj;if(i\\x3e\\x3d0)i+\\x3do.length}}x\\x3d'';j\\x3da.length;if(a\\x26\\x26j\\x3e0){x\\x3da[0];if(j\\x3e1){if(a.join)x\\x3da.join(n);else for(i\\x3d1;i\\x3cj;i++)x+\\x3dn+a[i]}}return x\");q.ape=new Function(\"x\",\"var s\\x3dthis,h\\x3d'0123456789ABCDEF',f\\x3d'+~!*()\\\\'',i,c\\x3ds.charSet,n,l,e,y\\x3d'';c\\x3dc?c.toUpperCase():'';if(x){x\\x3d''+x;if(s.em\\x3d\\x3d3){x\\x3dencodeURIComponent(x);for(i\\x3d0;i\\x3cf.length;i++){n\\x3df.substring(i,i+1);if(x.indexOf(n)\\x3e\\x3d0)x\\x3ds.rep(x,n,'%'+n.charCodeAt(0).toString(16).toUpperCase())}}else if(c\\x3d\\x3d'AUTO'\\x26\\x26('').charCodeAt){for(i\\x3d0;i\\x3cx.length;i++){c\\x3dx.substring(i,i+1);n\\x3dx.charCodeAt(i);if(n\\x3e127){l\\x3d0;e\\x3d'';while(n||l\\x3c4){e\\x3dh.substring(n%16,n%16+1)+e;n\\x3d(n-n%16)\/16;l++}y+\\x3d'%u'+e}else if(c\\x3d\\x3d'+')y+\\x3d'%2B';else y+\\x3descape(c)}x\\x3dy}else x\\x3ds.rep(escape(''+x),'+','%2B');if(c\\x26\\x26c!\\x3d'AUTO'\\x26\\x26s.em\\x3d\\x3d1\\x26\\x26x.indexOf('%u')\\x3c0\\x26\\x26x.indexOf('%U')\\x3c0){i\\x3dx.indexOf('%');while(i\\x3e\\x3d0){i++;if(h.substring(8).indexOf(x.substring(i,i+1).toUpperCase())\\x3e\\x3d0)return x.substring(0,i)+'u00'+x.substring(i);i\\x3dx.indexOf('%',i)}}}return x\");\nq.epa=new Function(\"x\",\"var s\\x3dthis,y,tcf;if(x){x\\x3ds.rep(''+x,'+',' ');if(s.em\\x3d\\x3d3){tcf\\x3dnew Function('x','var y,e;try{y\\x3ddecodeURIComponent(x)}catch(e){y\\x3dunescape(x)}return y');return tcf(x)}else return unescape(x)}return y\");q.parseUri=new Function(\"u\",\"if(u){u\\x3du+'';u\\x3du.indexOf(':')\\x3c0\\x26\\x26u.indexOf('\/\/')!\\x3d0?(u.indexOf('\/')\\x3d\\x3d0?'\/':'\/\/')+u:u}u\\x3du?u+'':window.location.href;var e,a\\x3ddocument.createElement('a'),l\\x3d['href','protocol','host','hostname','port','pathname','search','hash'],p,r\\x3d{href:u,toString:function(){return this.href}};a.setAttribute('href',u);for(e\\x3d1;e\\x3cl.length;e++){p\\x3dl[e];r[p]\\x3da[p]||''}delete a;p\\x3dr.pathname||'';if(p.indexOf('\/')!\\x3d0)r.pathname\\x3d'\/'+p;return r\");\nq.gtfs=new Function(\"var w\\x3dwindow,l\\x3dw.location,d\\x3ddocument,u;if(!l.origin)l.origin\\x3dl.protocol+'\/\/'+l.hostname+(l.port?':'+l.port:'');u\\x3dl!\\x3dw.parent.location?d.referrer:d.location;return{location:s.parseUri(u)}\");q.apl=new Function(\"l\",\"v\",\"d\",\"u\",\"var m\\x3d0;if(!l)l\\x3d'';if(u){var i,n,a\\x3ds.split(l,d);for(i\\x3d0;i\\x3ca.length;i++){n\\x3da[i];m\\x3dm||(u\\x3d\\x3d1?(n\\x3d\\x3dv):(n.toLowerCase()\\x3d\\x3dv.toLowerCase()));}}if(!m)l\\x3dl?l+d+v:v;return l\");q.p_c=new Function(\"v\",\"c\",\"var x\\x3dv.indexOf('\\x3d');return c.toLowerCase()\\x3d\\x3dv.substring(0,x\\x3c0?v.length:x).toLowerCase()?v:0\");\nq.p_gh=new Function(\"var s\\x3dthis;if(!s.eo\\x26\\x26!s.lnk)return '';var o\\x3ds.eo?s.eo:s.lnk,y\\x3ds.ot(o),n\\x3ds.oid(o),x\\x3do.s_oidt;if(s.eo\\x26\\x26o\\x3d\\x3ds.eo){while(o\\x26\\x26!n\\x26\\x26y!\\x3d'BODY'){o\\x3do.parentElement?o.parentElement:o.parentNode;if(!o)return '';y\\x3ds.ot(o);n\\x3ds.oid(o);x\\x3do.s_oidt}}return o.href?o.href:'';\");q.escp=new Function(\"x\",\"var s\\x3dthis;if(typeof(decodeURI)\\x3d\\x3d'function'\\x26\\x26x)return decodeURI(s.rep(''+x,'+',' '));else return unescape(s.rep(''+x,'+',' '));\");\nq.vpr=new Function(\"vs\",\"v\",\"if(typeof(v)!\\x3d'undefined'){var s\\x3dthis; eval('s.'+vs+'\\x3d\\\"'+v+'\\\"')}\");q.repl=new Function(\"x\",\"o\",\"n\",\"var i\\x3dx.indexOf(o),l\\x3dn.length;while(x\\x26\\x26i\\x3e\\x3d0){x\\x3dx.substring(0,i)+n+x.substring(i+o.length);i\\x3dx.indexOf(o,i+l)}return x\");I?(cR=_A.cR,cW=_A.cW):(cR=q.c_r,cW=q.c_w);q.trackTNT=new Function(\"v\",\"p\",\"b\",\"var s\\x3dthis,n\\x3d's_tnt',p\\x3dp?p:n,v\\x3dv?v:n,r\\x3d'',pm\\x3dfalse,b\\x3db?b:true;if(s.getQueryParam){pm\\x3ds.getQueryParam(p);}if(pm){r+\\x3d(pm+',');}if(s.wd[v]!\\x3dundefined){r+\\x3ds.wd[v];}if(b){s.wd[v]\\x3d'';}return r;\");\nq.getNewRepeat=new Function(\"d\",\"cn\",\"var s\\x3dthis,e\\x3dnew Date(),cval,sval,ct\\x3de.getTime();d\\x3dd?d:30;cn\\x3dcn?cn:'s_nr';e.setTime(ct+d*24*60*60*1000);cval\\x3ds.c_r(cn);if(cval.length\\x3d\\x3d0){s.c_w(cn,ct+'-New',e);return'New';}sval\\x3ds.split(cval,'-');if(ct-sval[0]\\x3c30*60*1000\\x26\\x26sval[1]\\x3d\\x3d'New'){s.c_w(cn,ct+'-New',e);return'New';}else{s.c_w(cn,ct+'-Repeat',e);return'Repeat';}\");q.split=new Function(\"l\",\"d\",\"var i,x\\x3d0,a\\x3dnew Array;while(l){i\\x3dl.indexOf(d);i\\x3di\\x3e-1?i:l.length;a[x++]\\x3dl.substring(0,i);l\\x3dl.substring(i+d.length);}return a\");\nq.genHash=new Function(\"t\",\"if(!t)return'';var T\\x3dthis,m\\x3d22695477,i\\x3d0,v\\x3d0,r\\x3dfunction(v){return(v\\x3e\\x3e\\x3e1|v\\x3c\\x3c31)\\x3e\\x3e\\x3e0};if(!T.genHashT){T.genHashT\\x3dnew Array(256);while(i\\x3c256)T.genHashT[i++]\\x3dv\\x3dr(v*m+11)}i\\x3dv\\x3d0;while(i\\x3ct.length)v\\x3dr(v^T.genHashT[t.charCodeAt(i++)]);return v.toString(16)\");q.split2=new Function(\"l\",\"d\",\"var i,x\\x3d0,a\\x3dnew Array;while(l){i\\x3dl.indexOf(d);i\\x3di\\x3e-1?i:l.length;a[x++]\\x3dl.substring(0,i);l\\x3dl.substring(i+d.length);}return a\");\nq.join=new Function(\"v\",\"p\",\"var s\\x3dthis;var f,b,d,w;if(p){f\\x3dp.front?p.front:'';b\\x3dp.back?p.back:'';d\\x3dp.delim?p.delim:'';w\\x3dp.wrap?p.wrap:'';}var str\\x3d'';for(var x\\x3d0;x\\x3cv.length;x++){if(typeof(v[x])\\x3d\\x3d'object' )str+\\x3ds.join( v[x],p);else str+\\x3dw+v[x]+w;if(x\\x3cv.length-1)str+\\x3dd;}return f+str+b;\");q.getValOnce=new Function(\"v\",\"c\",\"e\",\"t\",\"var s\\x3dthis,a\\x3dnew Date,v\\x3dv?v:'',c\\x3dc?c:'s_gvo',e\\x3de?e:0,i\\x3dt\\x3d\\x3d'm'?60000:86400000;k\\x3dcR(c);if(v){a.setTime(a.getTime()+e*i);cW(c,v,e\\x3d\\x3d0?0:a);}return v\\x3d\\x3dk?'':v\");\nq.getPreviousValue=new Function(\"v\",\"c\",\"el\",\"var t\\x3dnew Date,i,j,r\\x3d'',u\\x3darguments.length\\x3c4||!!arguments[3];t.setTime(t.getTime()+1800000);if(el){if(s.events){i\\x3ds.split(el,',');j\\x3ds.split(s.events,',');for(x in i){for(y in j){if(i[x]\\x3d\\x3dj[y]){if(cR(c))r\\x3dcR(c);if(u)v?cW(c,v,t):cW(c,'no value',t);return r}}}}}else{if(cR(c)) r\\x3dcR(c);if(u)v?cW(c,v,t):cW(c,'no value',t);return r}\");q.getQueryParam=new Function(\"p\",\"d\",\"u\",\"h\",\"var s\\x3dthis,v\\x3d'',i,j,t;d\\x3dd?d:'';u\\x3du?u:(s.pageURL?s.pageURL:s.wd.location);if(u\\x3d\\x3d'f')u\\x3ds.gtfs().location;while(p){i\\x3dp.indexOf(',');i\\x3di\\x3c0?p.length:i;t\\x3ds.p_gpv(p.substring(0,i),u+'',h);if(t){t\\x3dt.indexOf('#')\\x3e-1?t.substring(0,t.indexOf('#')):t;}if(t)v+\\x3dv?d+t:t;p\\x3dp.substring(i\\x3d\\x3dp.length?i:i+1)}return v\");\nq.p_gpv=new Function(\"k\",\"u\",\"h\",\"var s\\x3dthis,v\\x3d'',q;j\\x3dh\\x3d\\x3d1?'#':'?';i\\x3du.indexOf(j);if(k\\x26\\x26i\\x3e-1){q\\x3du.substring(i+1);v\\x3ds.pt(q,'\\x26','p_gvf',k)}return v\");q.p_gvf=new Function(\"t\",\"k\",\"if(t){var s\\x3dthis,i\\x3dt.indexOf('\\x3d'),p\\x3di\\x3c0?t:t.substring(0,i),v\\x3di\\x3c0?'True':t.substring(i+1);if(p.toLowerCase()\\x3d\\x3dk.toLowerCase())return s.epa(v)}return''\");q.getPageName=new Function(\"u\",\"var v\\x3du?u:''+s.wd.location,x\\x3dv.indexOf(':'),y\\x3dv.indexOf('\/',x+4),z\\x3dv.indexOf('?'),c\\x3ds.pathConcatDelim,e\\x3ds.pathExcludeDelim,g\\x3ds.queryVarsList,d\\x3ds.siteID,n\\x3dd?d:'',q\\x3dz\\x3c0?'':v.substring(z+1),p\\x3dv.substring(y+1,q?z:v.length);z\\x3dp.indexOf('#');p\\x3dz\\x3c0?p:s.fl(p,z);x\\x3de?p.indexOf(e):-1;p\\x3dx\\x3c0?p:s.fl(p,x);p+\\x3d!p||p.charAt(p.length-1)\\x3d\\x3d'\/'?s.defaultPage:'';y\\x3dc?c:'\/';while(p){x\\x3dp.indexOf('\/');x\\x3dx\\x3c0?p.length:x;z\\x3ds.fl(p,x);if(!s.pt(s.pathExcludeList,',','p_c',z))n+\\x3dn?y+z:z;p\\x3dp.substring(x+1)}y\\x3dc?c:'?';while(g){x\\x3dg.indexOf(',');x\\x3dx\\x3c0?g.length:x;z\\x3ds.fl(g,x);z\\x3ds.pt(q,'\\x26','p_c',z);if(z){n+\\x3dn?y+z:z;y\\x3dc?c:'\\x26'}g\\x3dg.substring(x+1)}return n\");\nq.crossVisitParticipation=new Function(\"v\",\"cn\",\"ex\",\"ct\",\"dl\",\"ev\",\"var s\\x3dthis;var ay\\x3ds.split(ev,',');for(var u\\x3d0;u\\x3cay.length;u++){if(s.events\\x26\\x26s.events.indexOf(ay[u])!\\x3d-1){cW(cn,'');return '';}}if(!v||v\\x3d\\x3d'')return '';var arry\\x3dnew Array();var a\\x3dnew Array();var c\\x3ds.c_r(cn);var g\\x3d0;var h\\x3dnew Array();if(c\\x26\\x26c!\\x3d'') arry\\x3deval(c);var e\\x3dnew Date();e.setFullYear(e.getFullYear()+5);if(arry.length\\x3e0\\x26\\x26arry[arry.length-1][0]\\x3d\\x3dv)arry[arry.length-1]\\x3d[v, new Date().getTime()];else arry[arry.length]\\x3d[v, new Date().getTime()];var data\\x3ds.join(arry,{delim:',',front:'[',back:']',wrap:'\\\\''});var start\\x3darry.length-ct \\x3c 0?0:arry.length-ct;cW(cn,data,e);for(var x\\x3dstart;x\\x3carry.length;x++){var diff\\x3dMath.round(new Date()-new Date(parseInt(arry[x][1])))\/86400000;if(diff\\x3cex){h[g]\\x3darry[x][0];a[g++]\\x3darry[x];}}var r\\x3ds.join(h,{delim:dl});return r;\");\nq.callType=new Function(\"var s\\x3dthis,U,e\\x3ds.eo,l\\x3ds.linkObject,t\\x3ds.linkType,o\\x3de||l,h\\x3do?o.href||o.download:0,R\\x3dt||(typeof s.lt\\x3d\\x3d'function'\\x26\\x26typeof h\\x3d\\x3d'string'?s.lt(h):'');if(!R\\x26\\x26e\\x3d\\x3d\\x3dU\\x26\\x26t\\x3d\\x3d\\x3dU\\x26\\x26s.linkName\\x3d\\x3d\\x3dU\\x26\\x26l\\x3d\\x3dU\\x26\\x26h\\x3d\\x3d\\x3d0)R\\x3d't';if(!R\\x26\\x26h\\x3d\\x3d\\x3d0\\x26\\x26!(t\\x3d\\x3d\\x3d0))R\\x3d'o';return R||'+'\");q.setEvent=new Function(\"a\",\"x\",\"y\",\"var s\\x3dthis;var S\\x3d'string',N\\x3d'number',e\\x3ds.events,t,u,n,m,k,v,i,j,q,r;if(typeof a!\\x3dS\\x26\\x26typeof a!\\x3dN)return e;if(arguments.length\\x3d\\x3d2\\x26\\x26typeof x\\x3d\\x3dS){y\\x3dx;x\\x3d1}if(arguments.length\\x3c2)x\\x3d1;if(typeof x!\\x3dN||x\\x3c0||x\\x3e1e5)return e;y\\x3dy||'';if(!e||typeof e!\\x3dS||e.toLowerCase()\\x3d\\x3d'none')e\\x3d'';u\\x3d(a+'').split(',');for(k\\x3d0;k\\x3cu.length;k++){n\\x3du[k];m\\x3dNumber(n);if(!isNaN(m))n\\x3dm;if(typeof n\\x3d\\x3dS){i\\x3dn.indexOf(':');if(i\\x3e-1){y\\x3dn.substring(i+1);n\\x3dn.substring(0,i)}i\\x3dn.indexOf('\\x3d');if(i\\x3e-1){x\\x3dn.substring(i+1);n\\x3dn.substring(0,i)}}else{n\\x3dString(n);if(n)n\\x3d'event'+n}if(n){v\\x3dx\\x3e0?n+(x!\\x3d1?'\\x3d'+x:''):'';if(typeof e!\\x3dS||e.toLowerCase\\x3d\\x3d'none')e\\x3d'';if(e){t\\x3de.split(',');e\\x3d'';for(i\\x3d0;i\\x3ct.length;i++){q\\x3dt[i];j\\x3dq.indexOf(':');if(j\\x3e-1){r\\x3dq.substring(j);q\\x3dq.substring(0,j)}else{r\\x3d''}if(y)r\\x3dy;j\\x3dq.indexOf('\\x3d');if(j\\x3e-1)q\\x3dq.substring(0,j);if(q\\x3d\\x3dn){t[i]\\x3dv;if(r)q+\\x3d':'+r;v\\x3d''}if(t[i])e+\\x3d(e?',':'')+t[i]}}}if(v){e\\x3d(e?e+',':'')+v;if(y)e+\\x3d':'+y}x\\x3d1;y\\x3d''}s.events\\x3de;return e;\");\nq.getEvent=new Function(\"n\",\"var s\\x3dthis,e\\x3ds.events||'',S\\x3d'string';if(typeof e!\\x3dS||e.toLowerCase\\x3d\\x3d'none')e\\x3d'';n\\x3dtypeof n\\x3d\\x3dS?n.substring(n.indexOf('.')+1):typeof n\\x3d\\x3d'number'?'event'+n:'';if(!n||!e)return 0;var t\\x3de.split(',');if(t\\x26\\x26(typeof t\\x3d\\x3d'object'||typeof t\\x3d\\x3d'array')\\x26\\x26t.length\\x3e0){for(var i\\x3d0;i\\x3ct.length;i++){var u\\x3dt[i].indexOf(':');if(u\\x3e-1)t[i]\\x3dt[i].substring(0,u);var q\\x3dt[i].indexOf('\\x3d'),m\\x3dq\\x3e-1?t[i].substring(0,q):t[i];if(m\\x3d\\x3dn){if(q\\x3e-1){var v\\x3dt[i].substring(q+1);return v\\x26\\x26!isNaN(v)?parseFloat(v):1}return 1}}}return 0\");\nq.tlAdd=new Function(\"var s\\x3dthis,k,a\\x3darguments,n,q,e;for(k\\x3d0;k\\x3ca.length;k++){n\\x3da[k];n\\x3dn.replace(\/^([^\\x3d:;,]+\\\\.)\/,'');n\\x3dn.replace(\/^v([0-9])$\/,'eVar$1').replace(\/^c([0-9])$\/,'prop$1').replace(\/^e([0-9])\/,'event$1');q\\x3dn.indexOf('\\x3d');if(q\\x3c0)q\\x3dn.indexOf(':');if(q\\x3e\\x3d0)n\\x3dn.substring(0,q);if(!n.indexOf('event')){e\\x3ds.linkTrackEvents;if(e.toLowerCase()\\x3d\\x3d'none')e\\x3d'';e\\x3ds.apl(e,n,',',1);s.linkTrackEvents\\x3de;n\\x3d'events'}e\\x3ds.linkTrackVars;if(e.toLowerCase()\\x3d\\x3d'none')e\\x3d'';e\\x3ds.apl(e,n,',',1);s.linkTrackVars\\x3de}\");\nq.channelManager=new Function(\"a\",\"b\",\"c\",\"d\",\"e\",\"f\",\"g\",\"var s\\x3dthis,h\\x3dnew Date,i\\x3d0,j,k,l,m,n,o,p,q,r,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T;h.setTime(h.getTime()+1800000);if(e){i\\x3d1;if(cR(e))i\\x3d0;if(!cW(e,1,h))cW(e,1,0);if(!cR(e))i\\x3d0;if(f\\x26\\x26cR('s_tbm'+f))i\\x3d0;}j\\x3ds.referrer?s.referrer:document.referrer;j\\x3dunescape(j.toLowerCase());if(!j)k\\x3d1;else {l\\x3dj.indexOf('?')\\x3e-1?j.indexOf('?'):j.length;m\\x3dj.substring(0,l);n\\x3ds.split(j,'\/');n\\x3ds.split(n[2],'?');o\\x3dn[0].toLowerCase();p\\x3ds.linkInternalFilters.toLowerCase();p\\x3ds.split(p,',');for(q\\x3d0;q\\x3cp.length;q++){r\\x3do.indexOf(p[q])\\x3d\\x3d-1?'':j;if(r)break;}}if(!r\\x26\\x26!k){t\\x3dj;u\\x3dv\\x3do;w\\x3d'Other Natural Referrers';x\\x3ds.seList+'\\x3e'+s._extraSearchEngines;if(d\\x3d\\x3d1){m\\x3ds.repl(m,'oogle','%');m\\x3ds.repl(m,'ahoo','^');j\\x3ds.repl(j,'as_q','*');}y\\x3ds.split(x,'\\x3e');for(z\\x3d0;z\\x3cy.length;z++){A\\x3dy[z];A\\x3ds.split(A,'|');B\\x3ds.split(A[0],',');for(C\\x3d0;C\\x3cB.length;C++){D\\x3dm.indexOf(B[C]);if(D\\x3e-1){if(A[2])E\\x3dv\\x3dA[2];else E\\x3do;if(d\\x3d\\x3d1){E\\x3ds.repl(E,'#',' - ');j\\x3ds.repl(j,'*','as_q');E\\x3ds.repl(E,'^','ahoo');E\\x3ds.repl(E,'%','oogle');}F\\x3ds.split(A[1],',');for(G\\x3d0;G\\x3cF.length;G++){if(j.indexOf(F[G]+'\\x3d')\\x3e-1||j.indexOf('https:\/\/www.google.')\\x3d\\x3d0||j.indexOf('http:\/\/r.search.yahoo.com')\\x3d\\x3d0)H\\x3d1;I\\x3ds.getQueryParam(F[G],'',j).toLowerCase();if(H||I)break;}}if(H||I)break;}if(H||I)break;}}if(!r||g!\\x3d'1'){J\\x3ds.split(a,',');K\\x3d0;while(!T\\x26\\x26K\\x3cJ.length){T\\x3ds.getQueryParam(J[K],b);K++;}if(T){v\\x3dT;if(E)w\\x3d'Paid Search';else w\\x3d'Unknown Paid Channel';}if(!T\\x26\\x26E\\x26\\x26H){v\\x3dE;w\\x3d'Natural Search';}}if(i\\x26\\x26k\\x26\\x26!T)t\\x3du\\x3dv\\x3dw\\x3d'Typed\/Bookmarked';J\\x3ds._channelDomain;if(J\\x26\\x26o\\x26\\x26!r){K\\x3ds.split(J,'\\x3e');for(L\\x3d0;L\\x3cK.length;L++){M\\x3ds.split(K[L],'|');N\\x3ds.split(M[1],',');O\\x3dN.length;for(P\\x3d0;P\\x3cO;P++){Q\\x3dN[P].toLowerCase();R\\x3do.indexOf(Q);if(R\\x3e-1){w\\x3dM[0];break;}}if(R\\x3e-1)break;}}J\\x3ds._channelParameter;if(J){K\\x3ds.split(J,'\\x3e');for(L\\x3d0;L\\x3cK.length;L++){M\\x3ds.split(K[L],'|');N\\x3ds.split(M[1],',');O\\x3dN.length;for(P\\x3d0;P\\x3cO;P++){R\\x3ds.getQueryParam(N[P]);if(R){w\\x3dM[0];break;}}if(R)break;}}J\\x3ds._channelPattern;if(J){K\\x3ds.split(J,'\\x3e');for(L\\x3d0;L\\x3cK.length;L++){M\\x3ds.split(K[L],'|');N\\x3ds.split(M[1],',');O\\x3dN.length;for(P\\x3d0;P\\x3cO;P++){Q\\x3dN[P].toLowerCase();R\\x3dT.toLowerCase();S\\x3dR.indexOf(Q);if(S\\x3d\\x3d0){w\\x3dM[0];break;}}if(S\\x3d\\x3d0)break;}}S\\x3dw?T+u+w+I:'';c\\x3dc?c:'c_m';if(c!\\x3d'0')S\\x3ds.getValOnce(S,c,0);if(S){s._campaignID\\x3dT?T:'n\/a';s._referrer\\x3dt?t:'n\/a';s._referringDomain\\x3du?u:'n\/a';s._campaign\\x3dv?v:'n\/a';s._channel\\x3dw?w:'n\/a';s._partner\\x3dE?E:'n\/a';s._keywords\\x3dH?I?I:'Keyword Unavailable':'n\/a';if(f\\x26\\x26w!\\x3d'Typed\/Bookmarked'){h.setTime(h.getTime()+f*86400000);cW('s_tbm'+f,1,h);}}else s._campaignID\\x3ds._referrer\\x3ds._referringDomain\\x3ds._campaign\\x3ds._channel\\x3ds._partner\\x3ds._keywords\\x3d'';\");\nq.seList=\"google.,googlesyndication.com,.googleadservices.com|q,as_q|Google\\x3ebing.com|q|Bing\\x3eyahoo.com,yahoo.co.jp|p,va|Yahoo!\\x3eask.jp,ask.co|q,ask|Ask\\x3e.aol.,suche.aolsvc.de|q,query|AOL\\x3ealtavista.co,altavista.de|q,r|AltaVista\\x3e.mywebsearch.com|searchfor|MyWebSearch\\x3ewebcrawler.com|q|WebCrawler\\x3ewow.com|q|Wow\\x3einfospace.com|q|InfoSpace\\x3eblekko.com|q|Blekko\\x3edogpile.com|q|DogPile\\x3ealhea.com|q|Alhea\\x3egoduckgo.com|q|GoDuckGo\\x3einfo.com|qkw|Info.com\\x3econtenko.com|q|Contenko\\x3ewww.baidu.com|wd|Baidu\\x3edaum.net,search.daum.net|q|Daum\\x3eicqit.com|q|icq\\x3emyway.com|searchfor|MyWay.com\\x3enaver.com,search.naver.com|query|Naver\\x3enetscape.com|query,search|Netscape Search\\x3ereference.com|q|Reference.com\\x3eseznam|w|Seznam.cz\\x3eabcsok.no|q|Startsiden\\x3etiscali.it,www.tiscali.co.uk|key,query|Tiscali\\x3evirgilio.it|qs|Virgilio\\x3eyandex|text|Yandex.ru\\x3eoptimum.net|q|Optimum Search\";\nq._channelDomain=\"Social Networks|facebook.com,linkedin.com,\/t.co,twitter.com,orkut.com,friendster.com,livejournal.com,blogspot.com,wordpress.com,friendfeed.com,myspace.com,digg.com,reddit.comstumbleupon.com,twine.com,yelp.com,mixx.com,delicious.com,tumblr.com,disqus.com,intensedebate.com,plurk.com,slideshare.net,backtype.com,netvibes.com,mister-wong.com,diigo.com,flixster.com,youtube.com,vimeo.com,12seconds.tv,zooomr.com,identi.ca,jaiku.com,flickr.com,imeem.com,dailymotion.com,photobucket.com,fotolog.com,smugmug.com,classmates.com,myyearbook.com,mylife.com,tagged.com,brightkite.com,ning.com,bebo.com,hi5.com,yuku.com,cafemom.com,xanga.com,plus.google.com,pinterest.com,wanelo.com\\x3e\";\nreturn{s:q,s_gi:O,AppMeasurement:P}}());\u003C\/script\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":57
    },{
      "function":"__html",
      "once_per_load":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003Ewindow._UDL\u0026\u0026\"object\"==typeof window._UDL\u0026\u0026window._UDL.constructor!=Array||(window._UDL=function(){var T=document,O=T.location,U=T.referrer,y=window,k=\"unknown\",r=!0,n=!1,Y=\"18.10.03a\",ma=n,H=n,ka=\"dataLayer\",K=\"_UDL\",C=K+\" ERROR\",ha=K+\" WARNING\",ia=0,ea=n;try{if(ma=!!y.Bootstrapper){var Z=_A.gP(\"Bootstrapper.ensightenOptions.publishPath\");H=\"hpcom_prod\"==Z||\"etr_std_prod\"==Z}}catch(b){}console.log(K,Y,H?\"(Compatiblity Mode)\":\"\");var na=function(){var b=\"\";try{b=y.ga.getAll()[0].get(\"clientId\")||\n\"\"}catch(qa){b=\"\"}return b||_A.cR(\"_ga\").replace(\/GA[^.]*\/,\"\").replace(\/^\\.[0-9]\\.*\/,\"\")},P=function(){try{var b,k=arguments,e=\"\",l=0,m=n,h=n,f=\"hphqunknown\",c=\"hphqglobaldev\",d=H?y.s:_A.isO(y._AA)?y._AA.s:0,v=C+\" in adobeInitIfNeeded: Adobe\",w=function(b){_A.isO(y.bcgs_adobe_config)||(y.bcgs_adobe_config={APP_MEASUREMENT:{RSID:\"hphqunknown\",TRACKING_SERVER:\"met1.hp.com\"},HEARTBEAT:{DISABLE:r,TRACKING_SERVER:\"met1.hp.com\",JOB_ID:\"sc_va\",PUBLISHER:\"\",OVP:\"Brightcove\",SDK:\"1.5.2\",DEBUG_LOGGING:n},QUALITY:{TIME_TO_START:0},\nCUSTOM_EVENT:{disable:n,bc_data_mapping:{name:\"eVar70\",segment:\"eVar71\",contentType:\"eVar72\",timePlayed:\"event99\",view:\"event100\",segmentView:\"event97\",complete:\"event98\"}}});y.bcgs_adobe_config.APP_MEASUREMENT.RSID=b||\"hphqunknown\"};for(b=0;b\u003Ck.length;b++)_A.isS(k[b])\u0026\u0026(e=k[b]),_A.isO(k[b])\u0026\u0026(l=k[b]);l\u0026\u0026_A.isS(l.environment)\u0026\u0026\"dev\"==_A.LC(l.environment)\u0026\u0026(m=r);!e\u0026\u0026_A.isO(_A.section)\u0026\u0026(_A.section.dev\u0026\u0026(m=r),e=m\u0026\u0026_A.section.rsidDev?_A.section.rsidDev:!m\u0026\u0026_A.section.rsid?_A.section.rsid:\"\");e||(e=m?\nc:f);_A.isO(d)\u0026\u0026_A.isF(d.t)?e!=d.account?(h=r,d.sa(e),fa(),w(e),console.log(K,\"RSIDs change:\",e)):h=r:(_A.isF(H?y.s_gi:y._AA.s_gi)?(d=H?y.s=y.s_gi(e):y._AA.s=y._AA.s_gi(e),_A.isO(d)\u0026\u0026_A.isF(d.t)?(d.visitorNamespace=\"hpcorp\",d.trackingServer=\"met1.hp.com\",d.trackingServerSecure=\"met2.hp.com\",d.dc=\"112\",d.vmk=\"4A466CB3\",d.currencyCode=\"USD\",d.charSet=(ifA?_A.getCharSet():\"\")||\"UTF-8\",d.trackDownloadLinks=r,d.trackExternalLinks=r,d.trackInlineStats=r,d.linkInternalFilters=\"hp.com,hpconnected.com,hpsalescentral.com,compaq.com,hpcontent.com,hp-mpp.com,hpautodelivery.com,hpdirect.com.hk,hpshopping.co.nz,hpshopping.id,hpshopping.in,hpstore.cn,hpstorethailand.com,hponline.cl,hponline.com.ar,hponline.com.co,hponline.com.mx,hponlinestore.com.pe,lojahp.com.br\",\nd.linkDownloadFileTypes=\"7z,adpp,air,app,avi,bin,cnf,cptx,dmg,doc,docx,ds_tore,exe,flv,gif,gz,hqx,icns,iso,jar,jpeg,jpg,kext,mov,mp3,mpeg,mpg,msi,mxp,otf,pdf,pfx,plist,png,ppt,pptx,scpt,snd,swp,tgz,thm,tiff,ttf,vcf,wav,wmv,xls,xlsx,xml,zip,zxp\",d.linkLeaveQueryString=n,d.linkTrackVars=\"\",d.linkTrackEvents=\"None\",d.usePlugins=r,d.ActionDepthTest=r,fa(),d.loadModule(\"Media\"),d.Media.trackUsingContextData=r,d.Media.autoTrack=n,d.Media.trackMilestones=\"25,50,75\",d.Media.segmentByMilestones=r,d.Media.completeByCloseOffset=\nr,d.Media.completeCloseOffsetThreshold=0,d.Media.contextDataMapping={\"a.media.name\":\"eVar70\",\"a.media.segment\":\"eVar71\",\"a.contentType\":\"eVar72\",\"a.media.segmentView\":\"event97\",\"a.media.complete\":\"event98\",\"a.media.timePlayed\":\"event99\",\"a.media.view\":\"event100\"},d.Media.trackVars=\"events,eVar70,eVar71,eVar72\",d.Media.trackEvents=\"event97,event98,event99,event100\",w(e),h=r,console.log(K,\"Adobe Analytics intialized, RSIDs:\",e)):console.log(v,\"s object creation failure\")):console.log(v,\"function s_gi not defined\"),\np(K,\"adobeInitIfNeeded() s object created, RSIDs:\",e))}catch(I){h=n,console.log(C,\"in adobeInitIfNeeded\",I)}return h?d:0},fa=function(){var b=P();_A.isO(b)\u0026\u0026(b.products=b.events=\"\",b.linkTrackVars=b.linkTrackEvents=\"none\",b.eVar25=b.eVar26=b.eVar27=\"\")},B=function(b,k){try{var e=P();_A.isO(e)\u0026\u0026_A.isF(e.tl)?(p(K,'calling s.tl( T , \"o\"',b,\" )\"),e.tl(r,\"o\",b||\"unspecified\"),fa()):console.log(C,\"in adobeTL s.tl not defined\")}catch(l){console.log(C,\"in adobeTL ltName:\",b,l)}},oa=function(b,k){var e=P(),\nl=e.products,m=l.split(\",\"),h=m[m.length-1],f=h.split(\";\").length-1;if(l){for(;5\u003Ef;f++)h+=\";\";for(f=h.length-1;4\u003Cf\u0026\u0026\";\"!=h[f];)f--;f\u003Ch.length-1\u0026\u0026(h+=\"|\");m[m.length-1]=h+\"eVar\"+b+\"\\x3d\"+k;e.products=m.join(\",\")}return!l},pa=function(b,k,e,l){var m,h=new Function(\"x\",\"src\",\"return eval(x)\");if(_A.isO(b)\u0026\u0026_A.isO(k)\u0026\u0026_A.isO(e))for(m in _A.isO(l),k){l=m.split(\",\");var f=k[m];try{var c=this.z;c=_A.isF(f)?f(b):_A.isS(f)?\".\"==f[0]?b[f.substring(1)]:\"\\x3d\"==f[0]?h(f.substring(1),b):f:f}catch(v){console.log(C,\n\"in mapProperties mapping\",f,\"to\",m,v)}if(!_A.isU(c))for(f=0;f\u003Cl.length;f++){var d=l[f];\"LTV\"==d?_A.addLTV(c):\"event\"==d.substring(0,5)\u0026\u0026(_A.isN(c)||c)?e.events=_A.addCS(e.events,\"\\x3d\"==d[d.length-1]?c?d+c:d:d,1):e[d]=c}}else console.log(C,\"in mapProperties: invalid argument(s)\")},w=function(b){return _A.LC(_A.getHTMLtag(\"meta\",\"name\",b,\"content\"))},z=function(b,p){try{var e=P(b),l,m,h=C+\" in adobeSetCommonVars\",f,c=\"h_inavclk\",d=n,v=U?_A.getSiteSection(U):0,z=function(){var a=T.cookie||\"\";try{if(-1\u003C\na.indexOf(\"WRUID\")\u0026\u0026(-1\u003Ca.indexOf(\"_CT_RS_\\x3d1\")||-1==a.indexOf(\"WRIgnore\\x3dtrue\")\u0026\u0026-1\u003C !a.indexOf(\"_CT_RS_\\x3d1\"))){var b=a.split(\";\"),c=0,d=0,e,f=\"\";for(e=0;e\u003Cb.length;e++){for(a=b[e];\" \"==a.charAt(0);)a=a.substring(1,a.length);-1\u003Ca.indexOf(\"CT_Data\")\u0026\u0026(c=a.substring(a.indexOf(\"apv_\")).split(\"_\")[1]);-1\u003Ca.indexOf(\"WRUID\")\u0026\u0026(d=a.split(\"\\x3d\")[1])}f=0==d||0==c?\"\":d+\".\"+c}}catch(ra){console.log(h,\"getCTid\")}return f},I=function(){var a=window._bluekai_guid||_A.cR(\"bkguid\")||\"\";return a?\"bkguid:\"+\na:a};z={currencyCode:\".currency\",server:\".hostname\",hier1:\".pageName\",hier2:\".regCCsite\",channel:\".pageNameUpToPageCat\",pageName:\".pageName\",campaign:\".aoid\",event4:r,event69:d,event80:\".jidExt\",eVar1:\".cclc\",eVar5:\".regCCsite\",eVar6:\".searchKeywords\",eVar8:\".adobeID\",eVar9:\".userTypeSession\",eVar10:\".recipientId\",eVar13:\".homeInavClick\",eVar14:\".utmCodes\",eVar15:\".jidEnoS\",eVar16:\".jidL\",eVar17:\".jidE\",eVar18:\".jidB\",eVar19:\".jidO\",eVar20:\".demandBase1\",eVar21:\".demandBase2\",eVar29:\".demandBase3\",\neVar23:\".pageNameUpToPageCat\",eVar25:\".ABtest1\",eVar26:\".ABtest2\",eVar27:\".ABtest3\",eVar30:\".prodServiceName\",eVar36:\".searchTerm\",eVar37:\".numSearchResults\",eVar43:\".coupon\",eVar46:\".aSecTemplate\",eVar55:\".pageName\",eVar67:\".PNnoLocale\",eVar68:\".inavClick\",eVar69:\".prevPN\",eVar74:\".addToCartMethod\",eVar75:\".v151\",eVar76:\".v152\",eVar77:\".v153\",eVar78:\".v154\",eVar79:\".v155\",eVar82:z,eVar85:\".companyID\",eVar86:\".dnb1\",eVar87:\".dnb2\",eVar88:\".v156\",eVar90:\".url\",eVar91:\".referrer\",eVar92:\".codeStamp\",\neVar93:\".urlNoQ\",eVar94:\".hostname\",eVar95:\".diagSection\",eVar96:\".sitePlatform\",prop1:\".callCenter\",prop5:\".userTypeSession\",prop7:\".cc\",prop8:\".locale\",prop9:\".pageSegment\",prop10:\".pageLifecycle\",prop11:\".aSecTemplate\",prop12:\".pageSectionID\",prop13:\".rsid\",prop14:\".loginStatus\",prop16:\".pageBU\",prop26:\".pageName\",prop28:\".pageContent\",prop29:\".customerSegment\",prop34:\".prodServiceName\",prop46:\".aSecTemplate\",prop49:\".urlNoQ\",prop50:\".mktUrl\",prop51:\".pageDesignAndInav\",prop59:\".simpleTitle\",prop64:\".demandBase1\",\nprop65:\".demandBase2\",prop68:\".inavClick\",prop69:\".demandBase3\",prop71:I,prop73:\".prevPN\",prop75:\".region\",LTV:\"prop1,eVar1,prop2,eVar2,prop3,eVar3,prop4,eVar4,prop5,eVar5,prop6,eVar6,prop7,eVar7,prop8,eVar8,eVar9,prop9,eVar10,prop10,prop13,eVar14,prop14,eVar15,prop15,prop16,prop17,eVar17,eVar20,eVar21,eVar29,eVar25,eVar26,eVar27,eVar29,eVar36,eVar37,prop64,prop65,prop69,eVar74,eVar75,eVar76,eVar77,eVar78,eVar79,eVar86,eVar87,eVar88,eVar90,eVar91,eVar92,eVar93,eVar94,eVar95,eVar96\"};if(_A.isO(e)){var a=\n{};_A.isO(_A.section)||(_A.section={});try{a.cc=_A.LC(_A.section.country)||\"us\",a.region=_A.LC(_A.section.region)||\"ams\",a.lc=_A.LC(_A.section.language)||\"en\",a.cclc=a.cc+\":\"+a.lc,a.locale=a.lc+\"-\"+a.cc,a.currency=_A.UC(_A.section.currency)||\"USD\"}catch(g){console.log(h,\"setting Adobe locale variables\",g)}try{a.siteType=_A.LC(_A.section.type)||k;a.siteSubtype=_A.LC(_A.section.subtype)||k;a.pageType=_A.scrubAndEsc(_A.LC(b.pageNameL5||b.pageType)||k);a.pageCategory=_A.scrubAndEsc(_A.LC(b.pageNameL6||\nb.pageCategory||\"\"));a.pageSubcategory=_A.scrubAndEsc(_A.LC(b.pageNameL7||b.pageSubcategory||\"\"));a.pageSubcategoryDetail=_A.scrubAndEsc(_A.LC(b.pageNameL8||b.pageSubcategoryDetail)||\"\");var E=a.cc+\":\"+a.lc+\":\"+a.siteType;a.siteSubtype\u0026\u0026(E+=\":\"+a.siteSubtype);if(a.pageType==k)E+=\":\/\"+O.href.replace(\/^http.?:\\\/\\\/\/,\"\").replace(\/\\?.*\/,\"\"),a.pageNameUpToPageCat=E;else{var B=a.pageSubcategoryDetail?8:a.pageSubcategory?7:a.pageCategory?6:5;E+=\":\"+a.pageType;a.pageNameUpToPageCat=E;5\u003CB\u0026\u0026(E+=\":\"+a.pageCategory);\n6\u003CB\u0026\u0026(E+=\":\"+a.pageSubcategory);7\u003CB\u0026\u0026(E+=\":\"+a.pageSubcategoryDetail)}a.pageName=E;a.PNnoLocale=E.replace(\/[^:]*:[^:]*:\/,\"\");a.regCCsite=a.region+\":\"+a.cc+\":\"+a.siteType+\":\"+(w(\"segment\")||a.siteSubtype);a.companyID=b.companyID||\"\"}catch(g){console.log(h,\"setting Adobe page name variables\",g)}try{a.url=O.href,a.mktUrl=(\"Tridion\"==_A.section.platform?\"cs:\":\"\")+a.url,a.hostname=_A.LC(O.hostname),a.urlNoQ=O.origin+O.pathname,a.referrer=U}catch(g){console.log(h,\"setting Adobe URL variables\",g)}try{a.metaPageType=\nw(\"page_type\"),a.pageSegment=w(\"segment\"),a.pageLifecycle=w(\"lifecycle\"),a.pageBU=w(\"bu\"),a.pageSectionID=w(\"web_section_id\"),a.pageContent=w(\"page_content\"),a.pageDesignVer=w(\"hp_design_version\"),a.pageInavVer=w(\"hp_inav_version\")||\"hflegacy\",a.pageDesignAndInav=(a.pageDesignVer||k)+\":\"+(a.pageInavVer||k),a.aSec=w(\"analytics_section\"),a.aTemplate=w(\"analytics_template_name\"),a.aSecTemplate=a.aSec,a.aSecTemplate+=a.aTemplate?\":\"+a.aTemplate:\"\",a.prodServiceName=w(\"product_service_name\"),a.simpleTitle=\nw(\"simple_title\"),a.simpleTitle=(a.simpleTitle\u0026\u0026\"Tridion\"==_A.section.platform?\"cs:\":\"\")+a.simpleTitle}catch(g){console.log(h,\"setting Adobe page attribute variables\",g)}if(p){try{if(d=(m=unescape(_A.cR(c)))\u0026\u0026\"-\"!=m)a.inavClick=m,0\u003C=m.indexOf(\"home:\")\u0026\u0026(a.homeInavClick=cc+\":\"+lc+\":\"+m.replace(\"home:\",\"\"));else if(d=(m=unescape(_A.cR(\"h_cm\")||_A.cR(\"h_cm2\")))\u0026\u0026\"-\"!=m)a.homeInavClick=m;_A.cW(c,\"\",0,\".hp.com\");_A.cW(c,\"\");_A.cW(\"h_cm\",\"\",0,\".hp.com\");_A.cW(\"h_cm\",\"\");_A.cW(\"h_cm2\",\"\",0,\".hp.com\");_A.cW(\"h_cm2\",\n\"\")}catch(g){console.log(h,\"setting Adobe INAV cookies\",g)}try{a.prevPN=_A.isF(e.getPreviousValue)?e.getPreviousValue(E,\"s_prevPage\"):_A.getPrevious(\"s_prevPage\",E)}catch(g){console.log(h,\"setting previous page name variable\",g)}}try{-1\u003Ce.events.indexOf(\"scAdd\")\u0026\u0026(a.addToCartMethod=b.pageNameL5||\"\/\"+O.href.replace(\/^http.?:\\\/\\\/\/,\"\").replace(\/\\?.*\/,\"\"),oa(74,a.addToCartMethod))}catch(g){console.log(h,\"setting Adobe add to cart\",g)}try{if(b.test1name||b.test1variation)a.ABtest1=(b.test1name||k)+\":\"+\n(b.test1variation||k);if(b.test2name||b.test2variation)a.ABtest2=(b.test2name||k)+\":\"+(b.test2variation||k);if(b.test3name||b.test3variation)a.ABtest3=(b.test3name||k)+\":\"+(b.test3variation||k)}catch(g){console.log(h,\"setting Adobe A\/B testing variables\",g)}try{b.demandBase1\u0026\u0026(a.demandBase1=b.demandBase1),b.demandBase2\u0026\u0026(a.demandBase2=b.demandBase2),b.demandBase3\u0026\u0026(a.demandBase3=b.demandBase3),b.dnb1\u0026\u0026(a.dnb1=b.dnb1),b.dnb2\u0026\u0026(a.dnb2=b.dnb2)}catch(g){console.log(h,\"setting Adobe Demandbase and DnB variables\",\ng)}try{a.googleID=na(),a.adobeID=e.visitorID||(_A.cR(\"s_vi\")||\"\").replace(\/\\[[^\\[]*\\]\/g,\"\").replace(\/[^\\|]*\\|\/,\"\")||_A.cR(\"AMCV_\")||e.mid||_A.cR(\"s_fid\")||e.fid||k,a.loginStatus=(b.loginStatus?\"\":\"not \")+\"logged in\",a.userDevice=_A.getDeviceInfo().deviceType||\"desktop\",a.userTypeSession=b.userTypeSession||k,a.customerSegment=b.customerSegment||\"\",a.callCenter=b.callCenter||\"\"}catch(g){console.log(h,\"setting Adobe user attribute variables\",g)}try{if(l=(_A.parseParam(\"jumpid\")||\"\").toLowerCase()||\"\"){switch(l.substring(0,\n3)){case \"cp_\":case \"re_\":a.jidB=l;break;case \"in_\":a.jidL=l;break;case \"af_\":case \"ba_\":case \"cs_\":case \"em_\":case \"ex_\":case \"mb_\":case \"ps_\":case \"sc_\":case \"sc_\":case \"va_\":a.jidE=l;a.jidEnoS=l.substring(0,-1\u003Cl.indexOf(\"\/\")?l.indexOf(\"\/\"):l.length);break;default:a.jidO=l}v\u0026\u0026(\"NONE\"==v.match||_A.section.nonHP)\u0026\u0026(a.jidExt=r)}}catch(g){console.log(h,\"setting Adobe Jump ID variables\",g)}try{a.utmCodes=(_A.parseParam(\"utm_content\")||\"\")+\":\"+(_A.parseParam(\"utm_medium\")||\"\")+\":\"+(_A.parseParam(\"utm_source\")||\n\"\")+\":\"+(_A.parseParam(\"utm_campaign\")||\"\")+\":\"+(_A.parseParam(\"utm_term\")||\"\"),5\u003Ea.utmCodes.length\u0026\u0026(a.utmCodes=\"\"),a.aoid=b.AOID||_A.parseParam(\"aoid\")||\"\",a.recipientId=_A.parseParam(\"rid\")||\"\"}catch(g){console.log(h,\"setting Adobe campaign variables\",g)}try{a.searchTerm=b.searchTerm,a.numSearchResults=b.numSearchResults}catch(g){console.log(h,\"setting search variables\",g)}try{_A.isO(b.ecommerce)\u0026\u0026_A.isO(b.ecommerce.purchase)\u0026\u0026_A.isO(b.ecommerce.purchase.actionField)\u0026\u0026(a.coupon=b.ecommerce.purchase.actionField.coupon)}catch(g){console.log(h,\n\"setting commerce-related variables\",g)}try{for(f=151;200\u003E=f;f++)m=\"v\"+f,b[m]\u0026\u0026(a[m]=b[m])}catch(g){console.log(h,\"setting Adobe regional variables\",g)}try{a.rsid=e.account||y.s_account||k,a.codeStamp=\"gtm|GTM-MZXB4R4|\"+(",["escape",["macro",58],8,16],"||\"\"),_A.isO(y._A.section)?(a.sitePlatform=_A.section.platform,a.diagSection=_A.section.type||\"?\",a.diagSection+=\":\"+(_A.section.subtype||\"?\"),_A.section.dev\u0026\u0026(a.diagSection+=\":dev\"),a.diagSection+=\"|\"+(_A.section.platform||\"?\"),a.diagSection+=\"|\"+(_A.section.region||\n\"?\"),a.diagSection+=\"|\"+(_A.section.country||\"?\"),a.diagSection+=\":\"+(_A.section.language||\"?\"),a.diagSection+=\"|\"+(_A.section.currency||\"?\")):a.sitePlatform=a.diagSection=\"?\"}catch(g){console.log(h,\"setting Adobe diagnostic variables\",g)}try{pa(a,z,e)}catch(g){console.log(h,\"calling mapProperties(\",a,\",\",z,\",\",e,\")\",g)}}}catch(g){console.log(h,g)}};Y=function(b,w,e,l){w=P(c);var m={},h={name:\"eVar52\",category:\"eVar53\"};if(_A.isA(b))for(;ia\u003Cb.length;)try{var f=ia;ia++;var c=JSON.parse(JSON.stringify(b[f]));\nif(_A.isO(c)\u0026\u0026_A.isS(c.event)\u0026\u00260\u003Ec.event.indexOf(\"gtm.\")){var d=_A.isS(c.event)?c.event:\"-\";if(\"e_pageView\"!=d)for(e=f;0\u003C=e;e--)if(\"e_pageView\"==b[e].event){var v=\"pageBusinessUnit loginStatus userTypeSession pageNameL5 pageNameL6 pageNameL7 pageNameL8\".split(\" \");for(l=0;l\u003Cv.length;l++)b[e][v[l]]\u0026\u0026(c[v[l]]=b[e][v[l]]);break}0\u003Ed.indexOf(\"gtm.\")\u0026\u0026p(K,_A.varsToStr(\"-l\",\"dataLayer[\"+f+\"]\\x3d\",b[f]));var H=v=void 0,I=void 0,a=void 0,E=void 0,O=void 0,g=void 0,L=void 0,D=void 0,Q=void 0,R=void 0,V=void 0,\nT=void 0,q=void 0,F=void 0,W=void 0,M=void 0,N=void 0,X=void 0,J=void 0,G=void 0,aa=void 0,ba=c,ca=m,da=h;try{var x=K+\" processEcommerce\",A=_A.isO(ba)\u0026\u0026_A.isO(ba.ecommerce)?ba.ecommerce:0,u=P(ba),U=\"add remove checkout detail productDetail purchase\".split(\" \"),Y=\"scAdd scRemove scCheckout prodView prodView purchase\".split(\" \"),Z=n,la=n;if(A){p(x,\"ecommerce object:\",A);u?u.currencyCode=(_A.isS(A.currencyCode)?A.currencyCode:\"\")||(_A.isO(_A.section)?_A.section.currency:\"\")||u.currencyCode||\"USD\":console.log(C,\n\"in processEcommerce: Adobe s object undefined\");p(x,\"currency:\",u.currencyCode);try{for(X=N=\"\",aa=[],I=M=0;I\u003CU.length;I++)J=U[I],_A.isO(A[J])\u0026\u0026_A.isA(A[J].products)\u0026\u00260\u003CA[J].products.length\u0026\u0026(aa=A[J].products,X=J,N=Y[I],\"purchase\"==N\u0026\u0026_A.isO(A[J].actionField)\u0026\u0026(M=A[J].actionField.id,_A.isS(M)||_A.isN(M)||(M=0)),p(x,\"getEcommObj found eCommerce event\",\"gEvent:\",X,\"sEvent:\",N,\"purchaseID:\",M,\"products:\",aa))}catch(S){console.log(C,\"in getEcommObj i:\",I,\"event:\",J,S)}I=X;J=\"cartItems\";v=H=_A.toNum(_A.lG(J))||\n0;switch(I){case \"add\":v++;break;case \"remove\":v=0\u003CH?H-1:0;break;case \"purchase\":v=0}_A.lS(J,v);la=0==H\u0026\u00260\u003Cv;if(a=X){p(x,\"found commerce event gEvent:\",X,\"sEvent:\",N);M\u0026\u0026u\u0026\u0026(u.transactionID=u.purchaseID=M,p(x,\"purchase ID:\",M));for(W=0;W\u003Caa.length;W++){G=aa[W];p(x,\"product[\",W,\"]:\",G);V=R=\"\";if(_A.isO(ca))for(F in ca)G[F]\u0026\u0026_A.isS(G[F])\u0026\u0026ca[F]\u0026\u0026_A.isS(ca[F])\u0026\u0026(V+=(V?\"|\":\"\")+ca[F]+\"\\x3d\"+_A.scrubAndEsc(G[F],\",;|\"));V\u0026\u0026p(x,\"|     sInc:\",V);if(_A.isO(da))for(F in R=\"\",da)G[F]\u0026\u0026_A.isS(G[F])\u0026\u0026da[F]\u0026\u0026_A.isS(da[F])\u0026\u0026\n(R+=(R?\"|\":\"\")+da[F]+\"\\x3d\"+_A.scrubAndEsc(G[F],\",;|\"));R\u0026\u0026p(x,\"|   sMerch:\",R);Q=G.sku||G.id||\"\";Q=_A.isS(Q)?Q:\"\";D=G.quantity||G.qty||0;D=_A.roundNum(_A.isN(_A.toNum(D))?_A.toNum(D):_A.isN(_A.toFloat(D))?_A.toFloat(D):0);D=0\u003CD?D:0;q=G.price;if(_A.isS(q)){for(q=q.replace(\/ \/g,\"\");1\u003Cq.length\u0026\u0026\".\"!=q[0]\u0026\u0026\",\"!=q[0]\u0026\u0026(\"0\"\u003Eq[0]||\"9\"\u003Cq[0]);)q=q.substring(1);-1\u003Cq.indexOf(\",\")\u0026\u0026-1\u003Cq.indexOf(\".\")\u0026\u0026(q=q.replace(\/,\/g,\"\"));T=(q.match(\/,\/g)||[]).length;1==T\u0026\u0026q.indexOf(\",\")==q.length-3\u0026\u0026(q=q.replace(\/,\/,\".\"));\nq=q.replace(\/,\/g,\"\")}L=_A.toFloat(q);L=_A.isN(L)\u0026\u00260\u003CL?D*L:0;p(x,\"|      sku:\",Q);p(x,\"| quantity:\",D);p(x,\"|    price:\",L);if(Q){if(Z=r,la\u0026\u0026(u\u0026\u0026(u.events=_A.addCS(u.events,\"scOpen\",1),ea\u0026\u0026_A.addLTV(\"scOpen\")),p(x,\"| new cart: Y\")),g=\";\"+Q+\";\"+(D\u0026\u0026L?D:\"\")+\";\"+(D\u0026\u0026L?_A.roundNum(L,4):\"\")+\";\"+V+\";\"+R,p(x,\"\\x3e    sProd:\",g),u\u0026\u0026(u.events=_A.addCS(u.events,N,1),u.products=(u.products?u.products+\",\":\"\")+g,ea\u0026\u0026_A.addLTV(\"products\",N),\"scAdd\"==N||\"prodView\"==N))u.events=_A.addCS(u.events,\"event1\",1),ea\u0026\u0026_A.addLTV(\"event1\")}else console.log(ha,\n\"in processEcommerce: product sku not defined, product[\",W,\"]:\",G)}p(x,\"s.products:\",u.products);p(x,\"s.events:\",u.events)}(O=_A.isA(A.impressions)\u0026\u00260\u003CA.impressions.length?A.impressions:0)\u0026\u0026p(x,\"found impressions (ignoring)\");(E=_A.isO(A)\u0026\u0026_A.isA(A.promoView)\u0026\u00260\u003CA.promoView.length?A.promoView:0)\u0026\u0026p(x,\"found promo view (ignoring)\")}}catch(S){console.log(C,\"in processEcommerce:\",ka,\"element\",ba,S)}p(x,\"returning\",Z);switch(d){case \"e_pageView\":z(c,r);try{var ja=P(c);_A.isO(ja)\u0026\u0026_A.isF(ja.t)?(ja.t(),\nfa(),ea=r,y.adobeStCalled=r):console.log(C,\"in adobeT s.t not defined\")}catch(S){console.log(C,\"in adobeT\",S)}break;case \"e_ABtest\":z(c,n);var t=\"abtest:\"+(c.test1name||c.test2name||c.test3name||k+\"test\")+\":\"+(c.test1variation||c.test2variation||c.test3variation||k+\"var\");B(t);break;case \"e_addToCart\":z(c,n);t=\"addToCart\";B(t);break;case \"e_facet\":z(c,n);t=(\"false\"==c.filterChecked?\"facet.deselect\":\"facet.select\")+\":\"+c.filterCategories+\":\"+c.filterValue;w.prop55=t;_A.addLTV(\"prop55\");B(t);break;\ncase \"e_dnb\":z(c,n);t=\"dnb\";B(t);break;case \"e_demandBase\":z(c,n);t=\"demandBase\";B(t);break;case \"i_nav\":break;case \"e_internal\":z(c,n);t=\"internal:\"+(c.action||k)+\":\"+(c.label||k);B(t);break;case \"e_linkClick\":z(c,n);t=\"linkClick:\"+(c.linkPlacement||k)+(c.linkID?\":\"+c.linkID:\"\");B(t);break;case \"e_prodDetailsTab\":z(c,n);t=\"prodDetailsTab:\"+(c.detailsTabName||k)+(c.productName?\":\"+c.productName:\"\");B(t);break;case \"e_readReview\":z(c,n);t=\"readReview:\"+(c.productName||k);B(t);break;case \"e_removeFromCart\":z(c,\nn);t=\"removeFromCart\";B(t);break;case \"e_searchResults\":z(c,n);t=\"searchTerms\";B(t);break;default:p(ha,\"UNPROCESSED:\",d)}}}catch(S){console.log(C,\"in callOnDLchange:\",S,\"\\n\"+_A.varsToStr(\"-l\",b+\"[\"+f+\"]\\x3d\",b[f]))}else console.log(ha,\"in callonDLchange window.\"+b,\"not an array\")};if(!H){try{var p=function(){(_A.section.dev||_A.cR(\"debugMode\"))\u0026\u0026console.log.apply(this,arguments)};_A.parseParam(\"debug\")\u0026\u0026_A.cW(\"debugMode\",1);_A.cR(\"debugMode\")\u0026\u0026(_A.section.dev=r)}catch(b){console.log(C,\"while checking debugMode\",\nb)}_A.watch(ka,Y)}return{udlOnEns:n,compatibilityMode:H}}());\u003C\/script\u003E\n"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":58
    }],
  "predicates":[{
      "function":"_eq",
      "arg0":["macro",11],
      "arg1":"blockTransaction"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_pageView"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_video"
    },{
      "function":"_eq",
      "arg0":["macro",148],
      "arg1":"true"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"scrollEvent"
    },{
      "function":"_eq",
      "arg0":["macro",6],
      "arg1":"outbound"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"gtm.linkClick"
    },{
      "function":"_re",
      "arg0":["macro",159],
      "arg1":"(^$|((^|,)7314507_38($|,)))"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_userRegister"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_userLogin"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_emailSubscribe"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_emailUnsubscribe"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_searchResults"
    },{
      "function":"_re",
      "arg0":["macro",68],
      "arg1":"e_searchFilter|e_facet"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_searchSortBy"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_linkClick"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_chatOpen"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_couponApplied"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_couponError"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_readReview"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_compareModels"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_prodDetailsTab"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_busChatOpen"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_supplierSearch"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_callRequest"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_returnStart"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_searchAutoClick"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_orderStatus"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_productReviewed"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_configuratorChange"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_errorCheckoutForm"
    },{
      "function":"_eq",
      "arg0":["macro",6],
      "arg1":"social"
    },{
      "function":"_re",
      "arg0":["macro",159],
      "arg1":"(^$|((^|,)7314507_35($|,)))"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_addToCart"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_removeFromCart"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_configuratorStart"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_configuratorComplete"
    },{
      "function":"_eq",
      "arg0":["macro",6],
      "arg1":"download"
    },{
      "function":"_re",
      "arg0":["macro",159],
      "arg1":"(^$|((^|,)7314507_36($|,)))"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_formSubmit"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_formError"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_formStart"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_ABtest"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_checkShipping"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_demandBase"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_internal"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"e_dnb"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"gtm.dom"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"gtm.elementVisibility"
    },{
      "function":"_re",
      "arg0":["macro",159],
      "arg1":"(^$|((^|,)7314507_312($|,)))"
    },{
      "function":"_eq",
      "arg0":["macro",68],
      "arg1":"gtm.js"
    },{
      "function":"_re",
      "arg0":["macro",161],
      "arg1":"(.*)",
      "ignore_case":true
    }],
  "rules":[
    [["if",1],["unless",0],["add",0]],
    [["if",2],["add",1]],
    [["if",4],["unless",3],["add",2]],
    [["if",5,6,7],["add",3]],
    [["if",8],["add",4]],
    [["if",9],["add",5]],
    [["if",10],["add",6]],
    [["if",11],["add",7]],
    [["if",12],["add",8]],
    [["if",13],["add",9]],
    [["if",14],["add",10]],
    [["if",15],["add",11]],
    [["if",16],["add",12]],
    [["if",17],["add",13]],
    [["if",18],["add",14]],
    [["if",19],["add",15]],
    [["if",20],["add",16]],
    [["if",21],["add",17]],
    [["if",22],["add",18]],
    [["if",23],["add",19]],
    [["if",24],["add",20]],
    [["if",25],["add",21]],
    [["if",26],["add",22]],
    [["if",27],["add",23]],
    [["if",28],["add",24]],
    [["if",29],["add",25]],
    [["if",30],["add",26]],
    [["if",6,31,32],["add",27]],
    [["if",33],["add",28]],
    [["if",34],["add",29]],
    [["if",35],["add",30]],
    [["if",36],["add",31]],
    [["if",6,37,38],["add",32]],
    [["if",39],["add",33]],
    [["if",40],["add",34]],
    [["if",41],["add",35]],
    [["if",42],["add",36]],
    [["if",43],["add",37]],
    [["if",44],["add",38]],
    [["if",45],["add",39]],
    [["if",46],["add",40]],
    [["if",47],["add",41,62]],
    [["if",48,49],["add",41]],
    [["if",50],["add",42,43,44,45,46,47,48,49,50,51,59,60,61,57,58]],
    [["if",50,51],["add",52,53,54,55,56]]]
},
"runtime":[
[],[]
]
};
var da=this,ha=function(){if(null===ea){var a;a:{var b=da.document,c=b.querySelector&&b.querySelector("script[nonce]");if(c){var d=c.nonce||c.getAttribute("nonce");if(d&&fa.test(d)){a=d;break a}}a=null}ea=a||""}return ea},fa=/^[\w+/_-]+[=]{0,2}$/,ea=null,ia=function(a,b){function c(){}c.prototype=b.prototype;a.rf=b.prototype;a.prototype=new c;a.prototype.constructor=a;a.Ye=function(a,c,g){for(var d=Array(arguments.length-2),e=2;e<arguments.length;e++)d[e-2]=arguments[e];return b.prototype[c].apply(a,
d)}};var f=function(a,b){this.C=a;this.wd=b};f.prototype.Kd=function(){return this.C};f.prototype.getType=f.prototype.Kd;f.prototype.getData=function(){return this.wd};f.prototype.getData=f.prototype.getData;var ka=function(a){return"number"===typeof a&&0<=a&&isFinite(a)&&0===a%1||"string"===typeof a&&"-"!==a[0]&&a===""+parseInt(a,10)},la=function(){this.ka={};this.Aa=!1};la.prototype.get=function(a){return this.ka["dust."+a]};la.prototype.set=function(a,b){!this.Aa&&(this.ka["dust."+a]=b)};la.prototype.has=function(a){return this.ka.hasOwnProperty("dust."+a)};var ma=function(a){var b=[],c;for(c in a.ka)a.ka.hasOwnProperty(c)&&b.push(c.substr(5));return b};
la.prototype.remove=function(a){!this.Aa&&delete this.ka["dust."+a]};la.prototype.M=function(){this.Aa=!0};var v=function(a){this.na=new la;this.i=[];a=a||[];for(var b in a)a.hasOwnProperty(b)&&(ka(b)?this.i[Number(b)]=a[Number(b)]:this.na.set(b,a[b]))};v.prototype.toString=function(){for(var a=[],b=0;b<this.i.length;b++){var c=this.i[b];null===c||void 0===c?a.push(""):a.push(c.toString())}return a.join(",")};v.prototype.set=function(a,b){if("length"==a){if(!ka(b))throw"RangeError: Length property must be a valid integer.";this.i.length=Number(b)}else ka(a)?this.i[Number(a)]=b:this.na.set(a,b)};
v.prototype.set=v.prototype.set;v.prototype.get=function(a){return"length"==a?this.length():ka(a)?this.i[Number(a)]:this.na.get(a)};v.prototype.get=v.prototype.get;v.prototype.length=function(){return this.i.length};v.prototype.T=function(){for(var a=ma(this.na),b=0;b<this.i.length;b++)a.push(b+"");return new v(a)};v.prototype.getKeys=v.prototype.T;v.prototype.remove=function(a){ka(a)?delete this.i[Number(a)]:this.na.remove(a)};v.prototype.remove=v.prototype.remove;v.prototype.pop=function(){return this.i.pop()};
v.prototype.pop=v.prototype.pop;v.prototype.push=function(a){return this.i.push.apply(this.i,Array.prototype.slice.call(arguments))};v.prototype.push=v.prototype.push;v.prototype.shift=function(){return this.i.shift()};v.prototype.shift=v.prototype.shift;v.prototype.splice=function(a,b,c){return new v(this.i.splice.apply(this.i,arguments))};v.prototype.splice=v.prototype.splice;v.prototype.unshift=function(a){return this.i.unshift.apply(this.i,Array.prototype.slice.call(arguments))};
v.prototype.unshift=v.prototype.unshift;v.prototype.has=function(a){return ka(a)&&this.i.hasOwnProperty(a)||this.na.has(a)};var na=function(){function a(a,b){c[a]=b}function b(){c={};g=!1}var c={},d,e={},g=!1,h={add:a,Wb:function(a,b,c){e[a]||(e[a]={});e[a][b]=c},create:function(e){var h={add:a,assert:function(a,b){if(!g){var h=c[a]||d;h&&h.apply(e,Array.prototype.slice.call(arguments,0))}},reset:b};h.add=h.add;h.assert=h.assert;h.reset=h.reset;return h},xc:function(a){return e[a]?(b(),c=e[a],!0):!1},oa:function(a){d=a},reset:b,Hc:function(a){g=a}};h.add=h.add;h.addToCache=h.Wb;h.loadFromCache=h.xc;h.registerDefaultPermission=
h.oa;h.reset=h.reset;h.setPermitAllAsserts=h.Hc;return h};var oa=function(){function a(a,c){if(b[a]){if(b[a].Pa+c>b[a].max)throw Error("Quota exceeded");b[a].Pa+=c}}var b={},c=void 0,d=void 0,e={ke:function(a){c=a},Xb:function(){c&&a(c,1)},me:function(a){d=a},W:function(b){d&&a(d,b)},He:function(a,c){b[a]=b[a]||{Pa:0};b[a].max=c},Jd:function(a){return b[a]&&b[a].Pa||0},reset:function(){b={}},qd:a};e.onFnConsume=e.ke;e.consumeFn=e.Xb;e.onStorageConsume=e.me;e.consumeStorage=e.W;e.setMax=e.He;e.getConsumed=e.Jd;e.reset=e.reset;e.consume=e.qd;return e};var pa=function(a,b,c){this.N=a;this.I=b;this.Z=c;this.i=new la};pa.prototype.add=function(a,b){this.i.Aa||(this.N.W(("string"===typeof a?a.length:1)+("string"===typeof b?b.length:1)),this.i.set(a,b))};pa.prototype.add=pa.prototype.add;pa.prototype.set=function(a,b){this.i.Aa||(this.Z&&this.Z.has(a)?this.Z.set(a,b):(this.N.W(("string"===typeof a?a.length:1)+("string"===typeof b?b.length:1)),this.i.set(a,b)))};pa.prototype.set=pa.prototype.set;
pa.prototype.get=function(a){return this.i.has(a)?this.i.get(a):this.Z?this.Z.get(a):void 0};pa.prototype.get=pa.prototype.get;pa.prototype.has=function(a){return!!this.i.has(a)||!(!this.Z||!this.Z.has(a))};pa.prototype.has=pa.prototype.has;pa.prototype.K=function(){return this.N};pa.prototype.M=function(){this.i.M()};var qa=function(){},ra=function(a){return"function"==typeof a},sa=function(a){return"string"==typeof a},ta=function(a){return"number"==typeof a&&!isNaN(a)},ua=function(a){return"[object Array]"==Object.prototype.toString.call(Object(a))},va=function(a,b){if(Array.prototype.indexOf){var c=a.indexOf(b);return"number"==typeof c?c:-1}for(var d=0;d<a.length;d++)if(a[d]===b)return d;return-1},xa=function(a,b){if(!ta(a)||!ta(b)||a>b)a=0,b=2147483647;return Math.floor(Math.random()*(b-a+1)+a)},ya=function(a){return Math.round(Number(a))||
0},Aa=function(a){return"false"==String(a).toLowerCase()?!1:!!a},Ba=function(a){var b=[];if(ua(a))for(var c=0;c<a.length;c++)b.push(String(a[c]));return b},Ca=function(){return new Date},Da=function(){this.prefix="gtm.";this.values={}};Da.prototype.set=function(a,b){this.values[this.prefix+a]=b};Da.prototype.get=function(a){return this.values[this.prefix+a]};Da.prototype.contains=function(a){return void 0!==this.get(a)};
var Ea=function(a,b,c){return a&&a.hasOwnProperty(b)?a[b]:c},Fa=function(a){var b=!1;return function(){if(!b)try{a()}catch(c){}b=!0}},Ga=function(a,b){for(var c in b)b.hasOwnProperty(c)&&(a[c]=b[c])},Ha=function(a){for(var b in a)if(a.hasOwnProperty(b))return!0;return!1};var w=function(a,b){la.call(this);this.yc=a;this.Gd=b};ia(w,la);var Ja=function(a,b){for(var c,d=0;d<b.length&&!(c=Ia(a,b[d]),c instanceof f);d++);return c},Ia=function(a,b){var c=a.get(String(b[0]));if(!(c&&c instanceof w))throw"Attempting to execute non-function "+b[0]+".";return c.o.apply(c,[a].concat(b.slice(1)))};w.prototype.toString=function(){return this.yc};w.prototype.getName=function(){return this.yc};w.prototype.getName=w.prototype.getName;w.prototype.T=function(){return new v(ma(this))};
w.prototype.getKeys=w.prototype.T;w.prototype.o=function(a,b){var c,d={F:function(){return a},evaluate:function(b){var c=a;return ua(b)?Ia(c,b):b},xa:function(b){return Ja(a,b)},K:function(){return a.K()},kb:function(){c||(c=a.I.create(d));return c}};a.K().Xb();return this.Gd.apply(d,Array.prototype.slice.call(arguments,1))};w.prototype.invoke=w.prototype.o;var Ka=function(){la.call(this)};ia(Ka,la);Ka.prototype.T=function(){return new v(ma(this))};Ka.prototype.getKeys=Ka.prototype.T;/*
 jQuery v1.9.1 (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license. */
var La=/\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,Ma=function(a){if(null==a)return String(a);var b=La.exec(Object.prototype.toString.call(Object(a)));return b?b[1].toLowerCase():"object"},Na=function(a,b){return Object.prototype.hasOwnProperty.call(Object(a),b)},Oa=function(a){if(!a||"object"!=Ma(a)||a.nodeType||a==a.window)return!1;try{if(a.constructor&&!Na(a,"constructor")&&!Na(a.constructor.prototype,"isPrototypeOf"))return!1}catch(c){return!1}for(var b in a);return void 0===
b||Na(a,b)},Pa=function(a,b){var c=b||("array"==Ma(a)?[]:{}),d;for(d in a)if(Na(a,d)){var e=a[d];"array"==Ma(e)?("array"!=Ma(c[d])&&(c[d]=[]),c[d]=Pa(e,c[d])):Oa(e)?(Oa(c[d])||(c[d]={}),c[d]=Pa(e,c[d])):c[d]=e}return c};var Qa=function(a){if(a instanceof v){for(var b=[],c=a.length(),d=0;d<c;d++)a.has(d)&&(b[d]=Qa(a.get(d)));return b}if(a instanceof Ka){for(var e={},g=a.T(),h=g.length(),k=0;k<h;k++)e[g.get(k)]=Qa(a.get(g.get(k)));return e}return a instanceof w?function(){for(var b=Array.prototype.slice.call(arguments,0),c=0;c<b.length;c++)b[c]=Ra(b[c]);var d=new pa(oa(),na());return Qa(a.o.apply(a,[d].concat(b)))}:a},Ra=function(a){if(ua(a)){for(var b=[],c=0;c<a.length;c++)a.hasOwnProperty(c)&&(b[c]=Ra(a[c]));return new v(b)}if(Oa(a)){var d=
new Ka,e;for(e in a)a.hasOwnProperty(e)&&d.set(e,Ra(a[e]));return d}if("function"===typeof a)return new w("",function(b){for(var c=Array.prototype.slice.call(arguments,0),d=0;d<c.length;d++)c[d]=Qa(this.evaluate(c[d]));return Ra(a.apply(a,c))});var g=typeof a;if(null===a||"string"===g||"number"===g||"boolean"===g)return a};var Sa={control:function(a,b){return new f(a,this.evaluate(b))},fn:function(a,b,c){var d=this.F(),e=this.evaluate(b);if(!(e instanceof v))throw"Error: non-List value given for Fn argument names.";var g=Array.prototype.slice.call(arguments,2);this.K().W(a.length+g.length);return new w(a,function(){return function(a){for(var b=new pa(d.N,d.I,d),c=Array.prototype.slice.call(arguments,0),h=0;h<c.length;h++)if(c[h]=this.evaluate(c[h]),c[h]instanceof f)return c[h];for(var n=e.get("length"),p=0;p<n;p++)p<
c.length?b.set(e.get(p),c[p]):b.set(e.get(p),void 0);b.set("arguments",new v(c));var q=Ja(b,g);if(q instanceof f)return"return"===q.C?q.getData():q}}())},list:function(a){var b=this.K();b.W(arguments.length);for(var c=new v,d=0;d<arguments.length;d++){var e=this.evaluate(arguments[d]);"string"===typeof e&&b.W(e.length?e.length-1:0);c.push(e)}return c},map:function(a){for(var b=this.K(),c=new Ka,d=0;d<arguments.length-1;d+=2){var e=this.evaluate(arguments[d])+"",g=this.evaluate(arguments[d+1]),h=e.length;
h+="string"===typeof g?g.length:1;b.W(h);c.set(e,g)}return c},undefined:function(){}};var x=function(){this.N=oa();this.I=na();this.ya=new pa(this.N,this.I)};x.prototype.V=function(a,b){var c=new w(a,b);c.M();this.ya.set(a,c)};x.prototype.addInstruction=x.prototype.V;x.prototype.Vb=function(a,b){Sa.hasOwnProperty(a)&&this.V(b||a,Sa[a])};x.prototype.addNativeInstruction=x.prototype.Vb;x.prototype.K=function(){return this.N};x.prototype.getQuota=x.prototype.K;x.prototype.Wa=function(){this.N=oa();this.ya.N=this.N};x.prototype.resetQuota=x.prototype.Wa;
x.prototype.Ee=function(){this.I=na();this.ya.I=this.I};x.prototype.resetPermissions=x.prototype.Ee;x.prototype.L=function(a,b){var c=Array.prototype.slice.call(arguments,0);return this.yb(c)};x.prototype.execute=x.prototype.L;x.prototype.yb=function(a){for(var b,c=0;c<arguments.length;c++){var d=Ia(this.ya,arguments[c]);b=d instanceof f||d instanceof w||d instanceof v||d instanceof Ka||null===d||void 0===d||"string"===typeof d||"number"===typeof d||"boolean"===typeof d?d:void 0}return b};
x.prototype.run=x.prototype.yb;x.prototype.M=function(){this.ya.M()};x.prototype.makeImmutable=x.prototype.M;var Ta=function(a){for(var b=[],c=0;c<a.length();c++)a.has(c)&&(b[c]=a.get(c));return b};var Ua={Le:"concat every filter forEach hasOwnProperty indexOf join lastIndexOf map pop push reduce reduceRight reverse shift slice some sort splice unshift toString".split(" "),concat:function(a,b){for(var c=[],d=0;d<this.length();d++)c.push(this.get(d));for(d=1;d<arguments.length;d++)if(arguments[d]instanceof v)for(var e=arguments[d],g=0;g<e.length();g++)c.push(e.get(g));else c.push(arguments[d]);return new v(c)},every:function(a,b){for(var c=this.length(),d=0;d<this.length()&&d<c;d++)if(this.has(d)&&
!b.o(a,this.get(d),d,this))return!1;return!0},filter:function(a,b){for(var c=this.length(),d=[],e=0;e<this.length()&&e<c;e++)this.has(e)&&b.o(a,this.get(e),e,this)&&d.push(this.get(e));return new v(d)},forEach:function(a,b){for(var c=this.length(),d=0;d<this.length()&&d<c;d++)this.has(d)&&b.o(a,this.get(d),d,this)},hasOwnProperty:function(a,b){return this.has(b)},indexOf:function(a,b,c){var d=this.length(),e=void 0===c?0:Number(c);0>e&&(e=Math.max(d+e,0));for(var g=e;g<d;g++)if(this.has(g)&&this.get(g)===
b)return g;return-1},join:function(a,b){for(var c=[],d=0;d<this.length();d++)c.push(this.get(d));return c.join(b)},lastIndexOf:function(a,b,c){var d=this.length(),e=d-1;void 0!==c&&(e=0>c?d+c:Math.min(c,e));for(var g=e;0<=g;g--)if(this.has(g)&&this.get(g)===b)return g;return-1},map:function(a,b){for(var c=this.length(),d=[],e=0;e<this.length()&&e<c;e++)this.has(e)&&(d[e]=b.o(a,this.get(e),e,this));return new v(d)},pop:function(){return this.pop()},push:function(a,b){return this.push.apply(this,Array.prototype.slice.call(arguments,
1))},reduce:function(a,b,c){var d=this.length(),e,g;if(void 0!==c)e=c,g=0;else{if(0==d)throw"TypeError: Reduce on List with no elements.";for(var h=0;h<d;h++)if(this.has(h)){e=this.get(h);g=h+1;break}if(h==d)throw"TypeError: Reduce on List with no elements.";}for(h=g;h<d;h++)this.has(h)&&(e=b.o(a,e,this.get(h),h,this));return e},reduceRight:function(a,b,c){var d=this.length(),e,g;if(void 0!==c)e=c,g=d-1;else{if(0==d)throw"TypeError: ReduceRight on List with no elements.";for(var h=1;h<=d;h++)if(this.has(d-
h)){e=this.get(d-h);g=d-(h+1);break}if(h>d)throw"TypeError: ReduceRight on List with no elements.";}for(h=g;0<=h;h--)this.has(h)&&(e=b.o(a,e,this.get(h),h,this));return e},reverse:function(){for(var a=Ta(this),b=a.length-1,c=0;0<=b;b--,c++)a.hasOwnProperty(b)?this.set(c,a[b]):this.remove(c);return this},shift:function(){return this.shift()},slice:function(a,b,c){var d=this.length();void 0===b&&(b=0);b=0>b?Math.max(d+b,0):Math.min(b,d);c=void 0===c?d:0>c?Math.max(d+c,0):Math.min(c,d);c=Math.max(b,
c);for(var e=[],g=b;g<c;g++)e.push(this.get(g));return new v(e)},some:function(a,b){for(var c=this.length(),d=0;d<this.length()&&d<c;d++)if(this.has(d)&&b.o(a,this.get(d),d,this))return!0;return!1},sort:function(a,b){var c=Ta(this);void 0===b?c.sort():c.sort(function(c,d){return Number(b.o(a,c,d))});for(var d=0;d<c.length;d++)c.hasOwnProperty(d)?this.set(d,c[d]):this.remove(d)},splice:function(a,b,c,d){return this.splice.apply(this,Array.prototype.splice.call(arguments,1,arguments.length-1))},toString:function(){return this.toString()},
unshift:function(a,b){return this.unshift.apply(this,Array.prototype.slice.call(arguments,1))}};var y={oc:{ADD:0,AND:1,APPLY:2,ASSIGN:3,BREAK:4,CASE:5,CONTINUE:6,CONTROL:49,CREATE_ARRAY:7,CREATE_OBJECT:8,DEFAULT:9,DEFN:50,DIVIDE:10,DO:11,EQUALS:12,EXPRESSION_LIST:13,FN:51,FOR:14,FOR_IN:47,GET:15,GET_CONTAINER_VARIABLE:48,GET_INDEX:16,GET_PROPERTY:17,GREATER_THAN:18,GREATER_THAN_EQUALS:19,IDENTITY_EQUALS:20,IDENTITY_NOT_EQUALS:21,IF:22,LESS_THAN:23,LESS_THAN_EQUALS:24,MODULUS:25,MULTIPLY:26,NEGATE:27,NOT:28,NOT_EQUALS:29,NULL:45,OR:30,PLUS_EQUALS:31,POST_DECREMENT:32,POST_INCREMENT:33,PRE_DECREMENT:34,
PRE_INCREMENT:35,QUOTE:46,RETURN:36,SET_PROPERTY:43,SUBTRACT:37,SWITCH:38,TERNARY:39,TYPEOF:40,UNDEFINED:44,VAR:41,WHILE:42}},Va="charAt concat indexOf lastIndexOf match replace search slice split substring toLowerCase toLocaleLowerCase toString toUpperCase toLocaleUpperCase trim".split(" "),Wa=new f("break"),Xa=new f("continue");y.add=function(a,b){return this.evaluate(a)+this.evaluate(b)};y.and=function(a,b){return this.evaluate(a)&&this.evaluate(b)};
y.apply=function(a,b,c){a=this.evaluate(a);b=this.evaluate(b);c=this.evaluate(c);if(!(c instanceof v))throw"Error: Non-List argument given to Apply instruction.";if(null===a||void 0===a)throw"TypeError: Can't read property "+b+" of "+a+".";if("boolean"==typeof a||"number"==typeof a){if("toString"==b)return a.toString();throw"TypeError: "+a+"."+b+" is not a function.";}if("string"==typeof a){if(0<=va(Va,b))return Ra(a[b].apply(a,Ta(c)));throw"TypeError: "+b+" is not a function";}if(a instanceof v){if(a.has(b)){var d=
a.get(b);if(d instanceof w){var e=Ta(c);e.unshift(this.F());return d.o.apply(d,e)}throw"TypeError: "+b+" is not a function";}if(0<=va(Ua.Le,b))return e=Ta(c),e.unshift(this.F()),Ua[b].apply(a,e)}if(a instanceof w||a instanceof Ka){if(a.has(b)){d=a.get(b);if(d instanceof w)return e=Ta(c),e.unshift(this.F()),d.o.apply(d,e);throw"TypeError: "+b+" is not a function";}if("toString"==b)return a instanceof w?a.getName():a.toString();if("hasOwnProperty"==b)return a.has.apply(a,Ta(c))}throw"TypeError: Object has no '"+
b+"' property.";};y.assign=function(a,b){a=this.evaluate(a);if("string"!=typeof a)throw"Invalid key name given for assignment.";var c=this.F();if(!c.has(a))throw"Attempting to assign to undefined value "+b;var d=this.evaluate(b);c.set(a,d);return d};y["break"]=function(){return Wa};y["case"]=function(a){for(var b=this.evaluate(a),c=0;c<b.length;c++){var d=this.evaluate(b[c]);if(d instanceof f)return d}};y["continue"]=function(){return Xa};
y.xd=function(a,b,c){var d=new v;b=this.evaluate(b);for(var e=0;e<b.length;e++)d.push(b[e]);var g=[y.oc.FN,a,d].concat(Array.prototype.splice.call(arguments,2,arguments.length-2));this.F().set(a,this.evaluate(g))};y.Ad=function(a,b){return this.evaluate(a)/this.evaluate(b)};y.Dd=function(a,b){return this.evaluate(a)==this.evaluate(b)};y.Ed=function(a){for(var b,c=0;c<arguments.length;c++)b=this.evaluate(arguments[c]);return b};
y.Hd=function(a,b,c){a=this.evaluate(a);b=this.evaluate(b);c=this.evaluate(c);var d=this.F();if("string"==typeof b)for(var e=0;e<b.length;e++){d.set(a,e);var g=this.xa(c);if(g instanceof f){if("break"==g.C)break;if("return"==g.C)return g}}else if(b instanceof Ka||b instanceof v||b instanceof w){var h=b.T(),k=h.length();for(e=0;e<k;e++)if(d.set(a,h.get(e)),g=this.xa(c),g instanceof f){if("break"==g.C)break;if("return"==g.C)return g}}};y.get=function(a){return this.F().get(this.evaluate(a))};
y.hc=function(a,b){var c;a=this.evaluate(a);b=this.evaluate(b);if(void 0===a||null===a)throw"TypeError: cannot access property of "+a+".";a instanceof Ka||a instanceof v||a instanceof w?c=a.get(b):"string"==typeof a&&("length"==b?c=a.length:ka(b)&&(c=a[b]));return c};y.Ld=function(a,b){return this.evaluate(a)>this.evaluate(b)};y.Md=function(a,b){return this.evaluate(a)>=this.evaluate(b)};y.Td=function(a,b){return this.evaluate(a)===this.evaluate(b)};y.Ud=function(a,b){return this.evaluate(a)!==this.evaluate(b)};
y["if"]=function(a,b,c){var d=[];this.evaluate(a)?d=this.evaluate(b):c&&(d=this.evaluate(c));var e=this.xa(d);if(e instanceof f)return e};y.be=function(a,b){return this.evaluate(a)<this.evaluate(b)};y.ce=function(a,b){return this.evaluate(a)<=this.evaluate(b)};y.ee=function(a,b){return this.evaluate(a)%this.evaluate(b)};y.multiply=function(a,b){return this.evaluate(a)*this.evaluate(b)};y.fe=function(a){return-this.evaluate(a)};y.he=function(a){return!this.evaluate(a)};
y.ie=function(a,b){return this.evaluate(a)!=this.evaluate(b)};y["null"]=function(){return null};y.or=function(a,b){return this.evaluate(a)||this.evaluate(b)};y.Dc=function(a,b){var c=this.evaluate(a);this.evaluate(b);return c};y.Ec=function(a){return this.evaluate(a)};y.quote=function(a){return Array.prototype.slice.apply(arguments)};y["return"]=function(a){return new f("return",this.evaluate(a))};
y.setProperty=function(a,b,c){a=this.evaluate(a);b=this.evaluate(b);c=this.evaluate(c);if(null===a||void 0===a)throw"TypeError: Can't set property "+b+" of "+a+".";(a instanceof w||a instanceof v||a instanceof Ka)&&a.set(b,c);return c};y.Ke=function(a,b){return this.evaluate(a)-this.evaluate(b)};
y["switch"]=function(a,b,c){a=this.evaluate(a);b=this.evaluate(b);c=this.evaluate(c);if(!ua(b)||!ua(c))throw"Error: Malformed switch instruction.";for(var d,e=!1,g=0;g<b.length;g++)if(e||a===this.evaluate(b[g]))if(d=this.evaluate(c[g]),d instanceof f){var h=d.C;if("break"==h)return;if("return"==h||"continue"==h)return d}else e=!0;if(c.length==b.length+1&&(d=this.evaluate(c[c.length-1]),d instanceof f&&("return"==d.C||"continue"==d.C)))return d};
y.Me=function(a,b,c){return this.evaluate(a)?this.evaluate(b):this.evaluate(c)};y["typeof"]=function(a){a=this.evaluate(a);return a instanceof w?"function":typeof a};y.undefined=function(){};y["var"]=function(a){for(var b=this.F(),c=0;c<arguments.length;c++){var d=arguments[c];"string"!=typeof d||b.add(d,void 0)}};
y["while"]=function(a,b,c,d){var e,g=this.evaluate(d);if(this.evaluate(c)&&(e=this.xa(g),e instanceof f)){if("break"==e.C)return;if("return"==e.C)return e}for(;this.evaluate(a);){e=this.xa(g);if(e instanceof f){if("break"==e.C)break;if("return"==e.C)return e}this.evaluate(b)}};var ab=function(){this.nc=!1;this.H=new x;Ya(this);this.nc=!0};ab.prototype.Zd=function(){return this.nc};ab.prototype.isInitialized=ab.prototype.Zd;ab.prototype.L=function(a){this.H.I.xc(String(a[0]))||(this.H.I.reset(),this.H.I.Hc(!0));return this.H.yb(a)};ab.prototype.execute=ab.prototype.L;ab.prototype.M=function(){this.H.M()};ab.prototype.makeImmutable=ab.prototype.M;
var Ya=function(a){function b(a,b){e.H.Vb(a,String(b))}function c(a,b){e.H.V(String(d[a]),b)}var d=y.oc,e=a;b("control",d.CONTROL);b("fn",d.FN);b("list",d.CREATE_ARRAY);b("map",d.CREATE_OBJECT);b("undefined",d.UNDEFINED);c("ADD",y.add);c("AND",y.and);c("APPLY",y.apply);c("ASSIGN",y.assign);c("BREAK",y["break"]);c("CASE",y["case"]);c("CONTINUE",y["continue"]);c("DEFAULT",y["case"]);c("DEFN",y.xd);c("DIVIDE",y.Ad);c("EQUALS",y.Dd);c("EXPRESSION_LIST",y.Ed);c("FOR_IN",y.Hd);c("GET",y.get);c("GET_INDEX",
y.hc);c("GET_PROPERTY",y.hc);c("GREATER_THAN",y.Ld);c("GREATER_THAN_EQUALS",y.Md);c("IDENTITY_EQUALS",y.Td);c("IDENTITY_NOT_EQUALS",y.Ud);c("IF",y["if"]);c("LESS_THAN",y.be);c("LESS_THAN_EQUALS",y.ce);c("MODULUS",y.ee);c("MULTIPLY",y.multiply);c("NEGATE",y.fe);c("NOT",y.he);c("NOT_EQUALS",y.ie);c("NULL",y["null"]);c("OR",y.or);c("POST_DECREMENT",y.Dc);c("POST_INCREMENT",y.Dc);c("PRE_DECREMENT",y.Ec);c("PRE_INCREMENT",y.Ec);c("QUOTE",y.quote);c("RETURN",y["return"]);c("SET_PROPERTY",y.setProperty);
c("SUBTRACT",y.Ke);c("SWITCH",y["switch"]);c("TERNARY",y.Me);c("TYPEOF",y["typeof"]);c("VAR",y["var"]);c("WHILE",y["while"])};ab.prototype.V=function(a,b){this.H.V(a,b)};ab.prototype.addInstruction=ab.prototype.V;ab.prototype.K=function(){return this.H.K()};ab.prototype.getQuota=ab.prototype.K;ab.prototype.Wa=function(){this.H.Wa()};ab.prototype.resetQuota=ab.prototype.Wa;ab.prototype.oa=function(a){this.H.I.oa(a)};ab.prototype.Na=function(a,b,c){this.H.I.Wb(a,b,c)};var bb=function(){this.Sa={}};bb.prototype.get=function(a){return this.Sa.hasOwnProperty(a)?this.Sa[a]:void 0};bb.prototype.add=function(a,b){if(this.Sa.hasOwnProperty(a))throw"Attempting to add a function which already exists: "+a+".";var c=new w(a,function(){for(var a=Array.prototype.slice.call(arguments,0),c=0;c<a.length;c++)a[c]=this.evaluate(a[c]);return b.apply(this,a)});c.M();this.Sa[a]=c};bb.prototype.addAll=function(a){for(var b in a)a.hasOwnProperty(b)&&this.add(b,a[b])};var z=window,B=document,cb=navigator,db=function(a,b){var c=z[a];z[a]=void 0===c?b:c;return z[a]},eb=function(a,b){b&&(a.addEventListener?a.onload=b:a.onreadystatechange=function(){a.readyState in{loaded:1,complete:1}&&(a.onreadystatechange=null,b())})},fb=function(a,b,c){var d=B.createElement("script");d.type="text/javascript";d.async=!0;d.src=a;eb(d,b);c&&(d.onerror=c);ha()&&d.setAttribute("nonce",ha());var e=B.getElementsByTagName("script")[0]||B.body||B.head;e.parentNode.insertBefore(d,e);return d},
gb=function(a,b){var c=B.createElement("iframe");c.height="0";c.width="0";c.style.display="none";c.style.visibility="hidden";var d=B.body&&B.body.lastChild||B.body||B.head;d.parentNode.insertBefore(c,d);eb(c,b);void 0!==a&&(c.src=a);return c},F=function(a,b,c){var d=new Image(1,1);d.onload=function(){d.onload=null;b&&b()};d.onerror=function(){d.onerror=null;c&&c()};d.src=a},hb=function(a,b,c,d){a.addEventListener?a.addEventListener(b,c,!!d):a.attachEvent&&a.attachEvent("on"+b,c)},ib=function(a,b,
c,d){a.removeEventListener?a.removeEventListener(b,c,!!d):a.detachEvent&&a.detachEvent("on"+b,c)},H=function(a){z.setTimeout(a,0)},lb=function(a){var b=B.getElementById(a);if(b&&kb(b,"id")!=a)for(var c=1;c<document.all[a].length;c++)if(kb(document.all[a][c],"id")==a)return document.all[a][c];return b},kb=function(a,b){return a&&b&&a.attributes&&a.attributes[b]?a.attributes[b].value:null},mb=function(a){var b=a.innerText||a.textContent||"";b&&" "!=b&&(b=b.replace(/^[\s\xa0]+|[\s\xa0]+$/g,""));b&&(b=
b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g," "));return b},nb=function(a){var b=B.createElement("div");b.innerHTML="A<div>"+a+"</div>";b=b.lastChild;for(var c=[];b.firstChild;)c.push(b.removeChild(b.firstChild));return c},ob=function(a){cb.sendBeacon&&cb.sendBeacon(a)||F(a)};var pb=/^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;var qb=/:[0-9]+$/,rb=function(a,b,c){for(var d=a.split("&"),e=0;e<d.length;e++){var g=d[e].split("=");if(decodeURIComponent(g[0]).replace(/\+/g," ")==b){var h=g.slice(1).join("=");return c?h:decodeURIComponent(h).replace(/\+/g," ")}}},sb=function(a,b,c,d,e){var g,h=function(a){return a?a.replace(":","").toLowerCase():""},k=h(a.protocol)||h(z.location.protocol);b&&(b=String(b).toLowerCase());switch(b){case "protocol":g=k;break;case "host":g=(a.hostname||z.location.hostname).replace(qb,"").toLowerCase();
if(c){var l=/^www\d*\./.exec(g);l&&l[0]&&(g=g.substr(l[0].length))}break;case "port":g=String(Number(a.hostname?a.port:z.location.port)||("http"==k?80:"https"==k?443:""));break;case "path":g="/"==a.pathname.substr(0,1)?a.pathname:"/"+a.pathname;var m=g.split("/");0<=va(d||[],m[m.length-1])&&(m[m.length-1]="");g=m.join("/");break;case "query":g=a.search.replace("?","");e&&(g=rb(g,e));break;case "extension":var n=a.pathname.split(".");g=1<n.length?n[n.length-1]:"";g=g.split("/")[0];break;case "fragment":g=
a.hash.replace("#","");break;default:g=a&&a.href}return g},tb=function(a){var b="";a&&a.href&&(b=a.hash?a.href.replace(a.hash,""):a.href);return b},N=function(a){var b=document.createElement("a");a&&(pb.test(a),b.href=a);var c=b.pathname;"/"!==c[0]&&(c="/"+c);var d=b.hostname.replace(qb,"");return{href:b.href,protocol:b.protocol,host:b.host,hostname:d,pathname:c,search:b.search,hash:b.hash,port:b.port}};var wb=function(){this.Va=new ab;var a=new bb;a.addAll(ub());vb(this,function(b){return a.get(b)})},ub=function(){return{callInWindow:xb,callLater:yb,copyFromWindow:zb,encodeURI:encodeURI,encodeURIComponent:encodeURIComponent,getReferrer:Ab,getUrl:Bb,getUrlComponent:Cb,getUrlFragment:Db,isPlainObject:Eb,loadIframe:Fb,loadJavaScript:Gb,logToConsole:Hb,queryPermission:Ib,removeUrlFragment:Jb,replaceAll:Kb,sendPixel:Lb,setInWindow:Mb}};wb.prototype.L=function(a){return this.Va.L(a)};
wb.prototype.execute=wb.prototype.L;var vb=function(a,b){a.Va.V("require",b)};wb.prototype.oa=function(a){this.Va.oa(a)};wb.prototype.Na=function(a,b,c){this.Va.Na(a,b,c)};function xb(a,b){for(var c=a.split("."),d=z,e=d[c[0]],g=1;e&&g<c.length;g++)d=e,e=e[c[g]];if("function"==Ma(e)){var h=[];for(g=1;g<arguments.length;g++)h.push(Qa(arguments[g]));e.apply(d,h)}}function yb(a){var b=this.F();H(function(){a instanceof w&&a.o(b)})}function Bb(){return z.location.href}
function zb(a,b,c){for(var d=a.split("."),e=z,g=0;g<d.length-1;g++)if(e=e[d[g]],void 0===e||null===e)return;b&&(void 0===e[d[g]]||c&&!e[d[g]])&&(e[d[g]]=Qa(b));return Ra(e[d[g]])}function Ab(){return B.referrer}function Cb(a,b,c,d,e){var g;if(d&&d instanceof v){g=[];for(var h=0;h<d.length();h++){var k=d.get(h);"string"==typeof k&&g.push(k)}}return sb(N(a),b,c,g,e)}function Db(a){return sb(N(a),"fragment")}function Eb(a){return a instanceof Ka}
function Fb(a,b){var c=this.F();gb(a,function(){b instanceof w&&b.o(c)})}var Nb={};
function Gb(a,b,c,d){this.kb().assert("networkAccess",a);var e=this.F(),g=function(){b instanceof w&&b.o(e)},h=function(){c instanceof w&&c.o(e)};d?Nb[d]?(Nb[d].onSuccess.push(g),Nb[d].onFailure.push(h)):(Nb[d]={onSuccess:[g],onFailure:[h]},g=function(){for(var a=Nb[d].onSuccess,b=0;b<a.length;b++)H(a[b]);a.push=function(a){H(a);return 0}},h=function(){for(var a=Nb[d].onFailure,b=0;b<a.length;b++)H(a[b]);Nb[d]=null},fb(a,g,h)):fb(a,g,h)}
function Hb(){for(var a=Array.prototype.slice.call(arguments,0),b=0;b<a.length;b++)a[b]=Qa(a[b]);console.log.apply(console,a)}function Jb(a){return tb(N(a))}function Kb(a,b,c){return a.replace(new RegExp(b,"g"),c)}function Lb(a,b,c){this.kb().assert("sendPixel",a);var d=this.F();F(a,function(){b instanceof w&&b.o(d)},function(){c instanceof w&&c.o(d)})}
function Mb(a,b,c){for(var d=a.split("."),e=z,g=0;g<d.length-1;g++)if(e=e[d[g]],void 0===e)return!1;return void 0===e[d[g]]||c?(e[d[g]]=Qa(b),!0):!1}function Ib(a,b){try{return this.kb().assert.apply(null,Array.prototype.slice.call(arguments,0)),!0}catch(c){return!1}};
var Ob=[],Pb={"\x00":"&#0;",'"':"&quot;","&":"&amp;","'":"&#39;","<":"&lt;",">":"&gt;","\t":"&#9;","\n":"&#10;","\x0B":"&#11;","\f":"&#12;","\r":"&#13;"," ":"&#32;","-":"&#45;","/":"&#47;","=":"&#61;","`":"&#96;","\u0085":"&#133;","\u00a0":"&#160;","\u2028":"&#8232;","\u2029":"&#8233;"},Qb=function(a){return Pb[a]},Rb=/[\x00\x22\x26\x27\x3c\x3e]/g;var Xb=/[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\\\x85\u2028\u2029]/g,Yb={"\x00":"\\x00","\b":"\\x08","\t":"\\t","\n":"\\n","\x0B":"\\x0b",
"\f":"\\f","\r":"\\r",'"':"\\x22","&":"\\x26","'":"\\x27","/":"\\/","<":"\\x3c","=":"\\x3d",">":"\\x3e","\\":"\\\\","\u0085":"\\x85","\u2028":"\\u2028","\u2029":"\\u2029",$:"\\x24","(":"\\x28",")":"\\x29","*":"\\x2a","+":"\\x2b",",":"\\x2c","-":"\\x2d",".":"\\x2e",":":"\\x3a","?":"\\x3f","[":"\\x5b","]":"\\x5d","^":"\\x5e","{":"\\x7b","|":"\\x7c","}":"\\x7d"},Zb=function(a){return Yb[a]};
Ob[8]=function(a){if(null==a)return" null ";switch(typeof a){case "boolean":case "number":return" "+a+" ";default:return"'"+String(String(a)).replace(Xb,Zb)+"'"}};var gc=/[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,hc={"\x00":"%00","\u0001":"%01","\u0002":"%02","\u0003":"%03","\u0004":"%04","\u0005":"%05","\u0006":"%06","\u0007":"%07","\b":"%08","\t":"%09","\n":"%0A","\x0B":"%0B","\f":"%0C","\r":"%0D","\u000e":"%0E","\u000f":"%0F","\u0010":"%10",
"\u0011":"%11","\u0012":"%12","\u0013":"%13","\u0014":"%14","\u0015":"%15","\u0016":"%16","\u0017":"%17","\u0018":"%18","\u0019":"%19","\u001a":"%1A","\u001b":"%1B","\u001c":"%1C","\u001d":"%1D","\u001e":"%1E","\u001f":"%1F"," ":"%20",'"':"%22","'":"%27","(":"%28",")":"%29","<":"%3C",">":"%3E","\\":"%5C","{":"%7B","}":"%7D","\u007f":"%7F","\u0085":"%C2%85","\u00a0":"%C2%A0","\u2028":"%E2%80%A8","\u2029":"%E2%80%A9","\uff01":"%EF%BC%81","\uff03":"%EF%BC%83","\uff04":"%EF%BC%84","\uff06":"%EF%BC%86",
"\uff07":"%EF%BC%87","\uff08":"%EF%BC%88","\uff09":"%EF%BC%89","\uff0a":"%EF%BC%8A","\uff0b":"%EF%BC%8B","\uff0c":"%EF%BC%8C","\uff0f":"%EF%BC%8F","\uff1a":"%EF%BC%9A","\uff1b":"%EF%BC%9B","\uff1d":"%EF%BC%9D","\uff1f":"%EF%BC%9F","\uff20":"%EF%BC%A0","\uff3b":"%EF%BC%BB","\uff3d":"%EF%BC%BD"},ic=function(a){return hc[a]};Ob[16]=function(a){return a};var kc,lc=[],mc=[],nc=[],oc=[],pc=[],qc={},rc,sc,tc,uc=function(a){var b=a["function"];if(!b)throw"Error: No function name given for function call.";var c=!!qc[b],d={},e;for(e in a)a.hasOwnProperty(e)&&0===e.indexOf("vtp_")&&(d[c?e:e.substr(4)]=a[e]);return c?qc[b](d):kc(b,d)},wc=function(a,b,c,d){c=c||[];d=d||qa;var e={},g;for(g in a)a.hasOwnProperty(g)&&(e[g]=vc(a[g],b,c,d));return e},xc=function(a){var b=a["function"];if(!b)throw"Error: No function name given for function call.";var c=qc[b];return c?
c.b||0:0},vc=function(a,b,c,d){if(ua(a)){var e;switch(a[0]){case "function_id":return a[1];case "list":e=[];for(var g=1;g<a.length;g++)e.push(vc(a[g],b,c,d));return e;case "macro":var h=a[1];if(c[h])return;var k=lc[h];if(!k||b(k))return;c[h]=!0;try{var l=wc(k,b,c,d);e=uc(l);tc&&(e=tc.sd(e,l))}catch(A){d(h,A),e=!1}c[h]=!1;return e;case "map":e={};for(var m=1;m<a.length;m+=2)e[vc(a[m],b,c,d)]=vc(a[m+1],b,c,d);return e;case "template":e=[];for(var n=!1,p=1;p<a.length;p++){var q=vc(a[p],b,c,d);sc&&(n=
n||q===sc.Ia);e.push(q)}return sc&&n?sc.td(e):e.join("");case "escape":e=vc(a[1],b,c,d);if(sc&&ua(a[1])&&"macro"===a[1][0]&&sc.$d(a))return sc.se(e);e=String(e);for(var r=2;r<a.length;r++)Ob[a[r]]&&(e=Ob[a[r]](e));return e;case "tag":var u=a[1];if(!oc[u])throw Error("Unable to resolve tag reference "+u+".");return e={bc:a[2],index:u};case "zb":var t=yc({"function":a[1],arg0:a[2],arg1:a[3],ignore_case:a[5]},b,c,d);a[4]&&(t=!t);return t;default:throw Error("Attempting to expand unknown Value type: "+
a[0]+".");}}return a},yc=function(a,b,c,d){try{return rc(wc(a,b,c,d))}catch(e){JSON.stringify(a)}return null};var Bc=null,Fc=function(a){function b(a){for(var b=0;b<a.length;b++)d[a[b]]=!0}var c=[],d=[];Bc=Cc(a,Dc()||function(){});for(var e=0;e<mc.length;e++){var g=mc[e],h=Ec(g);if(h){for(var k=g.add||[],l=0;l<k.length;l++)c[k[l]]=!0;b(g.block||[])}else null===h&&b(g.block||[])}var m=[];for(e=0;e<oc.length;e++)c[e]&&!d[e]&&(m[e]=!0);return m},Ec=function(a){for(var b=a["if"]||[],c=0;c<b.length;c++){var d=Bc(b[c]);if(!d)return null===d?null:!1}var e=a.unless||[];for(c=0;c<e.length;c++){d=Bc(e[c]);if(null===
d)return null;if(d)return!1}return!0};var Cc=function(a,b){var c=[];return function(d){void 0===c[d]&&(c[d]=yc(nc[d],a,void 0,b));return c[d]}};/*
 Copyright (c) 2014 Derek Brans, MIT license https://github.com/krux/postscribe/blob/master/LICENSE. Portions derived from simplehtmlparser, which is licensed under the Apache License, Version 2.0 */
var Ic={},Jc=null;Ic.s="GTM-MZXB4R4";var Kc=null,Lc=null,Mc="//www.googletagmanager.com/a?id="+Ic.s+"&cv=101",Nc={},Oc={},Pc=B.currentScript?B.currentScript.src:void 0,Qc=function(){var a=Jc.sequence||0;Jc.sequence=a+1;return a};var P=function(){var a=function(a){return{toString:function(){return a}}};return{Kb:a("convert_case_to"),Lb:a("convert_false_to"),Mb:a("convert_null_to"),Nb:a("convert_true_to"),Ob:a("convert_undefined_to"),P:a("function"),Lc:a("instance_name"),Mc:a("live_only"),Nc:a("malware_disabled"),Oc:a("once_per_event"),Qb:a("once_per_load"),Rb:a("setup_tags"),Pc:a("tag_id"),Sb:a("teardown_tags")}}();var Rc=new Da,Sc={},Vc={set:function(a,b){Pa(Tc(a,b),Sc)},get:function(a){return Uc(a,2)},reset:function(){Rc=new Da;Sc={}}},Uc=function(a,b){return 2!=b?Rc.get(a):Wc(a)},Wc=function(a,b,c){var d=a.split(".");return Yc(d)},Yc=function(a){for(var b=Sc,c=0;c<a.length;c++){if(null===
b)return!1;if(void 0===b)break;b=b[a[c]]}return b};
var $c=function(a,b){Rc.set(a,b);Pa(Tc(a,b),Sc)},Tc=function(a,b){for(var c={},d=c,e=a.split("."),g=0;g<e.length-1;g++)d=d[e[g]]={};d[e[e.length-1]]=b;return c};var ad=new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),bd={customPixels:["nonGooglePixels"],html:["customScripts","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],customScripts:["html","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],nonGooglePixels:[],nonGoogleScripts:["nonGooglePixels"],nonGoogleIframes:["nonGooglePixels"]},cd={customPixels:["customScripts","html"],html:["customScripts"],customScripts:["html"],nonGooglePixels:["customPixels",
"customScripts","html","nonGoogleScripts","nonGoogleIframes"],nonGoogleScripts:["customScripts","html"],nonGoogleIframes:["customScripts","html","nonGoogleScripts"]},dd=function(a,b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]),c.push.apply(c,b[a[d]]||[]);return c};
var ed=function(a){var b=Uc("gtm.whitelist");var c=b&&dd(Ba(b),bd),d=Uc("gtm.blacklist")||Uc("tagTypeBlacklist")||[];
ad.test(z.location&&z.location.hostname)&&(d=Ba(d),d.push("nonGooglePixels","nonGoogleScripts"));var e=d&&dd(Ba(d),cd),g={};return function(h){var k=h&&h[P.P];if(!k||"string"!=typeof k)return!0;k=k.replace(/^_*/,"");if(void 0!==g[k])return g[k];var l=Oc[k]||[],m=a(k);if(b){var n;if(n=m)a:{if(0>va(c,k))if(l&&0<l.length)for(var p=0;p<l.length;p++){if(0>va(c,l[p])){n=!1;break a}}else{n=!1;break a}n=!0}m=n}var q=!1;if(d){var r;if(!(r=0<=
va(e,k)))a:{for(var u=l||[],t=new Da,A=0;A<e.length;A++)t.set(e[A],!0);for(var C=0;C<u.length;C++)if(t.get(u[C])){r=!0;break a}r=!1}q=r}return g[k]=!m||q}};var fd={sd:function(a,b){b[P.Kb]&&"string"===typeof a&&(a=1==b[P.Kb]?a.toLowerCase():a.toUpperCase());b.hasOwnProperty(P.Mb)&&null===a&&(a=b[P.Mb]);b.hasOwnProperty(P.Ob)&&void 0===a&&(a=b[P.Ob]);b.hasOwnProperty(P.Nb)&&!0===a&&(a=b[P.Nb]);b.hasOwnProperty(P.Lb)&&!1===a&&(a=b[P.Lb]);return a}};var gd=function(a,b){this.oe=b};ia(gd,Error);gd.prototype.getParameters=function(){return this.oe};var hd=function(a){var b=Jc.zones;!b&&a&&(b=Jc.zones=a());return b},id={active:!0,isWhitelisted:function(){return!0}};var jd=!1,kd=0,ld=[];function md(a){if(!jd){var b=B.createEventObject,c="complete"==B.readyState,d="interactive"==B.readyState;if(!a||"readystatechange"!=a.type||c||!b&&d){jd=!0;for(var e=0;e<ld.length;e++)H(ld[e])}ld.push=function(){for(var a=0;a<arguments.length;a++)H(arguments[a]);return 0}}}function nd(){if(!jd&&140>kd){kd++;try{B.documentElement.doScroll("left"),md()}catch(a){z.setTimeout(nd,50)}}}var od=function(a){jd?a():ld.push(a)};var pd=!1,rd=function(){return z.GoogleAnalyticsObject&&z[z.GoogleAnalyticsObject]};
var sd=function(){function a(a){return!ta(a)||0>a?0:a}if(z.performance&&z.performance.timing){var b=z.performance.timing.navigationStart,c=ta(Vc.get("gtm.start"))?Vc.get("gtm.start"):0;Jc._li={cst:a(c-b),cbt:a(Kc-b)}}},td=function(a){z.GoogleAnalyticsObject||(z.GoogleAnalyticsObject=a||"ga");var b=z.GoogleAnalyticsObject;if(!z[b]){var c=function(){c.q=c.q||[];c.q.push(arguments)};c.l=Number(Ca());z[b]=c}sd();return z[b]},ud=function(a,b,c,d){b=String(b).replace(/\s+/g,"").split(",");var e=rd();e(a+
"require","linker");e(a+"linker:autoLink",b,c,d)};
var yd=function(){return"&tc="+oc.filter(function(a){return a}).length},zd="0.005000">Math.random(),Ad=function(){var a=0,b=0;return{ae:function(){if(2>a)return!1;1E3<=Ca().getTime()-b&&(a=0);return 2<=a},ze:function(){1E3<=Ca().getTime()-b&&(a=0);a++;b=Ca().getTime()}}},Bd="",Cd=function(){Bd=[Mc,"&v=3&t=t","&pid="+xa(),"&rv=a1"].join("")},Dd={},Ed="",Fd=void 0,Gd={},Hd={},Id=void 0,Jd=null,Kd=1E3,Ld=function(){var a=Fd;return void 0===a?"":[Bd,Dd[a]?"":"&es=1",
Gd[a],yd(),Ed,"&z=0"].join("")},Md=function(){Id&&(z.clearTimeout(Id),Id=void 0);void 0===Fd||Dd[Fd]&&!Ed||(Hd[Fd]||Jd.ae()||0>=Kd--?Hd[Fd]=!0:(Jd.ze(),F(Ld()),Dd[Fd]=!0,Ed=""))},Nd=function(a,b,c){if(zd&&!Hd[a]&&b){a!==Fd&&(Md(),Fd=a);var d=c+String(b[P.P]||"").replace(/_/g,"");Ed=Ed?Ed+"."+d:"&tr="+d;Id||(Id=z.setTimeout(Md,500));2022<=Ld().length&&Md()}};function Od(a,b,c,d,e,g){var h=oc[a],k=Pd(a,b,c,d,e,g);if(!k)return null;var l=vc(h[P.Rb],g.Y,[],Qd());if(l&&l.length){var m=l[0];k=Od(m.index,b,k,1===m.bc?e:k,e,g)}return k}
function Pd(a,b,c,d,e,g){function h(){var b=wc(k,g.Y,[],l);b.vtp_gtmOnSuccess=function(){Nd(g.id,oc[a],"5");c()};b.vtp_gtmOnFailure=function(){Nd(g.id,oc[a],"6");d()};b.vtp_gtmTagId=k.tag_id;if(k[P.Nc])d();else{Nd(g.id,k,"1");try{uc(b)}catch(C){Nd(g.id,
k,"7");e()}}}var k=oc[a];if(g.Y(k))return null;var l=Qd(),m=vc(k[P.Sb],g.Y,[],l);if(m&&m.length){var n=m[0],p=Od(n.index,b,c,d,e,g);if(!p)return null;c=p;d=2===n.bc?e:p}if(k[P.Qb]||k[P.Oc]){var q=k[P.Qb]?pc:b,r=c,u=d;if(!q[a]){h=Fa(h);var t=Rd(a,q,h);c=t.U;d=t.la}return function(){q[a](r,u)}}return h}
function Rd(a,b,c){var d=[],e=[];b[a]=Sd(d,e,c);return{U:function(){b[a]=Td;for(var c=0;c<d.length;c++)d[c]()},la:function(){b[a]=Ud;for(var c=0;c<e.length;c++)e[c]()}}}function Sd(a,b,c){return function(d,e){a.push(d);b.push(e);c()}}function Td(a){a()}function Ud(a,b){b()}function Qd(){return function(){}};function Vd(a){var b=0,c=0,d=!1;return{add:function(){c++;return Fa(function(){b++;d&&b>=c&&a()})},$c:function(){d=!0;b>=c&&a()}}}function Wd(a,b){var c,d=b.b,e=a.b;c=d>e?1:d<e?-1:0;var g;if(0!==c)g=c;else{var h=a.Jc,k=b.Jc;g=h>k?1:h<k?-1:0}return g}
function Xd(a,b){if(!zd)return;var c=function(a){var d=b.Y(oc[a])?"3":"4",g=vc(oc[a][P.Rb],b.Y,[],qa);g&&g.length&&c(g[0].index);Nd(b.id,oc[a],d);var h=vc(oc[a][P.Sb],b.Y,[],qa);h&&h.length&&c(h[0].index)};c(a);}var Yd=!1;function Dc(){return function(){}};var Zd=function(a,b){var c={};c[P.P]="__"+a;for(var d in b)b.hasOwnProperty(d)&&(c["vtp_"+d]=b[d]);for(d in void 0)(void 0).hasOwnProperty(d)&&(c[d]=(void 0)[d]);oc.push(c);return oc.length-1};var $d="allow_ad_personalization_signals cookie_domain cookie_expires cookie_name cookie_path custom_params event_callback event_timeout groups send_to send_page_view session_duration user_properties".split(" ");var ae=/[A-Z]+/,be=/\s/,ce=function(a){if(sa(a)&&(a=a.trim(),!be.test(a))){var b=a.indexOf("-");if(!(0>b)){var c=a.substring(0,b);if(ae.test(c)){for(var d=a.substring(b+1).split("/"),e=0;e<d.length;e++)if(!d[e])return;return{id:a,prefix:c,containerId:c+"-"+d[0],X:d}}}}};var de=null,ee={},fe={},ge;function he(){de=de||!Jc.gtagRegistered;Jc.gtagRegistered=!0;return de}var ie=function(a,b){var c={event:a};b&&(c.eventModel=Pa(b),b.event_callback&&(c.eventCallback=b.event_callback),b.event_timeout&&(c.eventTimeout=b.event_timeout));return c};
function je(a){if(void 0===fe[a.id]){var b;if("UA"==a.prefix)b=Zd("gtagua",{trackingId:a.id});else if("AW"==a.prefix)b=Zd("gtagaw",{conversionId:a});else if("DC"==a.prefix)b=Zd("gtagfl",{targetId:a.id});else if("GF"==a.prefix)b=Zd("gtaggf",{conversionId:a});else if("G"==a.prefix)b=Zd("get",{trackingId:a.id,isAutoTag:!0});else if("HA"==a.prefix)b=Zd("gtagha",{conversionId:a});else return;if(!ge){var c={name:"send_to",dataLayerVersion:2},d={};d[P.P]="__v";for(var e in c)c.hasOwnProperty(e)&&(d["vtp_"+
e]=c[e]);lc.push(d);ge=["macro",lc.length-1]}var g={arg0:ge,arg1:a.id,ignore_case:!1};g[P.P]="_lc";nc.push(g);var h={"if":[nc.length-1],add:[b]};h["if"]&&(h.add||h.block)&&mc.push(h);fe[a.id]=b}}
var le={event:function(a){var b=a[1];if(sa(b)&&!(3<a.length)){var c;if(2<a.length){if(!Oa(a[2]))return;c=a[2]}var d=ie(b,c);return d}},set:function(a){var b;2==a.length&&Oa(a[1])?
b=Pa(a[1]):3==a.length&&sa(a[1])&&(b={},b[a[1]]=a[2]);if(b)return b.eventModel=Pa(b),b.event="gtag.set",b._clear=!0,b},js:function(a){if(2==a.length&&a[1].getTime)return{event:"gtm.js","gtm.start":a[1].getTime()}},config:function(a){}},ke=Fa(function(){});var me=!1,ne=[];function oe(){if(!me){me=!0;for(var a=0;a<ne.length;a++)H(ne[a])}};var pe=[],qe=!1,re=function(a){var b=a.eventCallback,c=Fa(function(){ra(b)&&H(function(){b(Ic.s)})}),d=a.eventTimeout;d&&z.setTimeout(c,Number(d));return c},se=function(){for(var a=!1;!qe&&0<pe.length;){qe=!0;delete Sc.eventModel;var b=pe.shift();if(ra(b))try{b.call(Vc)}catch(De){}else if(ua(b)){var c=b;if(sa(c[0])){var d=c[0].split("."),e=d.pop(),g=c.slice(1),h=Uc(d.join("."),2);if(void 0!==h&&null!==h)try{h[e].apply(h,g)}catch(De){}}}else{var k=b;if(k&&("[object Arguments]"==Object.prototype.toString.call(k)||
Object.prototype.hasOwnProperty.call(k,"callee"))){a:{if(b.length&&sa(b[0])){var l=le[b[0]];if(l){b=l(b);break a}}b=void 0}if(!b){qe=!1;continue}}var m;var n=void 0,p=b,q=p._clear;for(n in p)p.hasOwnProperty(n)&&"_clear"!==n&&(q&&$c(n,void 0),$c(n,p[n]));var r=p.event;if(r){var u=p["gtm.uniqueEventId"];u||(u=Qc(),p["gtm.uniqueEventId"]=u,$c("gtm.uniqueEventId",u));Lc=r;var t;var A,C,D=p,L=D.event,E=D["gtm.uniqueEventId"],G=Jc.zones;C=G?G.checkState(Ic.s,E):id;if(C.active){var J=re(D);c:{var I=C.isWhitelisted;
if("gtm.js"==L){if(Yd){A=!1;break c}Yd=!0}var K=E,R=L;if(zd&&!Hd[K]&&Fd!==K){Md();Fd=K;Ed="";var ja=Gd,W=K,aa,M=R;aa=0===M.indexOf("gtm.")?encodeURIComponent(M):"*";ja[W]="&e="+aa+"&eid="+K;Id||(Id=z.setTimeout(Md,500))}var S=ed(I),O={id:E,name:L,callback:J||qa,Y:S,Da:[]};O.Da=Fc(S);for(var za,Za=O,Ub=Vd(Za.callback),zc=[],jb=[],$a=0;$a<oc.length;$a++)if(Za.Da[$a]){var Ee=oc[$a];var Vb=Ub.add();try{var Fe=Od($a,zc,Vb,Vb,Vb,Za);Fe?jb.push({Jc:$a,b:xc(Ee),L:Fe}):(Xd($a,Za),Vb())}catch(De){Vb()}}Ub.$c();jb.sort(Wd);for(var qd=0;qd<jb.length;qd++)jb[qd].L();za=0<jb.length;if("gtm.js"===L||"gtm.sync"===L)d:{}if(za){for(var Lg={__cl:!0,__evl:!0,__fsl:!0,__hl:!0,__jel:!0,__lcl:!0,__sdl:!0,__tl:!0,__ytl:!0},Ac=0;Ac<O.Da.length;Ac++)if(O.Da[Ac]){var He=oc[Ac];if(He&&!Lg[He[P.P]]){A=!0;break c}}A=!1}else A=za}t=A?!0:!1}else t=!1;Lc=null;m=t}else m=!1;a=m||a}qe=!1}return!a},te=function(){var a=se();try{var b=z["dataLayer"].hide;if(b&&void 0!==b[Ic.s]&&b.end){b[Ic.s]=!1;var c=!0,d;for(d in b)if(b.hasOwnProperty(d)&&
!0===b[d]){c=!1;break}c&&(b.end(),b.end=null)}}catch(e){}return a},ue=function(){var a=db("dataLayer",[]),b=db("google_tag_manager",{});b=b["dataLayer"]=b["dataLayer"]||{};ld.push(function(){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))});ne.push(function(){b.gtmLoad||(b.gtmLoad=!0,a.push({event:"gtm.load"}))});var c=a.push;a.push=function(){var b=[].slice.call(arguments,0);c.apply(a,b);for(pe.push.apply(pe,b);300<this.length;)this.shift();return se()};pe.push.apply(pe,a.slice(0));
H(te)};var ve={};ve.Ia=new String("undefined");ve.ab={};var we=function(a){this.resolve=function(b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]===ve.Ia?b:a[d]);return c.join("")}};we.prototype.toString=function(){return this.resolve("undefined")};we.prototype.valueOf=we.prototype.toString;ve.td=function(a){return new we(a)};var xe={};ve.Ae=function(a,b){var c=Qc();xe[c]=[a,b];return c};ve.Yb=function(a){var b=a?0:1;return function(a){var c=xe[a];if(c&&"function"===typeof c[b])c[b]();xe[a]=void 0}};
ve.$d=function(a){for(var b=!1,c=!1,d=2;d<a.length;d++)b=b||8===a[d],c=c||16===a[d];return b&&c};ve.se=function(a){if(a===ve.Ia)return a;var b=Qc();ve.ab[b]=a;return'google_tag_manager["'+Ic.s+'"].macro('+b+")"};ve.Qc=we;var ye=new Da,ze=function(a,b){function c(a){var b=N(a),c=sb(b,"protocol"),d=sb(b,"host",!0),e=sb(b,"port"),g=sb(b,"path").toLowerCase().replace(/\/$/,"");if(void 0===c||"http"==c&&"80"==e||"https"==c&&"443"==e)c="web",e="default";return[c,d,e,g]}for(var d=c(String(a)),e=c(String(b)),g=0;g<d.length;g++)if(d[g]!==e[g])return!1;return!0};
function Ae(a){var b=a.arg0,c=a.arg1;switch(a["function"]){case "_cn":return 0<=String(b).indexOf(String(c));case "_css":var d;a:{if(b){var e=["matches","webkitMatchesSelector","mozMatchesSelector","msMatchesSelector","oMatchesSelector"];try{for(var g=0;g<e.length;g++)if(b[e[g]]){d=b[e[g]](c);break a}}catch(u){}}d=!1}return d;case "_ew":var h,k;h=String(b);k=String(c);var l=h.length-k.length;return 0<=l&&h.indexOf(k,l)==l;case "_eq":return String(b)==String(c);case "_ge":return Number(b)>=Number(c);
case "_gt":return Number(b)>Number(c);case "_lc":var m;m=String(b).split(",");return 0<=va(m,String(c));case "_le":return Number(b)<=Number(c);case "_lt":return Number(b)<Number(c);case "_re":var n;var p=a.ignore_case?"i":void 0;try{var q=String(c)+p,r=ye.get(q);r||(r=new RegExp(c,p),ye.set(q,r));n=r.test(b)}catch(u){n=!1}return n;case "_sw":return 0==String(b).indexOf(String(c));case "_um":return ze(b,c)}return!1};var Be=function(){return!1};function Ce(a,b,c,d){return(d||"https:"==z.location.protocol?a:b)+c}function Ie(a,b){for(var c=b||(a instanceof v?new v:new Ka),d=a.T(),e=0;e<d.length();e++){var g=d.get(e);if(a.has(g)){var h=a.get(g);h instanceof v?(c.get(g)instanceof v||c.set(g,new v),Ie(h,c.get(g))):h instanceof Ka?(c.get(g)instanceof Ka||c.set(g,new Ka),Ie(h,c.get(g))):c.set(g,h)}}return c}function Je(){return Ic.s}function Ke(){return(new Date).getTime()}function Le(a,b){return Ra(Uc(a,b||2))}function Me(){return Lc}
function Ne(a){return nb('<a href="'+a+'"></a>')[0].href}function Oe(a){return ya(Qa(a))}function Pe(a){return null===a?"null":void 0===a?"undefined":a.toString()}function Qe(a,b){return xa(a,b)}function Re(a,b,c){if(!(a instanceof v))return null;for(var d=new Ka,e=!1,g=0;g<a.length();g++){var h=a.get(g);h instanceof Ka&&h.has(b)&&h.has(c)&&(d.set(h.get(b),h.get(c)),e=!0)}return e?d:null}
var Se=function(){var a=new bb,b=ub();Be()&&(b.loadJavaScript=qa,b.loadIframe=qa);a.addAll(b);a.addAll({buildSafeUrl:Ce,copy:Ie,copyFromDataLayer:Le,decodeHtmlUrl:Ne,generateRandom:Qe,generateUniqueNumber:Qc,getContainerId:Je,getCurrentTime:Ke,getEventName:Me,makeInteger:Oe,makeString:Pe,tableToMap:Re});return function(b){return a.get(b)}},Ue=function(){var a={networkAccess:Te};return function(b,c,d){return a[b]?a[b](c,d):qa}};
function Te(a,b){var c=a.url_list||[];return function(a,e){if(c.length){for(var d=0;d<c.length;d++)if(c[d]===e)return;throw b(a,{URL:e});}}};var Ve,Xe=function(){var a=data.runtime||[],b=data.permissions||{};Ve=new wb;kc=function(a,b){var c=new Ka,d;for(d in b)b.hasOwnProperty(d)&&c.set(d,Ra(b[d]));var e=Ve.L([a,c]);e instanceof f&&"return"===e.C&&(e=e.getData());return Qa(e)};rc=Ae;vb(Ve,Se());for(var c=0;c<a.length;c++){var d=a[c];if(!ua(d)||3>d.length){if(0==d.length)continue;return}Ve.L(d)}var e=function(a){throw We(a,{},"The requested permission is not configured.");};Ve.oa(e);var g=Ue(),h;for(h in b)if(b.hasOwnProperty(h)){var k=
b[h],l=!1,m;for(m in k)if(k.hasOwnProperty(m)){l=!0;var n=g(m,k[m],We);Ve.Na(h,m,n)}l||Ve.Na(h,"default",e)}};function We(a,b,c){return new gd(a,b,c)};var Ye=function(a,b){var c=function(){};c.prototype=a.prototype;var d=new c;a.apply(d,Array.prototype.slice.call(arguments,1));return d};var Ze=function(a){return encodeURIComponent(a)},$e=function(a,b){if(!a)return!1;var c=sb(N(a),"host");if(!c)return!1;for(var d=0;b&&d<b.length;d++){var e=b[d]&&b[d].toLowerCase();if(e){var g=c.length-e.length;0<g&&"."!=e.charAt(0)&&(g--,e="."+e);if(0<=g&&c.indexOf(e,g)==g)return!0}}return!1};
var Q=function(a,b,c){for(var d={},e=!1,g=0;a&&g<a.length;g++)a[g]&&a[g].hasOwnProperty(b)&&a[g].hasOwnProperty(c)&&(d[a[g][b]]=a[g][c],e=!0);return e?d:null},af=function(a,b){Pa(a,b)},bf=function(a){return ya(a)},cf=function(a,b){return va(a,b)};var df=function(a){var b={"gtm.element":a,"gtm.elementClasses":a.className,"gtm.elementId":a["for"]||kb(a,"id")||"","gtm.elementTarget":a.formTarget||a.target||""};b["gtm.elementUrl"]=(a.attributes&&a.attributes.formaction?a.formAction:"")||a.action||a.href||a.src||a.code||a.codebase||"";return b},ef=function(a){Jc.hasOwnProperty("autoEventsSettings")||(Jc.autoEventsSettings={});var b=Jc.autoEventsSettings;b.hasOwnProperty(a)||(b[a]={});return b[a]},ff=function(a,b,c,d){var e=ef(a),g=Ea(e,b,d);e[b]=
c(g)},gf=function(a,b,c){var d=ef(a);return Ea(d,b,c)};var hf=!1;if(B.querySelectorAll)try{var jf=B.querySelectorAll(":root");jf&&1==jf.length&&jf[0]==B.documentElement&&(hf=!0)}catch(a){}var kf=hf;var lf=function(a,b,c){for(var d=[],e=String(b||document.cookie).split(";"),g=0;g<e.length;g++){var h=e[g].split("="),k=h[0].replace(/^\s*|\s*$/g,"");if(k&&k==a){var l=h.slice(1).join("=").replace(/^\s*|\s*$/g,"");l&&!0===c&&(l=decodeURIComponent(l));d.push(l)}}return d},of=function(a,b,c,d){var e=mf(a,d);if(1===e.length)return e[0].id;if(0!==e.length){e=nf(e,function(a){return a.Bd},b);if(1===e.length)return e[0].id;e=nf(e,function(a){return a.pe},c);return e[0]?e[0].id:void 0}},rf=function(a,b,
c,d,e,g){c=c||"/";var h=d=d||"auto",k=c;if(pf.test(document.location.hostname)||"/"===k&&qf.test(h))return!1;g&&(b=encodeURIComponent(b));var l=b;l&&1200<l.length&&(l=l.substring(0,1200));b=l;var m=a+"="+b+"; path="+c+"; ";void 0!==e&&(m+="expires="+e.toGMTString()+"; ");if("auto"===d){var n=!1,p;a:{var q=[],r=document.location.hostname.split(".");if(4===r.length){var u=r[r.length-1];if(parseInt(u,10).toString()===u){p=["none"];break a}}for(var t=r.length-2;0<=t;t--)q.push(r.slice(t).join("."));q.push("none");
p=q}for(var A=p,C=0;C<A.length&&!n;C++)n=rf(a,b,c,A[C],e);return n}d&&"none"!==d&&(m+="domain="+d+";");var D=document.cookie;document.cookie=m;return D!=document.cookie||0<=lf(a).indexOf(b)};function nf(a,b,c){for(var d=[],e=[],g,h=0;h<a.length;h++){var k=a[h],l=b(k);l===c?d.push(k):void 0===g||l<g?(e=[k],g=l):l===g&&e.push(k)}return 0<d.length?d:e}
function mf(a,b){for(var c=[],d=lf(a),e=0;e<d.length;e++){var g=d[e].split("."),h=g.shift();if(!b||-1!==b.indexOf(h)){var k=g.shift();k&&(k=k.split("-"),c.push({id:g.join("."),Bd:1*k[0]||1,pe:1*k[1]||1}))}}return c}var qf=/^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,pf=/(^|\.)doubleclick\.net$/i;var sf=window,tf=document;var uf=function(){for(var a=sf.navigator.userAgent+(tf.cookie||"")+(tf.referrer||""),b=a.length,c=sf.history.length;0<c;)a+=c--^b++;var d=1,e,g,h;if(a)for(d=0,g=a.length-1;0<=g;g--)h=a.charCodeAt(g),d=(d<<6&268435455)+h+(h<<14),e=d&266338304,d=0!=e?d^e>>21:d;return[Math.round(2147483647*Math.random())^d&2147483647,Math.round(Ca().getTime()/1E3)].join(".")},xf=function(a,b,c,d){var e=vf(b);return of(a,e,wf(c),d)};
function vf(a){if(!a)return 1;a=0===a.indexOf(".")?a.substr(1):a;return a.split(".").length}function wf(a){if(!a||"/"===a)return 1;"/"!==a[0]&&(a="/"+a);"/"!==a[a.length-1]&&(a+="/");return a.split("/").length-1}function yf(a,b){var c=""+vf(a),d=wf(b);1<d&&(c+="-"+d);return c};var zf=["1"],Af={},Ef=function(a,b,c){var d=Bf(a);Af[d]||Cf(d,b,c)||(Df(d,uf(),b,c),Cf(d,b,c))};function Df(a,b,c,d){var e;e=["1",yf(c,d),b].join(".");rf(a,e,d,c,new Date(Ca().getTime()+7776E6))}function Cf(a,b,c){var d=xf(a,b,c,zf);d&&(Af[a]=d);return d}function Bf(a){return(a||"_gcl")+"_au"};function Ff(){for(var a=Gf,b={},c=0;c<a.length;++c)b[a[c]]=c;return b}function Hf(){var a="ABCDEFGHIJKLMNOPQRSTUVWXYZ";a+=a.toLowerCase()+"0123456789-_";return a+"."}
var Gf,If,Jf=function(a){Gf=Gf||Hf();If=If||Ff();for(var b=[],c=0;c<a.length;c+=3){var d=c+1<a.length,e=c+2<a.length,g=a.charCodeAt(c),h=d?a.charCodeAt(c+1):0,k=e?a.charCodeAt(c+2):0,l=g>>2,m=(g&3)<<4|h>>4,n=(h&15)<<2|k>>6,p=k&63;e||(p=64,d||(n=64));b.push(Gf[l],Gf[m],Gf[n],Gf[p])}return b.join("")},Kf=function(a){function b(b){for(;d<a.length;){var c=a.charAt(d++),e=If[c];if(null!=e)return e;if(!/^[\s\xa0]*$/.test(c))throw Error("Unknown base64 encoding at char: "+c);}return b}Gf=Gf||Hf();If=If||
Ff();for(var c="",d=0;;){var e=b(-1),g=b(0),h=b(64),k=b(64);if(64===k&&-1===e)return c;c+=String.fromCharCode(e<<2|g>>4);64!=h&&(c+=String.fromCharCode(g<<4&240|h>>2),64!=k&&(c+=String.fromCharCode(h<<6&192|k)))}};var Lf;function Mf(a,b){if(!a||b===B.location.hostname)return!1;for(var c=0;c<a.length;c++)if(a[c]instanceof RegExp){if(a[c].test(b))return!0}else if(0<=b.indexOf(a[c]))return!0;return!1}var Nf=function(){var a=db("google_tag_data",{}),b=a.gl;b&&b.decorators||(b={decorators:[]},a.gl=b);return b};var Of=/(.*?)\*(.*?)\*(.*)/,Pf=/([^?#]+)(\?[^#]*)?(#.*)?/,Qf=/(.*?)(^|&)_gl=([^&]*)&?(.*)/,Sf=function(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];void 0!==d&&d===d&&null!==d&&"[object Object]"!==d.toString()&&(b.push(c),b.push(Jf(String(d))))}var e=b.join("*");return["1",Rf(e),e].join("*")},Rf=function(a,b){var c=[window.navigator.userAgent,(new Date).getTimezoneOffset(),window.navigator.userLanguage||window.navigator.language,Math.floor((new Date).getTime()/60/1E3)-(void 0===b?0:
b),a].join("*"),d;if(!(d=Lf)){for(var e=Array(256),g=0;256>g;g++){for(var h=g,k=0;8>k;k++)h=h&1?h>>>1^3988292384:h>>>1;e[g]=h}d=e}Lf=d;for(var l=4294967295,m=0;m<c.length;m++)l=l>>>8^Lf[(l^c.charCodeAt(m))&255];return((l^-1)>>>0).toString(36)},Uf=function(){return function(a){var b=N(z.location.href),c=b.search.replace("?",""),d=rb(c,"_gl",!0)||"";a.query=Tf(d)||{};var e=sb(b,"fragment").match(Qf);a.fragment=Tf(e&&e[3]||"")||{}}},Tf=function(a){var b;b=void 0===b?3:b;try{if(a){var c=Of.exec(a);if(c&&
"1"===c[1]){var d=c[3],e;a:{for(var g=c[2],h=0;h<b;++h)if(g===Rf(d,h)){e=!0;break a}e=!1}if(e){for(var k={},l=d?d.split("*"):[],m=0;m<l.length;m+=2)k[l[m]]=Kf(l[m+1]);return k}}}}catch(n){}};
function Vf(a,b,c){function d(a){var b=a,c=Qf.exec(b),d=b;if(c){var e=c[2],g=c[4];d=c[1];g&&(d=d+e+g)}a=d;var h=a.charAt(a.length-1);a&&"&"!==h&&(a+="&");return a+l}c=void 0===c?!1:c;var e=Pf.exec(b);if(!e)return"";var g=e[1],h=e[2]||"",k=e[3]||"",l="_gl="+a;c?k="#"+d(k.substring(1)):h="?"+d(h.substring(1));return""+g+h+k}
function Wf(a,b,c){for(var d={},e={},g=Nf().decorators,h=0;h<g.length;++h){var k=g[h];(!c||k.forms)&&Mf(k.domains,b)&&(k.fragment?Ga(e,k.callback()):Ga(d,k.callback()))}if(Ha(d)){var l=Sf(d);if(c){if(a&&a.action){var m=(a.method||"").toLowerCase();if("get"===m){for(var n=a.childNodes||[],p=!1,q=0;q<n.length;q++){var r=n[q];if("_gl"===r.name){r.setAttribute("value",l);p=!0;break}}if(!p){var u=B.createElement("input");u.setAttribute("type","hidden");u.setAttribute("name","_gl");u.setAttribute("value",
l);a.appendChild(u)}}else if("post"===m){var t=Vf(l,a.action);pb.test(t)&&(a.action=t)}}}else Xf(l,a,!1)}if(!c&&Ha(e)){var A=Sf(e);Xf(A,a,!0)}}function Xf(a,b,c){if(b.href){var d=Vf(a,b.href,void 0===c?!1:c);pb.test(d)&&(b.href=d)}}
var Yf=function(a){try{var b;a:{for(var c=a.target||a.srcElement||{},d=100;c&&0<d;){if(c.href&&c.nodeName.match(/^a(?:rea)?$/i)){b=c;break a}c=c.parentNode;d--}b=null}var e=b;if(e){var g=e.protocol;"http:"!==g&&"https:"!==g||Wf(e,e.hostname,!1)}}catch(h){}},Zf=function(a){try{var b=a.target||a.srcElement||{};if(b.action){var c=sb(N(b.action),"host");Wf(b,c,!0)}}catch(d){}},$f=function(a,b,c,d){var e=Nf();e.init||(hb(B,"mousedown",Yf),hb(B,"keyup",Yf),hb(B,"submit",Zf),e.init=!0);var g={callback:a,
domains:b,fragment:"fragment"===c,forms:!!d};Nf().decorators.push(g)};var ag=/^\w+$/,bg=/^[\w-]+$/,cg=/^~?[\w-]+$/,dg={aw:"_aw",dc:"_dc",gf:"_gf",ha:"_ha"},fg=function(a){var b=lf(a,B.cookie),c=[];if(!b||0==b.length)return c;for(var d=0;d<b.length;d++){var e=b[d].split(".");3==e.length&&"GCL"==e[0]&&e[1]&&c.push(e[2])}return eg(c)};function gg(a){return a&&"string"==typeof a&&a.match(ag)?a:"_gcl"}
var hg=function(a){if(a){if("string"==typeof a){var b=gg(a);return{dc:b,aw:b,gf:b,ha:b}}if(a&&"object"==typeof a)return{dc:gg(a.dc),aw:gg(a.aw),gf:gg(a.gf),ha:gg(a.ha)}}return{dc:"_gcl",aw:"_gcl",gf:"_gcl",ha:"_gcl"}},ig=function(){var a=N(z.location.href),b={},c=function(a,c){b[c]||(b[c]=[]);b[c].push(a)},d=sb(a,"query",!1,void 0,"gclid"),e=sb(a,"query",!1,void 0,"gclsrc");if(!d||!e){var g=a.hash.replace("#","");d=d||rb(g,"gclid");e=e||rb(g,"gclsrc")}if(void 0!==d&&d.match(bg))switch(e){case void 0:c(d,
"aw");break;case "aw.ds":c(d,"aw");c(d,"dc");break;case "ds":c(d,"dc");break;case "gf":c(d,"gf");break;case "ha":c(d,"ha")}var h=sb(a,"query",!1,void 0,"dclid");h&&c(h,"dc");return b},kg=function(a){function b(a,b){var g=jg(a,c);g&&rf(g,b,e,d,h,!0)}a=a||{};var c=hg(a.prefix),d=a.domain||"auto",e=a.path||"/",g=Ca().getTime(),h=new Date(g+7776E6),k=Math.round(g/1E3),l=ig(),m=function(a){return["GCL",k,a].join(".")};l.aw&&(!0===a.vf?b("aw",m("~"+l.aw[0])):b("aw",m(l.aw[0])));l.dc&&b("dc",m(l.dc[0]));
l.gf&&b("gf",m(l.gf[0]));l.ha&&b("ha",m(l.ha[0]))},jg=function(a,b){var c=dg[a];if(void 0!==c){var d=b[a];if(void 0!==d)return d+c}},lg=function(a){var b=a.split(".");return 3!==b.length||"GCL"!==b[0]?0:1E3*(Number(b[1])||0)},mg=function(a,b,c,d,e){if(ua(b)){var g=hg(e);$f(function(){for(var b={},c=0;c<a.length;++c){var d=jg(a[c],g);if(d){var e=lf(d,B.cookie);e.length&&(b[d]=e.sort()[e.length-1])}}return b},b,c,d)}},eg=function(a){return a.filter(function(a){return cg.test(a)})};var ng=/^\d+\.fls\.doubleclick\.net$/;function og(a){var b=N(z.location.href),c=sb(b,"host",!1);if(c&&c.match(ng)){var d=sb(b,"path").split(a+"=");if(1<d.length)return d[1].split(";")[0].split("?")[0]}}
var pg=function(a){var b=og("gclaw");if(b)return b.split(".");var c=hg(a);if("_gcl"==c.aw){var d=ig().aw||[];if(0<d.length)return d}var e=jg("aw",c);return e?fg(e):[]},qg=function(a){var b=og("gcldc");if(b)return b.split(".");var c=hg(a);if("_gcl"==c.dc){var d=ig().dc||[];if(0<d.length)return d}var e=jg("dc",c);return e?fg(e):[]},rg=function(a){var b=hg(a);if("_gcl"==b.ha){var c=ig().ha||[];if(0<c.length)return c}return fg(b.ha+"_ha")},sg=function(){var a=og("gac");if(a)return decodeURIComponent(a);
for(var b=[],c=B.cookie.split(";"),d=/^\s*_gac_(UA-\d+-\d+)=\s*(.+?)\s*$/,e=0;e<c.length;e++){var g=c[e].match(d);g&&b.push({Cb:g[1],value:g[2]})}var h={};if(b&&b.length)for(var k=0;k<b.length;k++){var l=b[k].value.split(".");"1"==l[0]&&3==l.length&&l[1]&&(h[b[k].Cb]||(h[b[k].Cb]=[]),h[b[k].Cb].push({timestamp:l[1],Id:l[2]}))}var m=[],n;for(n in h)if(h.hasOwnProperty(n)){for(var p=[],q=h[n],r=0;r<q.length;r++)p.push(q[r].Id);p=eg(p);p.length&&m.push(n+":"+p.join(","))}return m.join(";")},tg=function(a,
b,c){Ef(a,b,c);var d=Af[Bf(a)],e=ig().dc||[];if(d&&0<e.length){var g=Jc.joined_au=Jc.joined_au||{},h=a||"_gcl";if(!g[h]){for(var k=!1,l=0;l<e.length;l++){var m="https://adservice.google.com/ddm/regclk";m+="?gclid="+e[l]+"&auiddc="+d;ob(m);k=!0}if(k){var n=Bf(a);Af[n]&&Df(n,Af[n],b,c);g[h]=!0}}}};var ug;a:{ug="G"}var vg={"":"n",UA:"u",AW:"a",DC:"d",G:"e",GTM:ug},wg=function(a){var b=Ic.s.split("-"),c=b[0].toUpperCase();return(vg[c]||"i")+"a1"+(a&&"GTM"===c?b[1]:"")};var Dg=!!z.MutationObserver,Eg=void 0,Fg=function(a){if(!Eg){var b=function(){var a=B.body;if(a)if(Dg)(new MutationObserver(function(){for(var a=0;a<Eg.length;a++)H(Eg[a])})).observe(a,{childList:!0,subtree:!0});else{var b=!1;hb(a,"DOMNodeInserted",function(){b||(b=!0,H(function(){b=!1;for(var a=0;a<Eg.length;a++)H(Eg[a])}))})}};Eg=[];B.body?b():H(b)}Eg.push(a)};
var Gg=function(){var a=B.body,b=B.documentElement||a&&a.parentElement,c,d;if(B.compatMode&&"BackCompat"!==B.compatMode)c=b?b.clientHeight:0,d=b?b.clientWidth:0;else{var e=function(a,b){return a&&b?Math.min(a,b):Math.max(a,b)};c=e(b?b.clientHeight:0,a?a.clientHeight:0);d=e(b?b.clientWidth:0,a?a.clientWidth:0)}return{width:d,height:c}},Hg=function(a){var b=Gg(),c=b.height,d=b.width,e=a.getBoundingClientRect(),g=e.bottom-e.top,h=e.right-e.left;return g&&h?(1-Math.min((Math.max(0-e.left,0)+Math.max(e.right-
d,0))/h,1))*(1-Math.min((Math.max(0-e.top,0)+Math.max(e.bottom-c,0))/g,1)):0},Ig=function(a){if(B.hidden)return!0;var b=a.getBoundingClientRect();if(b.top==b.bottom||b.left==b.right||!z.getComputedStyle)return!0;var c=z.getComputedStyle(a,null);if("hidden"===c.visibility)return!0;for(var d=a,e=c;d;){if("none"===e.display)return!0;var g=e.opacity,h=e.filter;if(h){var k=h.indexOf("opacity(");0<=k&&(h=h.substring(k+8,h.indexOf(")",k)),"%"==h.charAt(h.length-1)&&(h=h.substring(0,h.length-1)),g=Math.min(h,
g))}if(void 0!==g&&0>=g)return!0;(d=d.parentElement)&&(e=z.getComputedStyle(d,null))}return!1};var Jg=[],Kg=!(!z.IntersectionObserver||!z.IntersectionObserverEntry),Mg=function(a,b,c){for(var d=new z.IntersectionObserver(a,{threshold:c}),e=0;e<b.length;e++)d.observe(b[e]);for(var g=0;g<Jg.length;g++)if(!Jg[g])return Jg[g]=d,g;return Jg.push(d)-1},Ng=function(a,b,c){function d(b,c){var d={top:0,bottom:0,right:0,left:0,width:0,height:0},e={boundingClientRect:b.getBoundingClientRect(),
intersectionRatio:c,intersectionRect:d,isIntersecting:0<c,rootBounds:d,target:b,time:Ca().getTime()};H(function(){return a(e)})}for(var e=[],g=[],h=0;h<b.length;h++)e.push(0),g.push(-1);c.sort(function(a,b){return a-b});return function(){for(var a=0;a<b.length;a++){var h=Hg(b[a]);if(h>e[a])for(;g[a]<c.length-1&&h>=c[g[a]+1];)d(b[a],h),g[a]++;else if(h<e[a])for(;0<=g[a]&&h<=c[g[a]];)d(b[a],h),g[a]--;e[a]=h}}},Og=function(a,b,c){for(var d=0;d<c.length;d++)1<c[d]?c[d]=1:0>c[d]&&(c[d]=0);if(Kg){var e=
!1;H(function(){e||Ng(a,b,c)()});return Mg(function(b){e=!0;for(var c={za:0};c.za<b.length;c={za:c.za},c.za++)H(function(c){return function(){return a(b[c.za])}}(c))},b,c)}return z.setInterval(Ng(a,b,c),1E3)};var Qg="www.googletagmanager.com/gtm.js";
var Rg=Qg,Sg=function(a,b,c,d){hb(a,b,c,d)},Tg=function(a,b){return z.setTimeout(a,b)},T=function(a,b,c){if(Be()){b&&H(b)}else return fb(a,b,c)},Ug=function(){return z.location.href},Vg=function(a){return sb(N(a),"fragment")},Wg=function(a,b,c,d,e){return sb(a,b,c,d,e)},U=function(a,b){return Uc(a,b||2)},Xg=function(a,b,c){b&&(a.eventCallback=b,c&&(a.eventTimeout=c));return z["dataLayer"].push(a)},Yg=function(a,
b){z[a]=b},V=function(a,b,c){b&&(void 0===z[a]||c&&!z[a])&&(z[a]=b);return z[a]},Zg=function(a,b,c){return lf(a,b,void 0===c?!0:!!c)},$g=function(a,b,c){kg({prefix:a,path:b,domain:c})},ah=function(a,b,c,d){var e=Uf(),g=Nf();g.data||(g.data={query:{},fragment:{}},e(g.data));var h={},k=g.data;k&&(Ga(h,k.query),Ga(h,k.fragment));for(var l=hg(b),m=0;m<a.length;++m){var n=a[m];if(void 0!==dg[n]){var p=jg(n,l),q=h[p];if(q){var r=Math.min(lg(q),Ca().getTime()),
u;b:{for(var t=r,A=lf(p,B.cookie),C=0;C<A.length;++C)if(lg(A[C])>t){u=!0;break b}u=!1}u||rf(p,q,c,d,new Date(r+7776E6),!0)}}}},bh=function(a,b,c,d,e){mg(a,b,c,d,e);},ch=function(a,b){var c;a:{var d;d=100;for(var e={},g=0;g<b.length;g++)e[b[g]]=!0;for(var h=a,k=0;h&&k<=d;k++){if(e[String(h.tagName).toLowerCase()]){c=h;break a}h=h.parentElement}c=null}return c},X=function(a,
b,c,d){var e=!d&&"http:"==z.location.protocol;e&&(e=2!==dh());return(e?b:a)+c},eh=function(a,b){if(Be()){b&&H(b)}else gb(a,b)};
var fh=function(a){var b=0;b=Hg(a);return b},gh=function(a){Kg?0<=a&&a<Jg.length&&Jg[a]&&(Jg[a].disconnect(),Jg[a]=void 0):z.clearInterval(a);},hh=function(a){var b=!1;b=Ig(a);return b},ih=function(a,b){var c;a:{if(a&&
ua(a))for(var d=0;d<a.length;d++)if(a[d]&&b(a[d])){c=a[d];break a}c=void 0}return c},jh=function(a,b,c,d){ff(a,b,c,d)},kh=function(a,b,c){return gf(a,b,c)},lh=function(a){return!!gf(a,"init",!1)},mh=function(a){ef(a).init=!0};
var dh=function(){var a=Rg;if(Pc){if(0===Pc.toLowerCase().indexOf("https://"))return 2;if(0===Pc.toLowerCase().indexOf("http://"))return 3}a=a.toLowerCase();for(var b="https://"+a,c="http://"+a,d=1,e=B.getElementsByTagName("script"),g=0;g<e.length&&100>g;g++){var h=e[g].src;if(h){h=h.toLowerCase();if(0===h.indexOf(c))return 3;1===d&&0===h.indexOf(b)&&(d=2)}}return d};
var qh=function(a,b,c){var d=(void 0===c?0:c)?"www.googletagmanager.com/gtag/js":Rg;d+="?id="+encodeURIComponent(a)+"&l=dataLayer";if(b)for(var e in b)b[e]&&b.hasOwnProperty(e)&&(d+="&"+e+"="+encodeURIComponent(b[e]));T(X("https://","http://",d))};
var sh=function(a,b,c){a instanceof ve.Qc&&(a=a.resolve(ve.Ae(b,c)),b=qa);return{mb:a,U:b}};var Fh=function(a,b,c){this.n=a;this.t=b;this.p=c},Gh=function(){this.c=1;this.e=[];this.p=null};function Hh(a){var b=Jc,c=b.gss=b.gss||{};return c[a]=c[a]||new Gh}var Ih=function(a,b){Hh(a).p=b},Jh=function(a,b,c){var d=Math.floor(Ca().getTime()/1E3);Hh(a).e.push(new Fh(b,d,c))},Kh=function(a){};var Th=window,Uh=document,Vh=function(a){var b=Th._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a&&!0===Th["ga-disable-"+a])return!0;try{var c=Th.external;if(c&&c._gaUserPrefs&&"oo"==c._gaUserPrefs)return!0}catch(g){}for(var d=lf("AMP_TOKEN",Uh.cookie,!0),e=0;e<d.length;e++)if("$OPT_OUT"==d[e])return!0;return!1};var $h=function(a){if(1===Hh(a).c){Hh(a).c=2;var b=encodeURIComponent(a);fb(("http:"!=z.location.protocol?"https:":"http:")+("//www.googletagmanager.com/gtag/js?id="+b+"&l=dataLayer&cx=c"))}},ai=function(a,b){};var Z={a:{}};
Z.a.jsm=["customScripts"],function(){(function(a){Z.__jsm=a;Z.__jsm.g="jsm";Z.__jsm.h=!0;Z.__jsm.b=0})(function(a){if(void 0!==a.vtp_javascript){var b=a.vtp_javascript;try{var c=V("google_tag_manager");return c&&c.e&&c.e(b)}catch(d){}}})}();Z.a.c=["google"],function(){(function(a){Z.__c=a;Z.__c.g="c";Z.__c.h=!0;Z.__c.b=0})(function(a){return a.vtp_value})}();
Z.a.e=["google"],function(){(function(a){Z.__e=a;Z.__e.g="e";Z.__e.h=!0;Z.__e.b=0})(function(){return Lc})}();Z.a.f=["google"],function(){(function(a){Z.__f=a;Z.__f.g="f";Z.__f.h=!0;Z.__f.b=0})(function(a){var b=U("gtm.referrer",1)||B.referrer;return b?a.vtp_component&&"URL"!=a.vtp_component?Wg(N(String(b)),a.vtp_component,a.vtp_stripWww,a.vtp_defaultPages,a.vtp_queryKey):tb(N(String(b))):String(b)})}();
Z.a.k=["google"],function(){(function(a){Z.__k=a;Z.__k.g="k";Z.__k.h=!0;Z.__k.b=0})(function(a){return Zg(a.vtp_name,U("gtm.cookie",1),!!a.vtp_decodeCookie)[0]})}();

Z.a.u=["google"],function(){var a=function(a){return{toString:function(){return a}}};(function(a){Z.__u=a;Z.__u.g="u";Z.__u.h=!0;Z.__u.b=0})(function(b){var c;c=(c=b.vtp_customUrlSource?b.vtp_customUrlSource:U("gtm.url",1))||Ug();var d=b[a("vtp_component")];return d&&"URL"!=d?Wg(N(String(c)),d,"HOST"==d?b[a("vtp_stripWww")]:void 0,"PATH"==d?b[a("vtp_defaultPages")]:void 0,"QUERY"==d?b[a("vtp_queryKey")]:void 0):tb(N(String(c)))})}();
Z.a.v=["google"],function(){(function(a){Z.__v=a;Z.__v.g="v";Z.__v.h=!0;Z.__v.b=0})(function(a){var b=a.vtp_name;if(!b||!b.replace)return!1;var c=U(b.replace(/\\\./g,"."),a.vtp_dataLayerVersion||1);return void 0!==c?c:a.vtp_defaultValue})}();
Z.a.ua=["google"],function(){var a,b=function(b){var c={},e={},g={},h={},k={};if(b.vtp_gaSettings){var l=b.vtp_gaSettings;af(Q(l.vtp_fieldsToSet,"fieldName","value"),e);af(Q(l.vtp_contentGroup,"index","group"),g);af(Q(l.vtp_dimension,"index","dimension"),h);af(Q(l.vtp_metric,"index","metric"),k);b.vtp_gaSettings=null;l.vtp_fieldsToSet=void 0;l.vtp_contentGroup=void 0;l.vtp_dimension=void 0;l.vtp_metric=void 0;var m=Pa(l,void 0);b=Pa(b,m)}af(Q(b.vtp_fieldsToSet,"fieldName","value"),e);af(Q(b.vtp_contentGroup,
"index","group"),g);af(Q(b.vtp_dimension,"index","dimension"),h);af(Q(b.vtp_metric,"index","metric"),k);var n=td(b.vtp_functionName),p="",q="";b.vtp_setTrackerName&&"string"==typeof b.vtp_trackerName?""!==b.vtp_trackerName&&(q=b.vtp_trackerName,p=q+"."):(q="gtm"+Qc(),p=q+".");var r={name:!0,clientId:!0,sampleRate:!0,siteSpeedSampleRate:!0,alwaysSendReferrer:!0,allowAnchor:!0,allowLinker:!0,cookieName:!0,cookieDomain:!0,cookieExpires:!0,cookiePath:!0,cookieUpdate:!0,legacyCookieDomain:!0,legacyHistoryImport:!0,
storage:!0,useAmpClientId:!0,storeGac:!0},u={allowAnchor:!0,allowLinker:!0,alwaysSendReferrer:!0,anonymizeIp:!0,cookieUpdate:!0,exFatal:!0,forceSSL:!0,javaEnabled:!0,legacyHistoryImport:!0,nonInteraction:!0,useAmpClientId:!0,useBeacon:!0,storeGac:!0,allowAdFeatures:!0},t=function(a){var b=[].slice.call(arguments,0);b[0]=p+b[0];n.apply(window,b)},A=function(a,b){return void 0===b?b:a(b)},C=function(a,b){if(b)for(var c in b)b.hasOwnProperty(c)&&t("set",a+c,b[c])},D=function(){
var a=function(a,b,c){if(!Oa(b))return!1;var d;d=Ea(Object(b),c,[]);for(var e=0;d&&e<d.length;e++)t(a,d[e]);return!!d&&0<d.length},c;b.vtp_useEcommerceDataLayer?c=U("ecommerce",1):b.vtp_ecommerceMacroData&&(c=b.vtp_ecommerceMacroData.ecommerce);if(!Oa(c))return;c=Object(c);var d=Ea(e,"currencyCode",c.currencyCode);void 0!==d&&t("set","&cu",d);a("ec:addImpression",c,"impressions");if(a("ec:addPromo",c[c.promoClick?"promoClick":"promoView"],"promotions")&&c.promoClick){t("ec:setAction","promo_click",
c.promoClick.actionField);return}for(var g="detail checkout checkout_option click add remove purchase refund".split(" "),h=0;h<g.length;h++){var k=c[g[h]];if(k){a("ec:addProduct",k,"products");t("ec:setAction",g[h],k.actionField);break}}},L=function(a,b,c){var d=0;if(a)for(var e in a)if(a.hasOwnProperty(e)&&(c&&r[e]||!c&&void 0===r[e])){var g=u[e]?Aa(a[e]):a[e];"anonymizeIp"!=e||g||(g=void 0);b[e]=g;d++}return d},E={name:q};L(e,E,
!0);n("create",b.vtp_trackingId||c.trackingId,E);t("set","&gtm",wg(!0));(function(a,c){void 0!==b[c]&&t("set",a,b[c])})("nonInteraction","vtp_nonInteraction");C("contentGroup",g);C("dimension",h);C("metric",k);var G={};L(e,G,!1)&&t("set",G);var J;b.vtp_enableLinkId&&t("require","linkid","linkid.js");t("set","hitCallback",function(){var a=
e&&e.hitCallback;ra(a)&&a();b.vtp_gtmOnSuccess()});if("TRACK_EVENT"==b.vtp_trackType){b.vtp_enableEcommerce&&(t("require","ec","ec.js"),D());var I={hitType:"event",eventCategory:String(b.vtp_eventCategory||c.category),eventAction:String(b.vtp_eventAction||c.action),eventLabel:A(String,b.vtp_eventLabel||c.label),eventValue:A(bf,b.vtp_eventValue||c.value)};L(J,I,!1);t("send",I);}else if("TRACK_SOCIAL"==
b.vtp_trackType){I={hitType:"social",socialNetwork:String(b.vtp_socialNetwork),socialAction:String(b.vtp_socialAction),socialTarget:String(b.vtp_socialActionTarget)},L(J,I,!1),t("send",I);}else if("TRACK_TRANSACTION"==b.vtp_trackType){}else if("TRACK_TIMING"==b.vtp_trackType){}else if("DECORATE_LINK"==b.vtp_trackType){}else if("DECORATE_FORM"==b.vtp_trackType){}else if("TRACK_DATA"==
b.vtp_trackType){}else{b.vtp_enableEcommerce&&(t("require","ec","ec.js"),D());if(b.vtp_doubleClick||"DISPLAY_FEATURES"==b.vtp_advertisingFeaturesType){var S="_dc_gtm_"+String(b.vtp_trackingId).replace(/[^A-Za-z0-9-]/g,"");t("require","displayfeatures",void 0,{cookieName:S})}"DISPLAY_FEATURES_WITH_REMARKETING_LISTS"==b.vtp_advertisingFeaturesType&&
(S="_dc_gtm_"+String(b.vtp_trackingId).replace(/[^A-Za-z0-9-]/g,""),t("require","adfeatures",{cookieName:S}));J?t("send","pageview",J):t("send","pageview");}if(!a){var O=b.vtp_useDebugVersion?"u/analytics_debug.js":"analytics.js";b.vtp_useInternalVersion&&!b.vtp_useDebugVersion&&
(O="internal/"+O);a=!0;T(X("https:","http:","//www.google-analytics.com/"+O,e&&e.forceSSL),function(){var a=rd();a&&a.loaded||b.vtp_gtmOnFailure();},b.vtp_gtmOnFailure)}};Z.__ua=b;Z.__ua.g="ua";Z.__ua.h=!0;Z.__ua.b=0}();

Z.a.jel=["google"],function(){(function(a){Z.__jel=a;Z.__jel.g="jel";Z.__jel.h=!0;Z.__jel.b=0})(function(a){if(!lh("jel")){var b=V("self"),c=b.onerror;b.onerror=function(a,b,d,k,l){c&&c(a,b,d,k,l);Xg({event:"gtm.pageError","gtm.errorMessage":a,"gtm.errorUrl":b,"gtm.errorLineNumber":d});return!1};var d=gf("jel","legacyTeardown",void 0);d&&d();mh("jel")}H(a.vtp_gtmOnSuccess)})}();


Z.a.aev=["google"],function(){var a=void 0,b="",c=0,d=void 0,e={ATTRIBUTE:"gtm.elementAttribute",CLASSES:"gtm.elementClasses",ELEMENT:"gtm.element",ID:"gtm.elementId",HISTORY_CHANGE_SOURCE:"gtm.historyChangeSource",HISTORY_NEW_STATE:"gtm.newHistoryState",HISTORY_NEW_URL_FRAGMENT:"gtm.newUrlFragment",HISTORY_OLD_STATE:"gtm.oldHistoryState",HISTORY_OLD_URL_FRAGMENT:"gtm.oldUrlFragment",TARGET:"gtm.elementTarget"},g=function(a){var b=U(e[a.vtp_varType],1);return void 0!==b?b:a.vtp_defaultValue},h=function(a,
b){if(!a)return!1;var c=l(Ug()),d;d=ua(b.vtp_affiliatedDomains)?b.vtp_affiliatedDomains:String(b.vtp_affiliatedDomains||"").replace(/\s+/g,"").split(",");for(var e=[c],g=0;g<d.length;g++)if(d[g]instanceof RegExp){if(d[g].test(a))return!1}else{var h=d[g];if(0!=h.length){if(0<=l(a).indexOf(h))return!1;e.push(l(h))}}return!$e(a,e)},k=/^https?:\/\//i,l=function(a){k.test(a)||(a="http://"+a);return Wg(N(a),"HOST",!0)};(function(a){Z.__aev=a;Z.__aev.g="aev";Z.__aev.h=!0;Z.__aev.b=0})(function(e){switch(e.vtp_varType){case "TAG_NAME":return U("gtm.element",
1).tagName||e.vtp_defaultValue;case "TEXT":var k,l=U("gtm.element",1),m=U("event",1),r=Number(new Date);a===l&&b===m&&c>r-250?k=d:(d=k=l?mb(l):"",a=l,b=m);c=r;return k||e.vtp_defaultValue;case "URL":var u;a:{var t=String(U("gtm.elementUrl",1)||e.vtp_defaultValue||""),A=N(t);switch(e.vtp_component||"URL"){case "URL":u=t;break a;case "IS_OUTBOUND":u=h(t,e);break a;default:u=sb(A,e.vtp_component,e.vtp_stripWww,e.vtp_defaultPages,e.vtp_queryKey)}}return u;case "ATTRIBUTE":var C;if(void 0===e.vtp_attribute)C=
g(e);else{var D=U("gtm.element",1);C=kb(D,e.vtp_attribute)||e.vtp_defaultValue||""}return C;default:return g(e)}})}();
Z.a.gas=["google"],function(){(function(a){Z.__gas=a;Z.__gas.g="gas";Z.__gas.h=!0;Z.__gas.b=0})(function(a){var b=Pa(a,void 0),c=b;c[P.P]=null;c[P.Lc]=null;var d=b=c;d.vtp_fieldsToSet=d.vtp_fieldsToSet||[];var e=d.vtp_cookieDomain;void 0!==e&&(d.vtp_fieldsToSet.push({fieldName:"cookieDomain",value:e}),delete d.vtp_cookieDomain);return b})}();

Z.a.smm=["google"],function(){(function(a){Z.__smm=a;Z.__smm.g="smm";Z.__smm.h=!0;Z.__smm.b=0})(function(a){var b=a.vtp_input,c=Q(a.vtp_map,"key","value")||{};return c.hasOwnProperty(b)?c[b]:a.vtp_defaultValue})}();


Z.a.paused=[],function(){(function(a){Z.__paused=a;Z.__paused.g="paused";Z.__paused.h=!0;Z.__paused.b=0})(function(a){H(a.vtp_gtmOnFailure)})}();
Z.a.zone=[],function(){function a(a){for(var b=a.vtp_boundaries||[],c=0;c<b.length;c++)if(!b[c])return!1;return!0}function b(b){var d=Ic.s,e=d+":"+b.vtp_gtmTagId,g=U("gtm.uniqueEventId")||0,k=hd(function(){return new h}),l=a(b),m=b.vtp_enableTypeRestrictions?b.vtp_whitelistedTypes.map(function(a){return a.typeId}):null;if(k.registerZone(e,g,l,m))for(var A=b.vtp_childContainers.map(function(a){return a.publicId}),C=0;C<A.length;C++){var D=String(A[C]);if(k.registerChild(D,d,e)){var L=0!==D.indexOf("GTM-"),
E=0===D.indexOf("SB-")?c():void 0;qh(D,E,L)}}}function c(){var a=Zg("_oid")[0];if(a)return{oid:a,namespace:"cookie"}}var d={active:!1,isWhitelisted:function(){return!1}},e={active:!0,isWhitelisted:function(){return!0}},g={zone:!0,cn:!0,css:!0,ew:!0,eq:!0,ge:!0,gt:!0,lc:!0,le:!0,lt:!0,re:!0,sw:!0,um:!0},h=function(){this.Oa={};this.Jb={}};h.prototype.checkState=function(a,b){var c=this.Oa[a];if(!c)return e;var g=this.checkState(c.Bc,b);if(!g.active)return d;for(var h=[],k=0;k<c.Ib.length;k++){var l=
this.Jb[c.Ib[k]];l.Ba(b)&&h.push(l)}return h.length?{active:!0,isWhitelisted:function(a){if(!g.isWhitelisted(a))return!1;for(var b=0;b<h.length;++b)if(h[b].isWhitelisted(a))return!0;return!1}}:d};h.prototype.unregisterChild=function(a){delete this.Oa[a]};h.prototype.registerZone=function(a,b,c,d){var e=this.Jb[a];if(e)return e.ye(b,c),!1;if(!c)return!1;this.Jb[a]=new k(b,d);return!0};h.prototype.registerChild=function(a,b,c){var d=this.Oa[a];if(!d&&Jc[a]||d&&d.Bc!==b)return!1;if(d)return d.Ib.push(c),
!1;this.Oa[a]={Bc:b,Ib:[c]};return!0};var k=function(a,b){this.R=[{ib:a,Ba:!0}];this.Za=null;if(b){this.Za={};for(var c=0;c<b.length;c++)this.Za[b[c]]=!0}};k.prototype.ye=function(a,b){var c=this.R[this.R.length-1];a<=c.ib||c.Ba!=b&&this.R.push({ib:a,Ba:b})};k.prototype.Ba=function(a){if(!this.R||0==this.R.length)return!1;for(var b=this.R.length-1;0<=b;b--)if(this.R[b].ib<=a)return this.R[b].Ba;return!1};k.prototype.isWhitelisted=function(a){return this.Za?g[a]||!!this.Za[a]:!0};var l=function(a){b(a);
H(a.vtp_gtmOnSuccess)};Z.__zone=l;Z.__zone.g="zone";Z.__zone.h=!0;Z.__zone.b=0}();
Z.a.html=["customScripts"],function(){var a=function(b,c,g,h){return function(){try{if(0<c.length){var d=c.shift(),e=a(b,c,g,h);if("SCRIPT"==String(d.nodeName).toUpperCase()&&"text/gtmscript"==d.type){var m=B.createElement("script");m.async=!1;m.type="text/javascript";m.id=d.id;m.text=d.text||d.textContent||d.innerHTML||"";d.charset&&(m.charset=d.charset);var n=d.getAttribute("data-gtmsrc");n&&(m.src=n,eb(m,e));b.insertBefore(m,null);n||e()}else if(d.innerHTML&&0<=d.innerHTML.toLowerCase().indexOf("<script")){for(var p=
[];d.firstChild;)p.push(d.removeChild(d.firstChild));b.insertBefore(d,null);a(d,p,e,h)()}else b.insertBefore(d,null),e()}else g()}catch(q){H(h)}}};var c=function(d){if(B.body){var e=
d.vtp_gtmOnFailure,g=sh(d.vtp_html,d.vtp_gtmOnSuccess,e),h=g.mb,k=g.U;if(d.vtp_useIframe){}else d.vtp_supportDocumentWrite?b(h,k,e):a(B.body,nb(h),k,e)()}else Tg(function(){c(d)},200)};Z.__html=c;Z.__html.g="html";Z.__html.h=!0;Z.__html.b=
0}();


Z.a.lcl=[],function(){function a(){var a=V("document"),d=0,e=function(c){var e=c.target;if(e&&3!==c.which&&(!c.timeStamp||c.timeStamp!==d)){d=c.timeStamp;e=ch(e,["a","area"]);if(!e)return c.returnValue;var g=c.defaultPrevented||!1===c.returnValue,l=gf("lcl",g?"nv.mwt":"mwt",0),m=df(e);m.event="gtm.linkClick";if(g){var n=kh("lcl","nv.ids",[]).join(",");if(n)m["gtm.triggers"]=n;else return}else{var p=kh("lcl","ids",[]).join(",");m["gtm.triggers"]=p}if(b(c,e,a)&&!g&&l&&e.href){var q=V((e.target||"_self").substring(1)),
r=!0;if(Xg(m,function(){r&&q&&(q.location.href=e.href)},l))r=!1;else return c.preventDefault&&c.preventDefault(),c.returnValue=!1}else Xg(m,function(){},l||2E3);return!0}};hb(a,"click",e,!1);hb(a,"auxclick",e,!1)}function b(a,b,e){if(2===a.which||a.ctrlKey||a.shiftKey||a.altKey||a.metaKey)return!1;var c=b.href.indexOf("#"),d=b.target;if(d&&"_self"!==d&&"_parent"!==d&&"_top"!==d||0===c)return!1;if(0<c){var k=tb(N(b.href)),l=tb(N(e.location));return k!==l}return!0}(function(a){Z.__lcl=a;Z.__lcl.g="lcl";
Z.__lcl.h=!0;Z.__lcl.b=0})(function(b){var c=void 0===b.vtp_waitForTags?!0:b.vtp_waitForTags,e=void 0===b.vtp_checkValidation?!0:b.vtp_checkValidation,g=Number(b.vtp_waitForTagsTimeout);if(!g||0>=g)g=2E3;var h=b.vtp_uniqueTriggerId||"0";if(c){var k=function(a){return Math.max(g,a)};ff("lcl","mwt",k,0);e||ff("lcl","nv.mwt",k,0)}var l=function(a){a.push(h);return a};jh("lcl","ids",l,[]);e||jh("lcl","nv.ids",l,[]);if(!lh("lcl")){a();mh("lcl");var m=gf("lcl","legacyTeardown",void 0);m&&m()}H(b.vtp_gtmOnSuccess)})}();

Z.a.evl=["google"],function(){function a(a,b){this.element=a;this.uid=b}function b(){var a=Number(U("gtm.start"))||0;return(new Date).getTime()-a}function c(a,c,d,l){function g(){if(!hh(a.target)){c.has(e.La)||c.set(e.La,""+b());c.has(e.$a)||c.set(e.$a,""+b());var g=0;c.has(e.Ma)&&(g=Number(c.get(e.Ma)));g+=100;c.set(e.Ma,""+g);if(g>=d){var h=df(a.target);h.event="gtm.elementVisibility";var k=fh(a.target);h["gtm.visibleRatio"]=Math.round(1E3*k)/10;h["gtm.visibleTime"]=d;h["gtm.visibleFirstTime"]=
Number(c.get(e.$a));h["gtm.visibleLastTime"]=Number(c.get(e.La));h["gtm.triggers"]=c.uid;Xg(h);l()}}}if(!c.has(e.ra)&&(0==d&&g(),!c.has(e.da))){var h=V("self").setInterval(g,100);c.set(e.ra,h)}}function d(a){a.has(e.ra)&&(V("self").clearInterval(Number(a.get(e.ra))),a.remove(e.ra))}var e={ra:"polling-id-",$a:"first-on-screen-",La:"recent-on-screen-",Ma:"total-visible-time-",da:"has-fired-"};a.prototype.has=function(a){return!!this.element.getAttribute("data-gtm-vis-"+a+this.uid)};a.prototype.get=
function(a){return this.element.getAttribute("data-gtm-vis-"+a+this.uid)};a.prototype.set=function(a,b){this.element.setAttribute("data-gtm-vis-"+a+this.uid,b)};a.prototype.remove=function(a){this.element.removeAttribute("data-gtm-vis-"+a+this.uid)};(function(a){Z.__evl=a;Z.__evl.g="evl";Z.__evl.h=!0;Z.__evl.b=0})(function(b){function g(){var b=!1,c=null;if("CSS"===l){try{c=kf?B.querySelectorAll(m):null}catch(ja){}b=!!c&&t.length!=c.length}else if("ID"===l){var e=lb(m);e&&(c=[e],b=1!=t.length||t[0]!==
e)}c||(c=[],b=0<t.length);if(b){for(var g=0;g<t.length;g++)d(new a(t[g],r));t=[];for(var h=0;h<c.length;h++)t.push(c[h]);0<=A&&gh(A);if(0<t.length){var n=k,p=t,u=[q],R=0;R=Og(n,p,u);A=R}}}function k(b){var h=new a(b.target,r);b.intersectionRatio>=q?h.has(e.da)||c(b,h,p,"ONCE"===u?function(){for(var b=0;b<t.length;b++){var c=new a(t[b],r);c.set(e.da,"1");d(c)}gh(A);if(n&&Eg)for(var h=0;h<Eg.length;h++)Eg[h]===
g&&Eg.splice(h,1)}:function(){h.set(e.da,"1");d(h)}):(d(h),"MANY_PER_ELEMENT"===u&&h.has(e.da)&&(h.remove(e.da),h.remove(e.Ma)),h.remove(e.La))}var l=b.vtp_selectorType,m;"ID"===l?m=String(b.vtp_elementId):"CSS"===l&&(m=String(b.vtp_elementSelector));var n=!!b.vtp_useDomChangeListener,p=b.vtp_useOnScreenDuration&&Number(b.vtp_onScreenDuration)||0,q=(Number(b.vtp_onScreenRatio)||50)/100,r=b.vtp_uniqueTriggerId,u=b.vtp_firingFrequency,t=[],A=-1;g();n&&Fg(g);H(b.vtp_gtmOnSuccess)})}();

var bi={macro:function(a){if(ve.ab.hasOwnProperty(a))return ve.ab[a]}};bi.dataLayer=Vc;bi.onHtmlSuccess=ve.Yb(!0);bi.onHtmlFailure=ve.Yb(!1);bi.callback=function(a){Nc.hasOwnProperty(a)&&ra(Nc[a])&&Nc[a]();delete Nc[a]};bi.ed=function(){Jc[Ic.s]=bi;Oc=Z.a;sc=sc||ve;tc=fd};
bi.Wd=function(){Jc=z.google_tag_manager=z.google_tag_manager||{};if(Jc[Ic.s]){var a=Jc.zones;a&&a.unregisterChild(Ic.s)}else{for(var b=data.resource||{},c=b.macros||[],d=0;d<c.length;d++)lc.push(c[d]);for(var e=b.tags||[],g=0;g<e.length;g++)oc.push(e[g]);for(var h=b.predicates||[],k=0;k<h.length;k++)nc.push(h[k]);for(var l=b.rules||[],m=0;m<l.length;m++){for(var n=l[m],p={},q=0;q<n.length;q++)p[n[q][0]]=Array.prototype.slice.call(n[q],1);mc.push(p)}qc=Z;Xe();bi.ed();ue();jd=!1;kd=0;if("interactive"==
B.readyState&&!B.createEventObject||"complete"==B.readyState)md();else{hb(B,"DOMContentLoaded",md);hb(B,"readystatechange",md);if(B.createEventObject&&B.documentElement.doScroll){var r=!0;try{r=!z.frameElement}catch(t){}r&&nd()}hb(z,"load",md)}me=!1;"complete"===B.readyState?oe():hb(z,"load",oe);a:{
if(!zd)break a;Cd();Fd=void 0;Gd={};Dd={};Id=void 0;Hd={};Ed="";Jd=Ad();z.setInterval(Cd,864E5);}Kc=(new Date).getTime()}};bi.Wd();

})()
