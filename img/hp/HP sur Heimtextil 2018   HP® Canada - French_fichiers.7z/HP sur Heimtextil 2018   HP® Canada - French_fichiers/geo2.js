(function(){
  window['optimizely'] = window['optimizely'] || [];
  window['optimizely'].push(['activateGeoDelayedExperiments', {
    'location':{
      'city': "AUBERVILLIERS",
      'continent': "EU",
      'country': "FR",
      'region': "IDF"
    },
    'ip':"81.250.173.133"
  }]);
})
//
()

;